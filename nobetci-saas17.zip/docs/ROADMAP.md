# Yol Haritası

Bu doküman Nöbetçi'nin ürün gelişimini **8 fazlı** bir yapıda tanımlar. Fazlar
birbirini mantıksal olarak takip eder (temel platform → risk zekası → bilgi merkezi →
AI copilot → RAG → görsel AI → kurumsallaşma → mobil dağıtım) ancak paralel ilerleme
mümkündür. Sprint bazlı ayrıntı için [SPRINTS.md](./SPRINTS.md)'e bakın.

## Durum Özeti

| Faz | Başlık | Durum |
|---|---|---|
| 1 | Core Platform | ✅ Tamamlandı |
| 2 | Risk Intelligence | ✅ Tamamlandı |
| 3 | Knowledge Center | ✅ Tamamlandı |
| 4 | AI Copilot | 🟡 Kısmen tamamlandı |
| 5 | RAG | 🟡 Kısmen tamamlandı |
| 6 | Vision AI | 🔲 Planlandı |
| 7 | Enterprise | 🔲 Planlandı |
| 8 | Mobile Platform | 🔲 Karar bekliyor |

---

## Phase 1 — Core Platform

**Amaç:** İSG yönetimi için gerekli temel veri modelini ve uygulama iskeletini
kurmak; sonraki tüm fazların üzerine inşa edileceği sağlam bir zemin oluşturmak.

- Firma / Şube / Departman / Çalışan veri modeli
- Rol bazlı erişim (İSG Uzmanı / İşveren / Çalışan)
- Backend'e hazır tek veri erişim katmanı (`dataProvider`)
- Bildirim akışı, denetim günlüğü, periyodik kontrol takvimi
- Yönetici dashboard'u (KPI'lar, güvenlik skoru, trendler)

**Durum:** Tamamlandı.

## Phase 2 — Risk Intelligence

**Amaç:** Fine-Kinney risk değerlendirmesini kağıt/Excel seviyesinden, açıklamalı ve
izlenebilir kurumsal bir sürece taşımak.

- Açıklamalı Olasılık/Maruziyet/Şiddet puanlama skalaları
- Otomatik risk skoru, renklendirme ve artık risk hesaplama
- Çoklu düzeltici faaliyet takibi ve risk geçmişi (timeline)
- Departman/şube/durum/öncelik/tarih bazlı gelişmiş filtreleme

**Durum:** Tamamlandı.

## Phase 3 — Knowledge Center

**Amaç:** Mevzuat, risk ve eğitim dokümanlarını dağınık dosyalardan çıkarıp tek,
aranabilir bir kurumsal kütüphanede toplamak.

- Kategorilere ayrılmış doküman kütüphanesi
- Arama, kategori ve doküman türü bazlı filtreleme
- Doküman detay ekranı

**Durum:** Tamamlandı (mock veri ile; gerçek dosya deposu Phase 7 kapsamındadır).

## Phase 4 — AI Copilot

**Amaç:** Yapay zekayı tek bir sohbet ekranından çıkarıp, platformun her adımında
(risk girişi, öneri, karar destek) bağlama duyarlı bir yardımcıya dönüştürmek.

- AI sohbet danışmanı ve fotoğraf yorumlama (mevcut)
- Fine-Kinney önlem/KKD önerisi (mevcut, artık risk sınırlaması ile güvenli)
- Modül-bilinçli öneriler: aktif ekrana göre bağlamsal yardım
- Serbest metinden otomatik risk puanı önerisi (`scoreRisk`)

**Durum:** Temel sohbet ve Fine-Kinney önerisi canlıda; bağlamsal copilot deneyimi
genişletilecek.

## Phase 5 — RAG

**Amaç:** AI Copilot'un cevaplarını genel bilgiden değil, firmanın kendi Bilgi
Kütüphanesi içeriğinden (mevzuat, geçmiş risk raporları, firma dokümanları) üretmesini
sağlamak.

- ✅ Bilgi Kütüphanesi'nde "AI'ya Sor" — soru, anahtar kelime eşleştirmesiyle ilgili
  dokümanlara daraltılıp AI'ye bağlam olarak veriliyor, cevapla birlikte kaynak
  doküman(lar) gösteriliyor.
- 🔲 Dokümanların **vektör/embedding tabanlı** aranabilir hale getirilmesi — bugünkü
  sürüm basit anahtar kelime eşleştirmesi kullanıyor, gerçek semantik arama değil.
- 🔲 Firma bazlı bilgi izolasyonu (bir firmanın dokümanı başka firmanın AI yanıtına
  karışmaz) — bugün tüm dokümanlar tek, paylaşılan bir mock listesinde.

**Durum:** Temel akış (soru → ilgili doküman bulma → AI sentezi → kaynak gösterimi)
çalışıyor durumda; vektör tabanlı arama ve firma izolasyonu gerçek backend'e (Phase 7)
bağlı, henüz yapılmadı.

## Phase 6 — Vision AI

**Amaç:** Risk değerlendirmesine eklenen fotoğrafları pasif bir kayıttan, aktif bir
tehlike tespit aracına dönüştürmek.

- Risk ek dosyası (fotoğraf) üzerinden otomatik tehlike/önlem önerisi
- Tespit edilen bulgunun ilgili Fine-Kinney kaydına otomatik ön-doldurma olarak
  sunulması (öneri niteliğinde, onay zorunlu)

**Durum:** Planlandı. Ek dosya veri modeli (Phase 2) bu senaryo için zaten hazır
şekilde tasarlandı.

## Phase 7 — Enterprise

**Amaç:** Platformu tek kiracılı demodan, gerçek kimlik doğrulama ve veri
izolasyonuna sahip çok kiracılı bir kurumsal SaaS'a taşımak.

- Gerçek kullanıcı kimlik doğrulama (Supabase Auth)
- Sunucu taraflı veri izolasyonu (Row Level Security)
- Tek hesaptan birden fazla firma yönetimi (OSGB senaryosu)
- Gerçek doküman/dosya depolama

**Durum:** Planlandı. Teknik plan için bkz. [DATABASE_PLAN.md](./DATABASE_PLAN.md).

## Phase 8 — Mobile Platform

**Amaç:** Sahada, çevrimdışı da çalışabilen bir mobil deneyim sunmak.

- PWA (Progressive Web App) yeniden etkinleştirme **veya** Capacitor ile native
  paketleme kararı
- Çevrimdışı AI davranışının tanımlanması
- Push bildirim ve kamera/dosya erişiminin native seviyede iyileştirilmesi

**Durum:** Karar bekliyor — bkz. aşağıdaki "Açık Kararlar" bölümü.

---

## Açık Kararlar

- **Mobil dağıtım formatı** — PWA mı, Capacitor mı? (Phase 8)
- **Offline AI davranışı** — bağlantı yokken Copilot/Vision AI ne yapmalı? (Phase 4, 6, 8)
- **Çoklu firma UX detayı** — firma değiştirme ve izin modeli tasarımı (Phase 7)

## Güncelleme Kuralı

Bir faz tamamlandığında yalnızca "Durum Özeti" tablosu ve ilgili fazın "Durum" satırı
güncellenir. Faz kapsamı genişletilecekse önce bu dosyada, sonra
[SPRINTS.md](./SPRINTS.md)'de planlama yapılır.
