# Sprint Takibi

Bu doküman geliştirmenin **sprint bazlı** kaydını tutar. Her satır tek bir sprinti temsil
eder ve [ROADMAP.md](./ROADMAP.md)'deki ilgili **faza** bağlanır. Ayrıntılı, dosya
seviyesinde değişiklik kaydı için kök dizindeki `CHANGELOG.md` (tarihsel geliştirme
notları) ve [CHANGELOG.md](./CHANGELOG.md) (sürüm bazlı özet) dosyalarına bakın.

## Tamamlanan Sprintler

| Sprint | Odak | Faz | Durum |
|---|---|---|---|
| Kurumsal Mimari Refaktörü | Servis katmanı, code-splitting, hata yönetimi, ortak bileşenler | Phase 1 | ✅ |
| Auth Hazırlığı & Role-Based Dashboard | Rol sistemi (3 rol), Fine-Kinney servisi, doküman altyapısı | Phase 1 | ✅ |
| AI Chat Hazırlığı & Ayarlar Genişletmesi | Sohbet veri modeli, Dil/Bildirim ayarları, `useLocalStorage` | Phase 4 | ✅ |
| Fine-Kinney — Profesyonel Seviye (v1) | Gerçek puanlama/renklendirme, AI önerisi, arama/filtre | Phase 2 | ✅ |
| Periyodik Kontrol & Denetim Geçmişi | Periyodik kontrol takvimi, `auditService`, gerçek push bildirim | Phase 1 | ✅ |
| Service Worker Beyaz Ekran Düzeltmesi | Prod hotfix — SW kill-switch, PWA geçici devre dışı | Phase 8 | ✅ |
| Firma Sistemi | Firma/Şube/Departman/Çalışan CRUD, rol altyapısı veri modeli | Phase 1 | ✅ |
| Backend-Hazır Soyutlama Katmanı | `dataProvider.js`, `authService` Supabase-şekilli mock arayüz | Phase 1 | ✅ |
| Sprint 4A — Foundation | `RouteGuard`, `permissions.js`, tüm tiplere `companyId` | Phase 1 | ✅ |
| Sprint 4A.2 — Enterprise UX | Dashboard 2.0, Bildirim Merkezi (sistem olayları), Profil genişlemesi | Phase 1 | ✅ |
| Sprint 4A.3 — Executive Dashboard | Güvenlik skoru, yönetici özeti, trendler, düzeltici faaliyet paneli | Phase 1 | ✅ |
| Sprint 5A — Risk Yönetimi (v2) | Fine-Kinney açıklamalı puanlama, Risk Detay Sayfası (6 sekme), gelişmiş filtreleme | Phase 2 | ✅ |
| Sprint 6 — Bilgi Kütüphanesi | Kategorili doküman kütüphanesi (mock), arama/filtre/detay ekranı | Phase 3 | ✅ |
| Rol Modeli Birleştirmesi & AI Hook Refaktörü | Tek rol kaynağı (`allRoles.js`), `useAIRiskAnalysis` çıkarımı, doküman senkronizasyonu | Phase 1 | ✅ |
| Sprint 7.1 — Risk Workflow Foundation | 6 durumlu esnek risk yaşam döngüsü modeli, legacy `status` uyumluluğu | Phase 2 | ✅ |
| Dashboard Genişletmesi | Kazasız gün sayacı, risk workflow/departman kırılımı widget'ları, dikkat gerektirenler listesi | Phase 2 | ✅ |
| Sprint 7.2 — Eğitim Modülü | Video (yer tutucu) + sınav + otomatik puanlama + katılımcı listesi (uzman/işveren) | Phase 1 | ✅ |
| Sprint 7.2.1 — Education Module (genişletme) | İlerleme yüzdesi, kaldığı yerden devam, 4 durumlu model, dashboard istatistikleri | Phase 1 | ✅ |
| Sprint 7.2.2 — Periyodik Kontrol Modülü (genişletme) | Filtreleme, takvim görünümü, dashboard kartı, tek tıkla tamamlama | Phase 1 | ✅ |
| Bilgi Kütüphanesi — AI Asistanı | "AI'ya Sor" (RAG-lite), favoriler, ilgili dokümanlar | Phase 5 | ✅ |

## Faz Bazlı İlerleme Özeti

| Faz | Tamamlanan Sprint Sayısı | Faz Durumu ([ROADMAP.md](./ROADMAP.md)) |
|---|---|---|
| Phase 1 — Core Platform | 11 | ✅ Tamamlandı |
| Phase 2 — Risk Intelligence | 4 | ✅ Tamamlandı |
| Phase 3 — Knowledge Center | 1 | ✅ Tamamlandı |
| Phase 4 — AI Copilot | 1 | 🟡 Kısmen tamamlandı |
| Phase 5 — RAG | 1 | 🟡 Kısmen tamamlandı |
| Phase 6 — Vision AI | 0 | 🔲 Planlandı |
| Phase 7 — Enterprise | 0 | 🔲 Planlandı |
| Phase 8 — Mobile Platform | 1 (hotfix) | 🔲 Karar bekliyor |

## Sıradaki Sprint

Henüz resmi olarak planlanmadı. [ROADMAP.md](./ROADMAP.md)'ye göre en olası adaylar
Phase 4'ün genişletilmesi (bağlama duyarlı AI Copilot) veya Phase 7'nin başlangıcı
(rol modeli artık tekilleştiği için gerçek kimlik doğrulamaya daha hazır durumda).
Diğer aday konular için [ROADMAP.md](./ROADMAP.md) → "Açık Kararlar" bölümüne bakın.

## Kayıt Kuralı

- Bir sprint tamamlandığında bu tabloya **tek satır** eklenir (uzun açıklama buraya
  yazılmaz — o [CHANGELOG.md](./CHANGELOG.md)'nin işidir) ve ilgili
  [ROADMAP.md](./ROADMAP.md) fazıyla eşleştirilir.
- Sprint adı, kullanıcıdan gelen orijinal isimle (örn. "Sprint 5A") tutarlı olmalıdır.
- Bir sprint birden fazla fazı ilgilendiriyorsa, sprintin **ağırlıklı odağına** göre
  tek bir faz seçilir; ayrıntı [CHANGELOG.md](./CHANGELOG.md)'de belirtilir.
