# Changelog

Bu dosya [Keep a Changelog](https://keepachangelog.com) yaklaşımına uygun, **özet**
bir değişiklik kaydıdır. Dosya/kod seviyesinde tam ayrıntı için kök dizindeki
`CHANGELOG.md` (geliştirme günlüğü) dosyasına bakın.

Kategoriler: `Eklenen`, `Değişen`, `Düzeltilen`, `Kaldırılan`. Her sürüm başlığının
yanındaki `· Phase X` etiketi, o sürümün [ROADMAP.md](./ROADMAP.md)'deki hangi faza
karşılık geldiğini gösterir — sprint bazlı özet için [SPRINTS.md](./SPRINTS.md)'e
bakın.

## [Unreleased]

Henüz yayınlanmamış / planlama aşamasında değişiklik yok.

## [Bilgi Kütüphanesi — AI Asistanı] · Phase 5

### Eklenen
- **"AI'ya Sor"** — Bilgi Kütüphanesi'nde soru sorulduğunda, önce yerel anahtar
  kelime eşleştirmesiyle (`findRelevantDocuments`) ilgili dokümanlar bulunuyor,
  sonra bu dokümanların içeriği AI'ye bağlam olarak veriliyor. Cevapla birlikte
  kullanılan kaynak doküman(lar) her zaman gösteriliyor. **Not:** bu gerçek bir
  vektör/embedding tabanlı RAG değildir — bkz. [AI_ROADMAP.md](./AI_ROADMAP.md).
- **Favoriler** — doküman kartlarına yıldız butonu, "Yalnızca Favoriler" filtresi
  (yerel depoda tutulur, yeni backend gerekmedi).
- **İlgili Dokümanlar** — doküman detay ekranında, aynı kategori/etiketi paylaşan
  diğer dokümanlar önerilir.

### Değişen
- `docs/ROADMAP.md` → Phase 5 (RAG) durumu "Planlandı" → "Kısmen tamamlandı".

## [Sprint 7.2.2] — Periyodik Kontrol Modülü (genişletme) · Phase 1

### Eklenen
- **Filtreleme** — arama + durum (Süresi Geçti/Yaklaşıyor/Güncel) + kategori
  chip'leri (`PeriodicCheckFilters.jsx`, Fine-Kinney'deki filtre deseninin
  birebir uygulanması).
- **Takvim görünümü** — yeni bağımlılık eklemeden, saf bir ay ızgarası
  (`PeriodicCheckCalendar.jsx`); günlere tıklayınca o güne planlı kontroller
  listeleniyor.
- **Dashboard kartları** — yeni "Periyodik Kontrol Özeti" widget'ı (durum bazlı
  sayaç şeridi, Risk Workflow widget'ıyla aynı görsel dil).
- **Yaratıcı ek — tek tıkla "Bugün Kontrol Edildi":** önceden bir kontrolü
  tamamlanmış işaretlemenin tek yolu formu açıp tarihi elle değiştirmekti; artık
  geciken/yaklaşan her kartta tek butonla yapılabiliyor.

### Değişen
- `usePeriodicChecks.js`'e filtre state'i eklendi — mevcut `checks`/`saveCheck`/
  `removeCheck` sözleşmesi değişmedi, yalnızca yanına eklendi.
- `PeriodicCheckCard.jsx`'e hızlı aksiyon butonu eklendi, geri kalanı aynı.

### Not
- `PeriodicCheckForm.jsx`, `constants/periodicCheck.js` ve
  `services/periodicCheckService.js`'e **hiç dokunulmadı** — zaten doğru
  çalışıyordu.

## [Sprint 7.2.1] — Education Module (genişletme) · Phase 1

### Eklenen
- Video ilerleme yüzdesi (canlı, oynatıcı üzerinde) ve **"kaldığı yerden devam
  et"** — yeni `trainingProgress` koleksiyonu (`DB_VERSION` 8→9), her (kurs,
  çalışan) çifti için tek kayıt.
- 4 durumlu eğitim durum modeli: **Atandı / Devam Ediyor / Tamamlandı / Kaldı**
  (`constants/trainingStatus.js` → `resolveTrainingStatus`, Sprint 7.1'deki
  `riskWorkflow.js` ile aynı desen).
- Katılımcı listesine ilerleme yüzdesi ve durum rozeti eklendi — artık yalnızca
  sınavı bitirenler değil, izlemekte olanlar da listede.
- Dashboard'un kullanacağı eğitim istatistikleri (`computeTrainingStats`) —
  katılımcı/atanan/devam eden/tamamlanan/kalan sayıları. Şimdilik hiçbir widget
  tüketmiyor, `useEmployerDashboardData`'nın döndürdüğü `trainingStats` üzerinden
  hazır bekliyor.

### Değişen
- Dashboard'daki "Tamamlanan Eğitim" KPI'ı ve Güvenlik Skoru hesaplaması artık
  **gerçek** veriden besleniyor — önceden sabit `%72` mock değeri kullanılıyordu.
- İleri sarma engeli (`NoSkipVideoPlayer`) artık devam noktasını da koruyor —
  "kaldığı yerden devam et" ile birlikte yanlışlıkla ileri sarma sayılmıyor.

### Not
- Video/sınav sonucu gösterimi ve video bitmeden sınavın açılmaması Sprint 7.2'de
  zaten vardı, bu sprintte yalnızca korundu (tekrar yazılmadı).

## [Sprint 7.2] — Eğitim Modülü · Phase 1

### Eklenen
- `features/training/` — uçtan uca uzaktan eğitim akışı: video izleme (ileri
  sarma engelli `NoSkipVideoPlayer`) → video sonu sınav (`CourseQuiz`, otomatik
  puanlama) → tamamlama kaydı.
- `constants/trainingCourses.js` — 5 kurs (önceki statik `EDUCATION_MODULES`
  başlıklarının yerini aldı), her biri kendi 3 soruluk sınavıyla. Video alanı
  şimdilik telifsiz bir yer tutucu (`Big Buck Bunny` örnek dosyası) — gerçek
  eğitim videosu (AI ile üretim dahil) ayrı bir karar/altyapı gerektiriyor,
  bkz. docs/AI_ROADMAP.md.
- Yeni IndexedDB koleksiyonu: `trainingCompletions` (DB_VERSION 7 → 8).
- Katılımcı listesi — yalnızca İSG uzmanı ve işveren rolüne görünür.
- Sertifika/PDF üretimi **bilinçli olarak yok** — tamamlama kaydının kendisi
  "uzaktan eğitimin verildiğinin belgesi" işlevi görüyor.

### Değişen
- `constants/education.js` → `EDUCATION_MODULES`, artık `trainingCourses.js`'ten
  türetiliyor (tek kaynak) — mevcut 3 tüketici (Dashboard widget'ları,
  Employee mini liste) değişmeden çalışmaya devam ediyor.
- `DocumentsPage.jsx`'teki statik "Eğitim Modülleri" sekmesi gerçek
  `TrainingModule`'e bağlandı.

## [Dashboard Genişletmesi] — Phase 2

### Eklenen
- **Kazasız Gün Sayacı** — bildirim akışındaki gerçek "İş Kazası" kayıtlarından
  hesaplanan, hem İşveren hem Çalışan dashboard'unda gösterilen ortak widget.
- **Risk Workflow** widget'ı — Sprint 7.1'de eklenen 6 durumlu workflow modelini
  (`workflowState`) ilk kez görselleştiriyor.
- **Departman Bazlı Risk Dağılımı** — Sprint 5A'da risklere eklenen `departmentId`
  alanını ilk kez özetleyen bar-liste.
- **Dikkat Gerektirenler** widget'ı — geciken/yaklaşan düzeltici faaliyet
  alt-öğeleri ve periyodik kontrolleri tek, aciliyet sıralı listede birleştirir.
- Dashboard için "Yakında" etiketli PDF/Excel dışa aktarım butonları
  (Fine-Kinney listesindekiyle aynı desen).

### Düzeltilen
- `EmployerOverviewTab.jsx`'te "Düzeltici Faaliyetler" widget'ının ikonu
  (`ListChecks`) import edilmemişti — render sırasında hataya yol açabilecek bu
  eksik import düzeltildi.

## [Sprint 7.1] — Risk Workflow Foundation · Phase 2

### Eklenen
- `src/constants/riskWorkflow.js` — risk yaşam döngüsü için 6 durumlu esnek
  workflow modeli (Taslak/Açık/İncelemede/Aksiyon Bekliyor/Tamamlandı/Kapatıldı)
  ve aralarındaki izin verilen geçişler.
- Legacy `status` alanından (`open`/`in_progress`/`done`) yeni modele geriye
  dönük uyumlu otomatik eşleme (`mapLegacyStatusToWorkflowState`).
- `FineKinneyEntry` tipine opsiyonel `workflowState` alanı.

### Not
- Bu sprint yalnızca veri modeli/mimaridir — hiçbir ekran değiştirilmedi,
  kullanıcı arayüzünde görünen bir değişiklik yoktur.

## [Rol Modeli Birleştirmesi & AI Hook Refaktörü] · Phase 1

### Değişen
- Rol verisi tek kaynağa (`src/constants/allRoles.js`) indirildi; `RoleContext.jsx`
  artık kendi rol listesini tutmuyor, oradan türetiyor. 9 yerde tekrarlanan
  `ROLES.find(...).label` deseni `getRoleLabel()` ile sadeleştirildi.
- `FineKinneyForm.jsx`'teki AI öneri mantığı (`aiLoading`/`aiSuggestion`/
  `getAiSuggestion`) bağımsız `useAIRiskAnalysis` hook'una taşındı — form JSX'i
  değişmedi, dosya 212 → 165 satıra indi.
- `README.md`, `docs/SPRINTS.md`, `docs/CHANGELOG.md` güncel 8 fazlı
  `ROADMAP.md` yapısıyla senkronize edildi.

## [Sprint 6] — Bilgi Kütüphanesi · Phase 3

### Eklenen
- Yeni `knowledge-center` modülü: 8 sabit kategori, mock doküman listesi.
- Arama kutusu, doküman türü filtresi, kategori bazlı filtreleme.
- Doküman detay ekranı (görüntüle/indir eylemleri henüz pasif — gerçek depolama yok).
- `/knowledge-center` route'u ve Sidebar girişi.

## [Sprint 5A] — Risk Yönetimi (v2) · Phase 2

### Eklenen
- Fine-Kinney puanlama seçeneklerine referans açıklamaları.
- Risk Detay Sayfası: Risk Bilgileri, Fine-Kinney, Düzeltici Faaliyetler, Ek Dosyalar,
  Risk Geçmişi, Notlar sekmeleri.
- Çoklu düzeltici faaliyet listesi (önceki tekil alanların yanına, geriye dönük uyumlu).
- Departman/Şube/Durum/Öncelik/Tarih filtreleri.
- Risk geçmişi (timeline) otomatik olay kaydı.

### Değişen
- Fine-Kinney formundaki tekrar eden select blokları `ScaleSelectField` bileşenine
  indirildi.

## [Sprint 4A.3] — Executive Dashboard · Phase 1

### Eklenen
- AI Güvenlik Skoru (`computeSafetyScore`), Yönetici Özeti, Trend paneli.
- Düzeltici Faaliyet paneli, widget görünürlük tercihleri (`localStorage`).
- KPI kartları: risk kapanma süresi, ortalama risk puanı, aktif düzeltici faaliyet.

## [Sprint 4A.2] — Enterprise UX · Phase 1

### Eklenen
- Dashboard 2.0 (Genel Bakış + Performans sekmeleri), Bildirim Merkezi (sistem olayları).
- Profil sayfası genişlemesi (fotoğraf, ünvan, şifre değiştirme arayüzü).
- Rol bazlı sekme filtreleme (Risk Analizi, Dokümanlar).
- Fine-Kinney artık risk (önlem sonrası) hesaplaması ve AI destekli öneri.

## [Sprint 4A] — Foundation · Phase 1

### Eklenen
- `RouteGuard` ve `permissions.js` (rol/izin kontrolü).
- Tüm veri tiplerine `companyId` alanı (çok kiracılı izolasyona hazırlık).
- `notificationRecordService.js` ile Service+Repository mimarisi tamamlandı.

## [Firma Sistemi] · Phase 1

### Eklenen
- Firma, Şube, Departman, Çalışan CRUD modülleri (Ayarlar → Firma Yönetimi).
- Varsayılan departman seti otomatik oluşturma.

## [Backend-Hazır Soyutlama Katmanı] · Phase 1

### Eklenen
- `dataProvider.js` — tüm servislerin geçtiği tek veri erişim arayüzü.
- `authService.js` — Supabase Auth istemcisiyle aynı isimlerde mock fonksiyonlar.

## [Periyodik Kontrol & Denetim Geçmişi] · Phase 1

### Eklenen
- Periyodik kontrol takvimi ve durum hesaplama (`computeNextDueDate`).
- `auditService.js` (denetim/aktivite günlüğü).
- Gerçek tarayıcı push bildirimi (`Notification` API).

### Düzeltilen
- Service Worker'ın cache-first stratejisinin sebep olduğu prod beyaz ekran hatası —
  SW geçici olarak devre dışı bırakıldı (kill-switch script).

## [Fine-Kinney — Profesyonel Seviye (v1)] · Phase 2

### Eklenen
- Gerçek Olasılık × Maruziyet × Şiddet hesaplaması, 5 kademeli renklendirme.
- AI destekli önlem/KKD önerisi, arama ve risk seviyesi filtresi.

## [Auth Hazırlığı & Role-Based Dashboard] · Phase 1

### Eklenen
- 3 rollü (`expert`/`employer`/`employee`) dashboard yönlendirmesi.
- Doküman türleri ve belge oluşturucu arayüzü (mock içerik).

## [Kurumsal Mimari Refaktörü] · Phase 1

### Eklenen
- Servis katmanı (`chatService`, `authService`, `documentService`, `riskService`).
- Route bazlı code-splitting, `ErrorBoundary`, ortak UI bileşenleri (`Button`, `Badge`, vb).

### Değişen
- Dağınık `useIsgData` hook'u yerine paylaşılan `IsgDataContext` — sayfalar arası veri
  senkronizasyonu düzeltildi.
