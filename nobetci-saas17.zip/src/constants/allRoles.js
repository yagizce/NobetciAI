// Rol Modeli — TEK KAYNAK (single source of truth).
//
// ALL_ROLES, sistemdeki tüm rolleri tanımlar. Demo rol değiştirici (Header/Settings/
// Profile) ve tüm "aktör etiketi" ihtiyaçları (denetim günlüğü, risk geçmişi vb.)
// buradan türetilir — başka hiçbir dosyada ayrı bir rol listesi TANIMLANMAZ.
//
// `src/contexts/RoleContext.jsx`, kendi ROLES listesini tutmak yerine bu dosyadaki
// SWITCHABLE_ROLES'ü re-export eder. Diğer tüm modüller `getRoleLabel`/`getRoleMeta`
// fonksiyonlarını doğrudan buradan import eder.

export const ALL_ROLES = [
  { id: "expert", emoji: "🦺", label: "İSG Uzmanı" },
  { id: "employer", emoji: "👨‍💼", label: "İşveren" },
  { id: "employee", emoji: "👷", label: "Çalışan" },
  { id: "companyAdmin", emoji: "🏢", label: "Firma Admini" },
  { id: "superAdmin", emoji: "🛡️", label: "Süper Admin" },
];

// Bugünkü demo rol değiştiricide (Header/Settings/Profile) gösterilen, gerçekten
// "oturum açılabilir" kabul edilen roller. ALL_ROLES'ten FİLTRELENEREK türetilir ki
// iki liste birbirinden asla kopmasın; sırası da ALL_ROLES ile birebir aynı kalır.
const SWITCHABLE_ROLE_IDS = ["expert", "employer", "employee"];
export const SWITCHABLE_ROLES = ALL_ROLES.filter((r) => SWITCHABLE_ROLE_IDS.includes(r.id));

export function getRoleLabel(roleId) {
  return ALL_ROLES.find((r) => r.id === roleId)?.label || roleId;
}

export function getRoleMeta(roleId) {
  return ALL_ROLES.find((r) => r.id === roleId) || null;
}
