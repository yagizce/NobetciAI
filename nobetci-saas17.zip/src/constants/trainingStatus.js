// Sprint 7.2.1 — Eğitim durumu modeli. constants/riskWorkflow.js ile AYNI desen:
// durum listesi + saf bir "resolve" fonksiyonu. Hiçbir yerde kalıcı olarak saklanmaz —
// TrainingProgress (izleme) ve TrainingCompletion (sınav sonucu) kayıtlarından HER
// render'da anlık hesaplanır, tıpkı resolveEntryWorkflowState gibi.

export const TRAINING_STATUSES = [
  { id: "assigned", label: "Atandı", tone: "neutral" },
  { id: "inProgress", label: "Devam Ediyor", tone: "warning" },
  { id: "completed", label: "Tamamlandı", tone: "success" },
  { id: "failed", label: "Kaldı", tone: "danger" },
];

export function getTrainingStatus(statusId) {
  return TRAINING_STATUSES.find((s) => s.id === statusId) || TRAINING_STATUSES[0];
}

/**
 * Bir çalışanın bir kurstaki durumunu, ilerleme ve sınav denemesi kayıtlarından
 * hesaplar. Öncelik sırası: Completed (kalıcı — bir kez geçildiyse, sonradan tekrar
 * izlense bile durum düşürülmez) > yeniden izleniyorsa In Progress > Failed >
 * ilerleme varsa In Progress > Assigned.
 * @param {{ progress: import("../types/index.js").TrainingProgress|null, completions: import("../types/index.js").TrainingCompletion[] }} args
 * @returns {typeof TRAINING_STATUSES[number]}
 */
export function resolveTrainingStatus({ progress, completions }) {
  const latestCompletion = completions.length > 0
    ? [...completions].sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt))[0]
    : null;

  if (latestCompletion?.passed) return getTrainingStatus("completed");

  // Son sınav denemesi başarısızdı ama çalışan o denemeden SONRA yeniden izlemeye
  // başladıysa (yeni bir deneme sürecinde), "Kaldı" yerine "Devam Ediyor" gösterilir.
  const isRewatchingAfterFailure = Boolean(
    progress && latestCompletion && new Date(progress.updatedAt) > new Date(latestCompletion.completedAt)
  );

  if (latestCompletion && !isRewatchingAfterFailure) return getTrainingStatus("failed");
  if (progress && progress.positionSeconds > 0) return getTrainingStatus("inProgress");
  return getTrainingStatus("assigned");
}

/**
 * @param {import("../types/index.js").TrainingProgress|null} progress
 * @returns {number} 0-100
 */
export function computeProgressPercent(progress) {
  if (!progress || !progress.durationSeconds) return 0;
  return Math.min(100, Math.round((progress.positionSeconds / progress.durationSeconds) * 100));
}

/**
 * Dashboard'un kullanacağı eğitim istatistikleri. Yalnızca en az bir ilerleme/tamamlama
 * kaydı bulunan çalışanlar üzerinden hesaplanır — gerçek veri yoksa sahte bir yüzde
 * UYDURULMAZ, 0 döner (bkz. DEVELOPMENT_RULES.md → General Rules).
 * @param {object[]} courses - constants/trainingCourses.js → TRAINING_COURSES
 * @param {import("../types/index.js").TrainingProgress[]} progressRecords
 * @param {import("../types/index.js").TrainingCompletion[]} completionRecords
 * @returns {{ participantCount: number, assignedCount: number, inProgressCount: number, completedCount: number, failedCount: number, completionRatePercent: number }}
 */
export function computeTrainingStats(courses, progressRecords, completionRecords) {
  const employeeNames = new Set([
    ...progressRecords.map((p) => p.employeeName),
    ...completionRecords.map((c) => c.employeeName),
  ]);

  if (employeeNames.size === 0 || courses.length === 0) {
    return { participantCount: 0, assignedCount: courses.length, inProgressCount: 0, completedCount: 0, failedCount: 0, completionRatePercent: 0 };
  }

  let completedCount = 0, inProgressCount = 0, failedCount = 0, assignedCount = 0;

  for (const course of courses) {
    for (const employeeName of employeeNames) {
      const progress = progressRecords.find((p) => p.courseId === course.id && p.employeeName === employeeName) || null;
      const completions = completionRecords.filter((c) => c.courseId === course.id && c.employeeName === employeeName);
      const status = resolveTrainingStatus({ progress, completions });
      if (status.id === "completed") completedCount += 1;
      else if (status.id === "inProgress") inProgressCount += 1;
      else if (status.id === "failed") failedCount += 1;
      else assignedCount += 1;
    }
  }

  const totalSlots = courses.length * employeeNames.size;
  return {
    participantCount: employeeNames.size,
    assignedCount,
    inProgressCount,
    completedCount,
    failedCount,
    completionRatePercent: totalSlots > 0 ? Math.round((completedCount / totalSlots) * 100) : 0,
  };
}
