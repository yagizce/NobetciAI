import KnowledgeCenterPage from "../features/knowledge-center/KnowledgeCenterPage.jsx";
import { useDocumentTitle } from "../hooks/useDocumentTitle.js";

export default function KnowledgeCenter() {
  useDocumentTitle("Bilgi Kütüphanesi");
  return <KnowledgeCenterPage />;
}
