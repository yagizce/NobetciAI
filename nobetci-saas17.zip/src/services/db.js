const DB_NAME = "nobetci-isg";
const DB_VERSION = 9;
const STORES = ["equipment", "notifications", "risks", "fineKinney", "documents", "periodicChecks", "auditLog", "companies", "branches", "departments", "employees", "systemNotifications", "trainingCompletions", "trainingProgress"];

function getDBInstance() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      STORES.forEach((s) => {
        if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: "id" });
      });
    };
  });
}

export async function saveData(storeName, data) {
  try {
    const db = await getDBInstance();
    db.transaction(storeName, "readwrite").objectStore(storeName).put(data);
  } catch (e) {
    console.error("DB save error:", e);
  }
}

export async function loadAllData(storeName) {
  try {
    const db = await getDBInstance();
    return new Promise((resolve) => {
      const req = db.transaction(storeName, "readonly").objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
    });
  } catch (e) {
    console.error("DB loadAll error:", e);
    return [];
  }
}

export async function deleteData(storeName, id) {
  try {
    const db = await getDBInstance();
    db.transaction(storeName, "readwrite").objectStore(storeName).delete(id);
  } catch (e) {
    console.error("DB delete error:", e);
  }
}
