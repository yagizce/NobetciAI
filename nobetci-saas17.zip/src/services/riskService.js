// riskService — Fine-Kinney risk assessment storage, via the abstract dataProvider.
// `scoreRisk()` remains a placeholder: that name is reserved for a future dedicated
// AI/backend risk-scoring endpoint. Free-text risk analysis (the questioning AI risk
// engine) still happens via chatService directly from RiskAnalysisPage — that's
// intentional, it's a conversational flow rather than structured Fine-Kinney data entry.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").FineKinneyEntry[]>}
 */
export async function getFineKinneyEntries() {
  return dataProvider.getAll("fineKinney");
}

/**
 * @param {import("../types/index.js").FineKinneyEntry} entry
 */
export async function saveFineKinneyEntry(entry) {
  const companyId = entry.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("fineKinney", { ...entry, companyId });
}

/**
 * @param {number} id
 */
export async function deleteFineKinneyEntry(id) {
  return dataProvider.remove("fineKinney", id);
}

/**
 * Not implemented yet — reserved for a future dedicated risk-scoring endpoint
 * (e.g. an AI service that suggests Fine-Kinney values from a free-text description).
 * @param {{description: string, type: string}} _input
 * @returns {Promise<never>}
 */
export async function scoreRisk(_input) {
  throw new Error("riskService.scoreRisk henüz uygulanmadı.");
}

/**
 * Sprint 5A: Risk Detay Sayfası alt-sekmeleri (Düzeltici Faaliyetler, Ek Dosyalar, Notlar,
 * Risk Geçmişi) mevcut tekil form akışından (saveFineKinneyEntry) BAĞIMSIZ, hafif bir
 * güncelleme yolu kullanır — sadece belirtilen alanları mevcut kayıtla birleştirir.
 * Bu, ana Fine-Kinney formunu (ve onun score/history mantığını) hiç etkilemez.
 * @param {number} id
 * @param {object} patch - Birleştirilecek kısmi alanlar
 * @returns {Promise<import("../types/index.js").FineKinneyEntry|null>}
 */
export async function patchFineKinneyEntry(id, patch) {
  const current = await dataProvider.getById("fineKinney", id);
  if (!current) return null;
  const updated = { ...current, ...patch };
  await dataProvider.upsert("fineKinney", updated);
  return updated;
}
