import { useState, useMemo } from "react";
import { useTheme } from "../../../contexts/ThemeContext.jsx";
import { useToast } from "../../../contexts/ToastContext.jsx";
import { usePeriodicChecks } from "./usePeriodicChecks.js";
import PeriodicCheckForm, { EMPTY_PERIODIC_CHECK_FORM } from "./PeriodicCheckForm.jsx";
import PeriodicCheckCard from "./PeriodicCheckCard.jsx";
import PeriodicCheckFilters from "./PeriodicCheckFilters.jsx";
import PeriodicCheckCalendar from "./PeriodicCheckCalendar.jsx";
import Button from "../../../components/ui/Button.jsx";
import EmptyState from "../../../components/EmptyState.jsx";
import Loading from "../../../components/Loading.jsx";
import ConfirmDialog from "../../../components/ui/ConfirmDialog.jsx";
import { Plus, ListChecks, Calendar } from "../../../components/icons/index.jsx";

const STATUS_ORDER = { overdue: 0, upcoming: 1, ok: 2 };

export default function PeriodicChecksPanel() {
  const { theme } = useTheme();
  const { showToast } = useToast();
  const {
    checks, allChecks, totalCount, loaded, saveCheck, removeCheck, markCheckedToday,
    search, setSearch, statusFilter, setStatusFilter, categoryFilter, setCategoryFilter,
  } = usePeriodicChecks();

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_PERIODIC_CHECK_FORM);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [view, setView] = useState("list"); // list | calendar

  const sortedChecks = useMemo(
    () => [...checks].sort((a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status]),
    [checks]
  );

  // Genel sağlık özeti — her zaman TÜM kayıtlar üzerinden (filtreden bağımsız),
  // aksi halde bir filtre uygulandığında geciken sayısı yanıltıcı görünürdü.
  const summary = useMemo(() => ({
    overdue: allChecks.filter((c) => c.status === "overdue").length,
    upcoming: allChecks.filter((c) => c.status === "upcoming").length,
  }), [allChecks]);

  function resetForm() {
    setForm(EMPTY_PERIODIC_CHECK_FORM);
    setEditingId(null);
    setFormOpen(false);
  }

  function openNewForm() {
    setForm(EMPTY_PERIODIC_CHECK_FORM);
    setEditingId(null);
    setFormOpen(true);
  }

  function openEditForm(check) {
    setForm({
      itemName: check.itemName, category: check.category, lastCheckDate: check.lastCheckDate,
      intervalDays: check.intervalDays, responsible: check.responsible, notes: check.notes,
    });
    setEditingId(check.id);
    setFormOpen(true);
  }

  async function handleSubmit() {
    if (!form.itemName.trim() || !form.lastCheckDate) return;
    await saveCheck(form, editingId);
    showToast(editingId ? "Kontrol güncellendi." : "Yeni periyodik kontrol eklendi.", "success");
    resetForm();
  }

  async function handleConfirmDelete() {
    await removeCheck(confirmDeleteId);
    setConfirmDeleteId(null);
    showToast("Kontrol kaydı silindi.", "neutral");
  }

  async function handleMarkChecked(id) {
    await markCheckedToday(id);
    showToast("Kontrol bugün yapıldı olarak işaretlendi.", "success");
  }

  if (!loaded) return <Loading label="Periyodik kontroller yükleniyor..." />;

  return (
    <div>
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2 text-xs" style={{ color: theme.textFaint }}>
          {summary.overdue > 0 && (
            <span className="font-semibold px-2 py-1 rounded-full" style={{ background: theme.highRiskBg, color: theme.highRiskText }}>
              {summary.overdue} süresi geçmiş
            </span>
          )}
          {summary.upcoming > 0 && (
            <span className="font-semibold px-2 py-1 rounded-full" style={{ background: theme.warnBg, color: theme.warnText }}>
              {summary.upcoming} yaklaşıyor
            </span>
          )}
          {summary.overdue === 0 && summary.upcoming === 0 && allChecks.length > 0 && <span>Tüm kontroller güncel ✓</span>}
        </div>
        <Button size="sm" onClick={openNewForm} className="flex items-center gap-1.5">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Kontrol Kaydı
        </Button>
      </div>

      {formOpen && (
        <PeriodicCheckForm theme={theme} form={form} setForm={setForm} editingId={editingId} onSubmit={handleSubmit} onCancel={resetForm} />
      )}

      {totalCount > 0 && (
        <>
          <PeriodicCheckFilters
            theme={theme}
            search={search}
            onSearchChange={setSearch}
            statusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
            categoryFilter={categoryFilter}
            onCategoryFilterChange={setCategoryFilter}
          />

          <div className="flex gap-1.5 mb-3">
            <button
              onClick={() => setView("list")}
              className="flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1.5 rounded-full"
              style={view === "list" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}
            >
              <ListChecks style={{ fontSize: "12px" }} /> Liste
            </button>
            <button
              onClick={() => setView("calendar")}
              className="flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1.5 rounded-full"
              style={view === "calendar" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}
            >
              <Calendar style={{ fontSize: "12px" }} /> Takvim
            </button>
          </div>
        </>
      )}

      {totalCount === 0 ? (
        <EmptyState icon={ListChecks} title="Henüz periyodik kontrol kaydı yok" description="Yangın tüpü, ekipman veya elektrik tesisatı gibi düzenli kontrol gerektiren kalemleri ekleyin." />
      ) : sortedChecks.length === 0 ? (
        <EmptyState icon={ListChecks} title="Eşleşen kayıt yok" description="Arama veya filtre kriterlerini değiştirmeyi deneyin." />
      ) : view === "calendar" ? (
        <PeriodicCheckCalendar theme={theme} checks={sortedChecks} />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {sortedChecks.map((c) => (
            <PeriodicCheckCard key={c.id} check={c} theme={theme} onEdit={openEditForm} onDelete={setConfirmDeleteId} onMarkChecked={handleMarkChecked} />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={confirmDeleteId !== null}
        title="Kontrol kaydını sil"
        message="Bu periyodik kontrol kaydını silmek istediğine emin misin?"
        confirmLabel="Sil"
        danger
        onConfirm={handleConfirmDelete}
        onCancel={() => setConfirmDeleteId(null)}
      />
    </div>
  );
}
