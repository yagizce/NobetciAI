import { useState, useEffect, useCallback, useMemo } from "react";
import { getPeriodicChecks, savePeriodicCheck, deletePeriodicCheck } from "../../../services/periodicCheckService.js";
import { computeNextDueDate, computeCheckStatus } from "../../../constants/periodicCheck.js";
import { logActivity } from "../../../services/auditService.js";
import { pushSystemNotification } from "../../../services/systemNotificationService.js";
import { useRole } from "../../../contexts/RoleContext.jsx";
import { getRoleLabel } from "../../../constants/allRoles.js";
import { todayISO } from "../../../utils/dateUtils.js";

export function usePeriodicChecks() {
  const { role } = useRole();
  const [checks, setChecks] = useState([]);
  const [loaded, setLoaded] = useState(false);

  // Sprint 7.2.2: filtreleme — Fine-Kinney modülündeki (useFineKinneyEntries.js)
  // AYNI desen: arama + durum/kategori chip'leri, useMemo ile hesaplanan liste.
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  useEffect(() => {
    getPeriodicChecks().then((data) => {
      setChecks(data);
      setLoaded(true);
    });
  }, []);

  const saveCheck = useCallback(async (formValues, editingId) => {
    const nextDueDate = computeNextDueDate(formValues.lastCheckDate, formValues.intervalDays);
    const status = computeCheckStatus(nextDueDate);
    const entry = {
      id: editingId || Date.now(),
      itemName: formValues.itemName.trim(),
      category: formValues.category,
      lastCheckDate: formValues.lastCheckDate,
      intervalDays: Number(formValues.intervalDays),
      nextDueDate,
      status,
      responsible: formValues.responsible.trim(),
      notes: formValues.notes.trim(),
    };
    await savePeriodicCheck(entry);
    setChecks((prev) => {
      const exists = prev.some((c) => c.id === entry.id);
      return exists ? prev.map((c) => (c.id === entry.id ? entry : c)) : [entry, ...prev];
    });
    logActivity({
      actor: getRoleLabel(role),
      action: editingId ? "Periyodik kontrol güncellendi" : "Periyodik kontrol eklendi",
      details: entry.itemName,
      entityType: "periodicCheck",
    });
    if (status === "upcoming" || status === "overdue") {
      pushSystemNotification({
        type: "periodicCheckDue",
        title: status === "overdue" ? "Periyodik kontrol süresi geçti" : "Periyodik kontrol zamanı yaklaşıyor",
        message: `${entry.itemName} — sonraki kontrol: ${entry.nextDueDate}`,
      });
    }
    return entry;
  }, [role]);

  const removeCheck = useCallback(async (id) => {
    const check = checks.find((c) => c.id === id);
    await deletePeriodicCheck(id);
    setChecks((prev) => prev.filter((c) => c.id !== id));
    logActivity({
      actor: getRoleLabel(role),
      action: "Periyodik kontrol silindi",
      details: check?.itemName || `#${id}`,
      entityType: "periodicCheck",
    });
  }, [checks, role]);

  // Sprint 7.2.2 — yaratıcı ek: tek tıkla "Bugün Kontrol Edildi". Bugüne kadar bir
  // kontrolü tamamlanmış işaretlemenin tek yolu formu açıp tarihi elle değiştirmekti —
  // bu, modülün en sık yapılacak işlemi için gereksiz sürtünmeydi.
  const markCheckedToday = useCallback(async (id) => {
    const check = checks.find((c) => c.id === id);
    if (!check) return;
    await saveCheck({
      itemName: check.itemName,
      category: check.category,
      lastCheckDate: todayISO(),
      intervalDays: check.intervalDays,
      responsible: check.responsible,
      notes: check.notes,
    }, id);
  }, [checks, saveCheck]);

  const filteredChecks = useMemo(() => {
    const query = search.trim().toLowerCase();
    return checks.filter((c) => {
      const matchesSearch = !query || c.itemName.toLowerCase().includes(query) || (c.responsible || "").toLowerCase().includes(query);
      const matchesStatus = statusFilter === "all" || c.status === statusFilter;
      const matchesCategory = categoryFilter === "all" || c.category === categoryFilter;
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [checks, search, statusFilter, categoryFilter]);

  return {
    checks: filteredChecks,
    totalCount: checks.length,
    allChecks: checks,
    loaded,
    saveCheck,
    removeCheck,
    markCheckedToday,
    search, setSearch,
    statusFilter, setStatusFilter,
    categoryFilter, setCategoryFilter,
  };
}
