import { PROBABILITY_SCALE, FREQUENCY_SCALE, SEVERITY_SCALE, STATUS_OPTIONS, PRIORITY_OPTIONS, computeFineKinneyScore } from "../../../constants/fineKinney.js";
import Button from "../../../components/ui/Button.jsx";
import RiskLevelChip from "./RiskLevelChip.jsx";
import ScaleSelectField from "./ScaleSelectField.jsx";
import { useCompanyOrgLists } from "./useCompanyOrgLists.js";
import { useAIRiskAnalysis } from "./useAIRiskAnalysis.js";

export const EMPTY_FINE_KINNEY_FORM = {
  hazard: "", risk: "", probability: 1, frequency: 1, severity: 1, action: "", responsible: "", dueDate: "", status: "open",
  residualProbability: 1, residualFrequency: 1, residualSeverity: 1, residualSuggested: false,
  priority: "medium", completionPercent: 0, departmentId: "", branchId: "",
};

/**
 * @param {{ theme: object, mode: "light"|"dark", form: object, setForm: (f: object) => void, editingId: number|null, onSubmit: () => void, onCancel: () => void }} props
 */
export default function FineKinneyForm({ theme, mode, form, setForm, editingId, onSubmit, onCancel }) {
  const { departments, branches } = useCompanyOrgLists();
  const { aiLoading, aiSuggestion, aiError, getAiSuggestion, applySuggestionToAction } = useAIRiskAnalysis(form, setForm);

  const liveScore = computeFineKinneyScore(Number(form.probability), Number(form.frequency), Number(form.severity));
  const liveResidualScore = computeFineKinneyScore(Number(form.residualProbability), Number(form.residualFrequency), Number(form.residualSeverity));
  const showResidual = form.action.trim().length > 0;

  return (
    <div className="rounded-xl border px-3.5 py-3 mb-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
      <div className="grid gap-2 mb-2 sm:grid-cols-2">
        <input
          value={form.hazard}
          onChange={(e) => setForm({ ...form, hazard: e.target.value })}
          placeholder="Tehlike (örn. Yüksekte korkuluksuz çalışma)"
          className="text-sm rounded-lg px-3 py-2 outline-none border"
          style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
        />
        <input
          value={form.risk}
          onChange={(e) => setForm({ ...form, risk: e.target.value })}
          placeholder="Risk (örn. Yüksekten düşme)"
          className="text-sm rounded-lg px-3 py-2 outline-none border"
          style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
        />
      </div>

      <div className="grid gap-2 mb-2 sm:grid-cols-3">
        <ScaleSelectField theme={theme} label="Olasılık" value={form.probability} onChange={(v) => setForm({ ...form, probability: v })} scale={PROBABILITY_SCALE} />
        <ScaleSelectField theme={theme} label="Maruziyet" value={form.frequency} onChange={(v) => setForm({ ...form, frequency: v })} scale={FREQUENCY_SCALE} />
        <ScaleSelectField theme={theme} label="Şiddet" value={form.severity} onChange={(v) => setForm({ ...form, severity: v })} scale={SEVERITY_SCALE} />
      </div>

      <div className="rounded-lg px-3 py-2.5 mb-3 flex items-center justify-between flex-wrap gap-2" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
        <span className="text-xs" style={{ color: theme.textFaint }}>Mevcut Risk Puanı</span>
        <RiskLevelChip score={liveScore} mode={mode} showDescription />
      </div>

      <button
        onClick={getAiSuggestion}
        disabled={!form.hazard.trim() || aiLoading}
        className="text-xs font-semibold mb-3 px-3 py-1.5 rounded-full disabled:opacity-40"
        style={{ background: theme.accent, color: theme.onAccent }}
      >
        {aiLoading ? "AI düşünüyor..." : "🤖 AI Önerisi Al (önlem + artık risk)"}
      </button>

      {aiError && (
        <div className="rounded-lg px-3 py-2 mb-3 text-xs" style={{ background: theme.emergencyBg, color: theme.emergencyText }}>
          {aiError}
        </div>
      )}

      {aiSuggestion && (
        <div className="rounded-lg px-3 py-2.5 mb-3" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
          <p className="text-[11px] whitespace-pre-wrap mb-2" style={{ color: theme.textMuted }}>{aiSuggestion}</p>
          <button onClick={applySuggestionToAction} className="text-[11px] font-semibold" style={{ color: theme.accent }}>
            + Önlem/KKD önerisini "Alınacak Önlem" alanına ekle
          </button>
          {form.residualSuggested && (
            <p className="text-[10.5px] mt-1.5" style={{ color: theme.successText }}>
              ✓ Artık risk değerleri aşağıda AI önerisiyle dolduruldu — gerekirse elle düzeltebilirsiniz.
            </p>
          )}
        </div>
      )}

      <textarea
        value={form.action}
        onChange={(e) => setForm({ ...form, action: e.target.value })}
        placeholder="Alınacak önlem"
        rows={3}
        className="w-full text-sm rounded-lg px-3 py-2 mb-2 outline-none border resize-none"
        style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
      />

      {showResidual && (
        <div className="rounded-lg px-3 py-3 mb-3" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
          <p className="text-xs font-semibold mb-2" style={{ color: theme.textPrimary }}>Artık Risk (Önlem Sonrası)</p>
          <p className="text-[10.5px] mb-2" style={{ color: theme.textFaint }}>Yukarıdaki önlem uygulandığında beklenen değerleri seçin — Şiddet genelde değişmez.</p>
          <div className="grid gap-2 mb-2 sm:grid-cols-3">
            <ScaleSelectField theme={theme} label="Artık Olasılık" value={form.residualProbability} onChange={(v) => setForm({ ...form, residualProbability: v })} scale={PROBABILITY_SCALE} background={theme.surfaceAlt} />
            <ScaleSelectField theme={theme} label="Artık Maruziyet" value={form.residualFrequency} onChange={(v) => setForm({ ...form, residualFrequency: v })} scale={FREQUENCY_SCALE} background={theme.surfaceAlt} />
            <ScaleSelectField theme={theme} label="Artık Şiddet" value={form.residualSeverity} onChange={(v) => setForm({ ...form, residualSeverity: v })} scale={SEVERITY_SCALE} background={theme.surfaceAlt} />
          </div>
          <div className="rounded-lg px-3 py-2 flex items-center justify-between flex-wrap gap-2" style={{ background: theme.surfaceAlt }}>
            <span className="text-xs" style={{ color: theme.textFaint }}>Artık Risk Puanı</span>
            <RiskLevelChip score={liveResidualScore} mode={mode} showDescription />
          </div>
        </div>
      )}

      <div className="grid gap-2 mb-2 sm:grid-cols-3">
        <input value={form.responsible} onChange={(e) => setForm({ ...form, responsible: e.target.value })} placeholder="Sorumlu kişi"
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
        <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
        <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
          {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>

      {(departments.length > 0 || branches.length > 0) && (
        <div className="grid gap-2 mb-2 sm:grid-cols-2">
          <label className="block">
            <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Departman</span>
            <select value={form.departmentId} onChange={(e) => setForm({ ...form, departmentId: e.target.value })}
              className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
              <option value="">Belirtilmedi</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Şube</span>
            <select value={form.branchId} onChange={(e) => setForm({ ...form, branchId: e.target.value })}
              className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
              <option value="">Belirtilmedi</option>
              {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </label>
        </div>
      )}

      <div className="grid gap-2 mb-3 sm:grid-cols-2">
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Öncelik</span>
          <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}
            className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
            {PRIORITY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Tamamlanma Yüzdesi: %{form.completionPercent}</span>
          <input type="range" min="0" max="100" step="5" value={form.completionPercent}
            onChange={(e) => setForm({ ...form, completionPercent: Number(e.target.value) })}
            className="w-full" style={{ accentColor: theme.accent }} />
        </label>
      </div>

      <div className="flex gap-2">
        <Button variant="secondary" onClick={onCancel} className="flex-1">Vazgeç</Button>
        <Button onClick={onSubmit} disabled={!form.hazard.trim() || !form.risk.trim()} className="flex-1">
          {editingId ? "Güncelle" : "Kaydet"}
        </Button>
      </div>
    </div>
  );
}
