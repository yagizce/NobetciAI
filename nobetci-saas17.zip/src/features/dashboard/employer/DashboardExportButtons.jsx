import { FileText } from "../../../components/icons/index.jsx";
import Badge from "../../../components/ui/Badge.jsx";

/**
 * FineKinneyExportButtons.jsx ile BİREBİR AYNI desen — kod tekrarını önlemek için ortak
 * bir bileşene çıkarılabilir ama iki kullanım (Fine-Kinney listesi / Dashboard) henüz
 * "3. kullanım" eşiğine ulaşmadı (bkz. DEVELOPMENT_RULES.md → Code Quality: erken
 * soyutlama yapılmaz). Üçüncü bir yerde aynı desen gerekirse ortak bileşene çıkarılmalı.
 * @param {{ theme: object }} props
 */
export default function DashboardExportButtons({ theme }) {
  return (
    <div className="flex gap-2">
      {["PDF", "Excel"].map((label) => (
        <button
          key={label}
          disabled
          className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full opacity-60 cursor-not-allowed"
          style={{ background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}
        >
          <FileText style={{ fontSize: "13px" }} />
          {label}
          <Badge tone="neutral">Yakında</Badge>
        </button>
      ))}
    </div>
  );
}
