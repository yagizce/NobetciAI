import { useState } from "react";
import Button from "../../components/ui/Button.jsx";

/**
 * Video sonu sınavı. Tüm sorular cevaplanmadan gönderilemez. Puanlama tamamen
 * otomatiktir (constants/trainingCourses.js'teki `correctIndex` ile karşılaştırma).
 *
 * @param {{ theme: object, quiz: Array<{id:string, question:string, options:string[], correctIndex:number}>, passingScorePercent: number, onSubmit: (result: { scorePercent: number, passed: boolean }) => void }} props
 */
export default function CourseQuiz({ theme, quiz, passingScorePercent, onSubmit }) {
  const [answers, setAnswers] = useState({});

  const allAnswered = quiz.every((q) => answers[q.id] !== undefined);

  function submit() {
    if (!allAnswered) return;
    const correctCount = quiz.filter((q) => answers[q.id] === q.correctIndex).length;
    const scorePercent = Math.round((correctCount / quiz.length) * 100);
    onSubmit({ scorePercent, passed: scorePercent >= passingScorePercent });
  }

  return (
    <div>
      <p className="text-sm font-semibold mb-3" style={{ color: theme.textPrimary }}>Sınav</p>
      <div className="flex flex-col gap-4 mb-4">
        {quiz.map((q, qi) => (
          <div key={q.id}>
            <p className="text-sm font-medium mb-2" style={{ color: theme.textPrimary }}>{qi + 1}. {q.question}</p>
            <div className="flex flex-col gap-1.5">
              {q.options.map((opt, oi) => (
                <button
                  key={oi}
                  onClick={() => setAnswers((prev) => ({ ...prev, [q.id]: oi }))}
                  className="text-left text-sm px-3 py-2 rounded-lg border"
                  style={
                    answers[q.id] === oi
                      ? { background: theme.accent, color: theme.onAccent, borderColor: theme.accent }
                      : { background: theme.surface, color: theme.textPrimary, borderColor: theme.border }
                  }
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
      <Button onClick={submit} disabled={!allAnswered} className="w-full">
        {allAnswered ? "Sınavı Bitir" : `${Object.keys(answers).length}/${quiz.length} soru cevaplandı`}
      </Button>
    </div>
  );
}
