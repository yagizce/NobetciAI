import Badge from "../../components/ui/Badge.jsx";
import { CheckCircle2 } from "../../components/icons/index.jsx";
import { resolveTrainingStatus, computeProgressPercent } from "../../constants/trainingStatus.js";

/**
 * @param {{ theme: object, course: object, myProgress: object|null, myCompletions: object[], onStart: () => void }} props
 */
export default function CourseCard({ theme, course, myProgress, myCompletions, onStart }) {
  const status = resolveTrainingStatus({ progress: myProgress, completions: myCompletions });
  const progressPercent = computeProgressPercent(myProgress);
  const latestCompletion = myCompletions.length > 0
    ? [...myCompletions].sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt))[0]
    : null;

  return (
    <div className="rounded-lg border px-3.5 py-3" style={{ borderColor: theme.border, background: theme.surface }}>
      <div className="flex items-start justify-between gap-2 mb-1">
        <p className="text-sm font-semibold" style={{ color: theme.textPrimary }}>{course.title}</p>
        {course.mandatory && <Badge tone="warning">Zorunlu</Badge>}
      </div>
      <p className="text-xs mb-2.5" style={{ color: theme.textMuted }}>{course.description}</p>

      <div className="flex items-center gap-1.5 mb-2.5">
        <Badge tone={status.tone}>{status.label}</Badge>
        {latestCompletion && <span className="text-[10.5px]" style={{ color: theme.textFaint }}>Son sınav: %{latestCompletion.quizScore}</span>}
      </div>

      {status.id === "inProgress" && (
        <div className="mb-2.5">
          <div className="h-1.5 rounded-full overflow-hidden mb-1" style={{ background: theme.surfaceAlt }}>
            <div className="h-full rounded-full" style={{ width: `${progressPercent}%`, background: theme.accent }} />
          </div>
          <span className="text-[10.5px]" style={{ color: theme.textFaint }}>Video izleme: %{progressPercent}</span>
        </div>
      )}

      {status.id === "completed" ? (
        <div className="flex items-center gap-1.5">
          <CheckCircle2 style={{ fontSize: "14px", color: theme.successText }} />
          <span className="text-xs font-semibold" style={{ color: theme.successText }}>Tamamlandı — %{latestCompletion.quizScore}</span>
        </div>
      ) : (
        <button onClick={onStart} className="text-xs font-semibold px-3 py-1.5 rounded-full" style={{ background: theme.accent, color: theme.onAccent }}>
          {status.id === "assigned" ? "Eğitimi İzle" : status.id === "inProgress" ? "Devam Et" : "Tekrar Dene"}
        </button>
      )}
    </div>
  );
}
