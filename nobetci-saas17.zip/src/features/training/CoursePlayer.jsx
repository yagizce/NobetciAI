import { useState } from "react";
import NoSkipVideoPlayer from "./NoSkipVideoPlayer.jsx";
import CourseQuiz from "./CourseQuiz.jsx";
import Button from "../../components/ui/Button.jsx";
import Badge from "../../components/ui/Badge.jsx";
import { X, CheckCircle2, AlertTriangle } from "../../components/icons/index.jsx";

/**
 * Video → Sınav → Sonuç akışını yöneten orkestratör. Sertifika/PDF ÜRETMEZ — sonuç
 * ekranındaki "Tamamlandı" durumu ve arkada kaydedilen TrainingCompletion kaydı,
 * uzaktan eğitimin verildiğinin belgesi yerine geçer.
 *
 * Sprint 7.2.1: `myProgress` (varsa) ile "kaldığı yerden devam et" desteklenir.
 *
 * @param {{ theme: object, course: object, employeeName: string, myProgress: import("../../types/index.js").TrainingProgress|null, onClose: () => void, onComplete: (data: object) => void, onProgress: (data: object) => void }} props
 */
export default function CoursePlayer({ theme, course, employeeName, myProgress, onClose, onComplete, onProgress }) {
  const alreadyFullyWatched = Boolean(myProgress && myProgress.durationSeconds > 0 && myProgress.positionSeconds >= myProgress.durationSeconds - 1);
  const [step, setStep] = useState("video"); // video | quiz | result
  const [videoWatched, setVideoWatched] = useState(alreadyFullyWatched);
  const [result, setResult] = useState(null);

  function handleQuizSubmit({ scorePercent, passed }) {
    setResult({ scorePercent, passed });
    setStep("result");
    onComplete({
      courseId: course.id,
      employeeName,
      watchedFullVideo: true,
      quizScore: scorePercent,
      passed,
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-2 sm:px-4">
      <div className="absolute inset-0 bg-black/40" onClick={step !== "video" ? undefined : onClose} />
      <div className="relative w-full max-w-lg rounded-2xl p-4 sm:p-5 max-h-[90vh] overflow-y-auto" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
        <div className="flex items-start justify-between gap-2 mb-3">
          <p className="font-[Oswald] text-base uppercase tracking-wide" style={{ color: theme.textPrimary }}>{course.title}</p>
          {step !== "quiz" && (
            <button onClick={onClose} aria-label="Kapat"><X style={{ fontSize: "18px", color: theme.textMuted }} /></button>
          )}
        </div>

        {step === "video" && (
          <NoSkipVideoPlayer
            theme={theme}
            videoUrl={course.videoUrl}
            initialPositionSeconds={myProgress?.positionSeconds || 0}
            onFullyWatched={() => setVideoWatched(true)}
            onProgress={(positionSeconds, durationSeconds) => onProgress({ courseId: course.id, employeeName, positionSeconds, durationSeconds })}
          />
        )}

        {step === "video" && (
          <Button className="w-full mt-3" onClick={() => setStep("quiz")} disabled={!videoWatched}>
            {videoWatched ? "Sınava Geç" : "Sınava geçmek için videoyu tamamlayın"}
          </Button>
        )}

        {step === "quiz" && (
          <CourseQuiz theme={theme} quiz={course.quiz} passingScorePercent={course.passingScorePercent} onSubmit={handleQuizSubmit} />
        )}

        {step === "result" && result && (
          <div className="text-center py-4">
            {result.passed ? (
              <CheckCircle2 style={{ fontSize: "40px", color: theme.successText, margin: "0 auto 8px" }} />
            ) : (
              <AlertTriangle style={{ fontSize: "40px", color: theme.warnText, margin: "0 auto 8px" }} />
            )}
            <p className="text-lg font-bold mb-1" style={{ color: theme.textPrimary }}>%{result.scorePercent}</p>
            <div className="mb-3">
              <Badge tone={result.passed ? "success" : "warning"}>{result.passed ? "Başarılı — Eğitim Tamamlandı" : "Başarısız — Tekrar Deneyin"}</Badge>
            </div>
            <p className="text-xs mb-4" style={{ color: theme.textFaint }}>
              {result.passed
                ? "Tamamlama kaydınız oluşturuldu."
                : `Geçme notu %${course.passingScorePercent}. Videoyu tekrar izleyip sınava yeniden girebilirsiniz.`}
            </p>
            <div className="flex gap-2">
              {!result.passed && (
                <Button variant="secondary" className="flex-1" onClick={() => { setStep("video"); setResult(null); }}>
                  Tekrar Dene
                </Button>
              )}
              <Button className="flex-1" onClick={onClose}>Kapat</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
