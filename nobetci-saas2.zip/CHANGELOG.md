# Changelog

## [Kurumsal Mimari Refaktörü] — Bu güncelleme

Bu bir yeniden yazma değildir — çalışan hiçbir özellik bozulmadı, kod yeni bir mimariye taşındı.

### Kaldırıldı
- `src/pages/Settings.jsx` — tekrarlanan tema değiştirici kaldırıldı (zaten Header'da mevcut)
- `src/services/api.js` — yerini `src/services/chatService.js` aldı
- `src/hooks/useIsgData.js` — yerini `src/contexts/IsgDataContext.jsx` aldı (bkz. "Düzeltilen hata")

### Eklendi — Servis katmanı
- `src/services/chatService.js` — **tek gerçekten çalışan servis.** Chat ve fotoğraf analizi Netlify Function proxy'sine buradan gidiyor.
- `src/services/authService.js` — **sahte (mock) kullanıcı sistemi.** `getCurrentUser()` şu an sabit bir `User` objesi döndürüyor (`id, name, email, company, role, subscription`). Gerçek kimlik doğrulama eklenince yalnızca bu dosya değişecek.
- `src/services/documentService.js` — ekipman kayıtları için IndexedDB sarmalayıcı (gerçek, çalışıyor — ama API'ye gitmiyor).
- `src/services/riskService.js` — **iskelet/placeholder.** Risk analizi şu an `chatService` üzerinden yapılıyor; bu dosya gelecekte özel bir risk-skorlama backend'i eklenince kullanılacak.

### Eklendi — Sayfa/Route yapısı
- `src/App.jsx` — tüm sayfalar artık `React.lazy` + `Suspense` ile code-splitting kullanıyor (her sayfa kendi JS parçası, yalnızca ziyaret edildiğinde indiriliyor).
- Tüm sayfalara `useDocumentTitle` hook'u eklendi (`src/hooks/useDocumentTitle.js`) — sekme başlığı sayfaya göre dinamik olarak değişiyor.

### Eklendi — Hata yönetimi
- `src/components/ErrorBoundary.jsx` — `main.jsx`'te tüm uygulamayı sarmalıyor, render hatalarını yakalayıp kullanıcıya "Sayfayı Yenile" seçeneği sunuyor.
- `src/components/Loading.jsx` — tam sayfa yükleme göstergesi (Suspense fallback olarak da kullanılıyor).
- `src/components/EmptyState.jsx` — boş liste durumları için (Dashboard ve Risk Analizi'nde kullanıldı).
- 404 sayfası zaten mevcuttu (`src/pages/NotFound.jsx`), route yapısına bağlı kalmaya devam ediyor.

### Eklendi — Yeniden kullanılabilir bileşenler (`src/components/ui/`)
`Button`, `Input`, `Modal`, `Card`, `Badge`, `Loader`, `Toast` (+ `src/contexts/ToastContext.jsx`), `ConfirmDialog`.
Bazıları (Button, Badge, EmptyState) Risk Analizi ve Dashboard sayfalarında kullanılmaya başlandı; diğerleri (Modal, Input, Card, ConfirmDialog) hazır ve kullanılabilir durumda ama henüz her ekrana zorla entegre edilmedi — mevcut, çalışan arayüzü bozmamak adına kademeli benimseme tercih edildi.

### Düzeltilen hata
- **Veri tutarsızlığı:** Önceki sürümde `useIsgData` düz bir hook'tu; Header, Dashboard, Risk Analizi ve Dokümanlar sayfaları her biri kendi bağımsız IndexedDB okuma/durum kopyasına sahipti. Bir sayfada bildirim gönderildiğinde diğerleri anında güncellenmiyordu. Şimdi `src/contexts/IsgDataContext.jsx` tek bir paylaşılan kaynak — tüm sayfalar gerçek zamanlı senkronize.

### TypeScript hazırlığı
- `src/types/index.js` içine `User` tipi eklendi (JSDoc `@typedef`).
- Servis fonksiyonlarına JSDoc `@param`/`@returns` eklendi — ileride `.ts`'e geçişte tip çıkarımı kolaylaşsın diye.
- Yeni bağımlılık eklenmedi (TypeScript derleyicisi dahil) — mevcut kısıtlamaya uyuldu.

### Performans
- Route bazlı code splitting (`React.lazy`/`Suspense`).
- `React.memo`: `NotificationCard`, `QuickActionButton` — liste öğeleri artık gereksiz yere yeniden render olmuyor.
- `useMemo`: Dashboard metrikleri, Risk Analizi'nde görünür bildirim filtresi.
- `useCallback`: memoized bileşenlere geçen tüm handler'lar (`askQuickAction`, `copyMessage`, `submitNotification`, `expertApprove`).

### Güvenlik
- Değişiklik yok — API anahtarı hâlâ yalnızca `netlify/functions/chat.js` içinde, ortam değişkeni olarak duruyor. Hiçbir noktada frontend koduna yazılmadı.

### Bozulmayanlar (doğrulandı)
- AI Chat (hazır sorular, fotoğraf analizi, kopyala/temizle)
- Bildirim Merkezi akışı (Çalışan → AI → Uzman → İşveren)
- QR ekipman takibi, Eğitim modülleri
- Netlify Functions, `netlify.toml` build ayarları
- PWA (manifest, service worker) — `/public` altında değişmeden duruyor
- Dark/Light tema — `localStorage`'da saklanmaya devam ediyor, artık yalnızca Header'da
