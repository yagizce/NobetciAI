/**
 * @typedef {Object} User
 * @property {string} id
 * @property {string} name
 * @property {string} email
 * @property {string} company
 * @property {"worker"|"expert"|"employer"} role
 * @property {"trial"|"pro"|"enterprise"} subscription
 */

/**
 * @typedef {Object} Notification
 * @property {number} id
 * @property {"ramakKala"|"tehlike"|"kaza"} type
 * @property {string} desc
 * @property {"pending"|"ai_analyzed"|"approved"} status
 * @property {string} worker
 * @property {string} date
 * @property {string|null} aiAnalysis
 * @property {string|null} expertNote
 */

/**
 * @typedef {Object} Equipment
 * @property {number} id
 * @property {string} name
 * @property {string|null} qr
 * @property {string} lastCheck
 */

/**
 * @typedef {Object} ChatMessage
 * @property {"user"|"assistant"} role
 * @property {string} text
 * @property {string} [image]
 * @property {string} time
 */

export {};
