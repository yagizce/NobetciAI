// authService — MOCK implementation. There is no real backend authentication yet.
// This exists so the rest of the app (Header, Profile, Settings) can be built against
// a stable User shape now, and swapped for real auth (e.g. Supabase Auth, Auth0) later
// without touching consuming components — only this file would change.

/** @type {import("../types/index.js").User} */
const MOCK_USER = {
  id: "usr_demo_001",
  name: "Ahmet Yıldız",
  email: "ahmet.yildiz@example.com",
  company: "Örnek Sanayi A.Ş.",
  role: "worker",
  subscription: "trial",
};

/**
 * @returns {Promise<import("../types/index.js").User>}
 */
export async function getCurrentUser() {
  // Simulated network delay so loading states can be exercised meaningfully.
  return new Promise((resolve) => setTimeout(() => resolve({ ...MOCK_USER }), 150));
}

/**
 * Placeholder — will call a real backend once auth is implemented.
 * @returns {Promise<{success: boolean, message: string}>}
 */
export async function loginWithCredentials(_email, _password) {
  return { success: false, message: "Gerçek kimlik doğrulama henüz bağlı değil (mock servis)." };
}
