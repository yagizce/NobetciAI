// documentService — wraps equipment/document storage (IndexedDB via services/db.js).
// Kept separate from chatService because it doesn't touch the network/API at all.

import { loadAllData, saveData } from "./db.js";

/**
 * @returns {Promise<import("../types/index.js").Equipment[]>}
 */
export async function getEquipment() {
  return loadAllData("equipment");
}

/**
 * @param {import("../types/index.js").Equipment} equipment
 */
export async function saveEquipment(equipment) {
  return saveData("equipment", equipment);
}
