// riskService — PLACEHOLDER. Risk analysis currently happens by calling chatService
// directly from the Risk Analysis feature (src/features/risk-analysis/RiskAnalysisPage.jsx),
// using the SYSTEM_PROMPT risk-engine rules. This file is scaffolding for when risk scoring
// becomes its own backend concern (e.g. a dedicated Fine-Kinney/L-Tipi calculation endpoint,
// or a database of past assessments) — at that point, RiskAnalysisPage should be updated to
// call these functions instead of chatService directly.

/**
 * Not implemented yet — reserved for a future dedicated risk-scoring endpoint.
 * @param {{description: string, type: string}} _input
 * @returns {Promise<never>}
 */
export async function scoreRisk(_input) {
  throw new Error("riskService.scoreRisk henüz uygulanmadı — şu an risk analizi chatService üzerinden yapılıyor.");
}
