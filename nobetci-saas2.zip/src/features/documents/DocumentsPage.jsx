import { useState, useRef } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useIsgData } from "../../contexts/IsgDataContext.jsx";
import { nowLabel } from "../../utils/dateUtils.js";
import { QrCode, BookOpen } from "../../components/icons/index.jsx";

const EDUCATION_MODULES = ["KKD Kullanımı", "Yangın Söndürme", "İlk Yardım", "Elektrik Güvenliği", "Yüksekte Çalışma"];

export default function DocumentsPage() {
  const { theme } = useTheme();
  const { equipmentList, addEquipment } = useIsgData();
  const [tab, setTab] = useState("equipment");
  const [scanResult, setScanResult] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  function startQRScan() {
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then((stream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play();
            scanQRLoop();
          };
        }
      });
    }
  }

  function scanQRLoop() {
    if (canvasRef.current && videoRef.current && window.jsQR) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      ctx.drawImage(videoRef.current, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = window.jsQR(imageData.data, canvas.width, canvas.height);
      if (code) {
        setScanResult(code.data);
        videoRef.current.srcObject?.getTracks().forEach((t) => t.stop());
      } else {
        requestAnimationFrame(scanQRLoop);
      }
    }
  }

  function handleAddEquipment() {
    addEquipment({ id: Date.now(), name: `Ekipman ${equipmentList.length + 1}`, qr: scanResult, lastCheck: nowLabel() });
    setScanResult(null);
  }

  return (
    <div className="px-4 md:px-8 py-6 max-w-3xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-3" style={{ color: theme.textPrimary }}>Dokümanlar</p>

      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab("equipment")} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full"
          style={tab === "equipment" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
          <QrCode style={{ fontSize: "13px" }} /> Ekipman Kayıtları
        </button>
        <button onClick={() => setTab("education")} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full"
          style={tab === "education" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
          <BookOpen style={{ fontSize: "13px" }} /> Eğitim Modülleri
        </button>
      </div>

      {tab === "equipment" && (
        <div>
          {!scanResult ? (
            <button onClick={startQRScan} className="w-full max-w-sm py-3 rounded-xl border-2 text-center font-semibold mb-4" style={{ borderColor: theme.accent, background: theme.surfaceAlt, color: theme.accent }}>
              QR Kod Tarayıcı Başlat
            </button>
          ) : (
            <div className="rounded-xl p-4 mb-4 max-w-sm" style={{ background: theme.successBg }}>
              <p className="text-sm" style={{ color: theme.successText }}>✓ QR Okundu</p>
              <button onClick={handleAddEquipment} className="w-full mt-2 py-2 rounded-lg font-semibold" style={{ background: theme.accent, color: theme.onAccent }}>Ekleyin</button>
            </div>
          )}
          <video ref={videoRef} style={{ display: "none" }} />
          <canvas ref={canvasRef} style={{ display: "none" }} />

          <p className="font-[Oswald] text-sm uppercase tracking-wide mb-2" style={{ color: theme.textPrimary }}>Kayıtlı Ekipmanlar</p>
          <div className="grid gap-2 md:grid-cols-2">
            {equipmentList.map((eq) => (
              <div key={eq.id} className="rounded-lg border px-3 py-2" style={{ borderColor: theme.border, background: theme.surface }}>
                <p className="text-sm" style={{ color: theme.textPrimary }}>{eq.name}</p>
                <p className="text-xs" style={{ color: theme.textFaint }}>Son: {eq.lastCheck}</p>
              </div>
            ))}
            {equipmentList.length === 0 && <p className="text-xs" style={{ color: theme.textFaint }}>Henüz kayıtlı ekipman yok.</p>}
          </div>
        </div>
      )}

      {tab === "education" && (
        <div className="grid gap-2 md:grid-cols-2">
          {EDUCATION_MODULES.map((title, i) => (
            <div key={i} className="rounded-lg border px-3 py-3" style={{ borderColor: theme.border, background: theme.surface }}>
              <p className="text-sm font-semibold" style={{ color: theme.textPrimary }}>{title}</p>
              <p className="text-xs mt-1" style={{ color: theme.textMuted }}>Zorunlu Eğitim</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
