import { useMemo } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useIsgData } from "../../contexts/IsgDataContext.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import { ClipboardList } from "../../components/icons/index.jsx";

export default function DashboardPage() {
  const { theme } = useTheme();
  const { notifications, equipmentList } = useIsgData();

  // Recomputed only when the underlying collections actually change, not on every render.
  const metrics = useMemo(() => ({
    openRisks: notifications.filter((n) => n.status !== "approved").length,
    pendingNotifs: notifications.filter((n) => n.status === "pending" || n.status === "ai_analyzed").length,
    nearMiss: notifications.filter((n) => n.type === "ramakKala").length,
    workAccidents: notifications.filter((n) => n.type === "kaza").length,
    upcomingChecks: equipmentList.length,
  }), [notifications, equipmentList]);

  const CARDS = [
    { label: "Açık Riskler", value: metrics.openRisks, bg: theme.highRiskBg, color: theme.highRiskText },
    { label: "Bekleyen Bildirimler", value: metrics.pendingNotifs, bg: theme.pendingBg, color: theme.pendingText },
    { label: "Yaklaşan Kontroller", value: metrics.upcomingChecks, bg: theme.warnBg, color: theme.warnText },
    { label: "Ramak Kala", value: metrics.nearMiss, bg: theme.successBg, color: theme.successText },
    { label: "İş Kazaları", value: metrics.workAccidents, bg: theme.highRiskBg, color: theme.highRiskText },
  ];

  return (
    <div className="px-4 md:px-8 py-6 max-w-4xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-4" style={{ color: theme.textPrimary }}>Dashboard</p>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        {CARDS.map((c) => (
          <div key={c.label} className="rounded-lg p-3" style={{ background: c.bg }}>
            <p className="text-xs" style={{ color: theme.textFaint }}>{c.label}</p>
            <p className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      <p className="font-[Oswald] text-sm uppercase tracking-wide mb-2" style={{ color: theme.textPrimary }}>Son Bildirimler</p>
      <div className="grid gap-2 md:grid-cols-2">
        {notifications.slice(0, 6).map((n) => (
          <div key={n.id} className="rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border, background: theme.surface, color: theme.textMuted }}>
            {n.desc} — {n.date}
          </div>
        ))}
        {notifications.length === 0 && <EmptyState icon={ClipboardList} title="Henüz kayıt yok" description="İlk bildirim geldiğinde burada görünecek." />}
      </div>
    </div>
  );
}
