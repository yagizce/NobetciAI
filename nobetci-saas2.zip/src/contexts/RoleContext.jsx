import { createContext, useContext, useState, useEffect } from "react";

const RoleContext = createContext(null);
const STORAGE_KEY = "nobetci-role";

export const ROLES = [
  { id: "worker", emoji: "👷", label: "Çalışan" },
  { id: "expert", emoji: "🦺", label: "Uzman" },
  { id: "employer", emoji: "👨‍💼", label: "İşveren" },
];

export function RoleProvider({ children }) {
  const [role, setRole] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || "worker";
    } catch {
      return "worker";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, role);
    } catch {
      // ignore
    }
  }, [role]);

  return <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>;
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within a RoleProvider");
  return ctx;
}
