// dashboardTrends — "Son 30 Gün Değişim" kartı için GERÇEK zaman-bazlı karşılaştırma.
// TrendsPanel.jsx'teki 6 dönemlik seyrin aksine (orada açıkça "temsili" işaretli), burada
// yalnızca gerçek zaman damgalı kayıtlar sayılır. Veri azsa/yoksa delta 0 çıkar — bu
// beklenen ve doğru davranıştır (bkz. DEVELOPMENT_RULES.md → General Rules, "emin
// olmadığın konularda varsayım yapma").
//
// fineKinney.date alanı "DD.MM.YYYY" (todayLabel() ile üretilir, bkz.
// risk-analysis/fineKinney/useFineKinneyEntries.js), ISO DEĞİLDİR — bu yüzden
// `toComparableDate` ile "YYYY-MM-DD"ye çevrilir. closedAt/completedAt/lastCheckDate
// zaten ISO'dur (types/index.js).

import { toComparableDate } from "./dateUtils.js";

function isoDateNDaysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function tomorrowISO() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

function inRange(comparableDate, start, end) {
  return Boolean(comparableDate) && comparableDate >= start && comparableDate < end;
}

/**
 * @param {import("../types/index.js").FineKinneyEntry[]} fineKinneyEntries
 * @param {import("../types/index.js").PeriodicCheck[]} periodicChecks
 * @param {import("../types/index.js").TrainingCompletion[]} trainingCompletionRecords
 * @returns {{
 *   newRisks: { current: number, previous: number, delta: number, goodDirection: "down" },
 *   closedRisks: { current: number, previous: number, delta: number, goodDirection: "up" },
 *   completedTrainings: { current: number, previous: number, delta: number, goodDirection: "up" },
 *   checksPerformed: { current: number, previous: number, delta: number, goodDirection: "up" },
 * }}
 */
export function computeLast30DayChange(fineKinneyEntries, periodicChecks, trainingCompletionRecords) {
  const windowEnd = tomorrowISO(); // bugünü dahil etmek için "yarın" sınırı (exclusive üst sınır)
  const currentStart = isoDateNDaysAgo(30);
  const previousStart = isoDateNDaysAgo(60);

  function countInWindows(items, getComparableDate) {
    let current = 0;
    let previous = 0;
    for (const item of items) {
      const d = getComparableDate(item);
      if (!d) continue;
      if (inRange(d, currentStart, windowEnd)) current += 1;
      else if (inRange(d, previousStart, currentStart)) previous += 1;
    }
    return { current, previous, delta: current - previous };
  }

  const newRisks = {
    ...countInWindows(fineKinneyEntries, (e) => toComparableDate(e.date)),
    goodDirection: "down",
  };

  const closedRisks = {
    ...countInWindows(fineKinneyEntries.filter((e) => e.closedAt), (e) => e.closedAt.slice(0, 10)),
    goodDirection: "up",
  };

  const completedTrainings = {
    ...countInWindows(trainingCompletionRecords.filter((c) => c.passed), (c) => c.completedAt.slice(0, 10)),
    goodDirection: "up",
  };

  // "Gerçekleşen kontrol" = son kontrol tarihi bu pencerede olan kayıtlar (bir kontrolün
  // fiilen yapıldığı an — nextDueDate değil, lastCheckDate esas alınır).
  const checksPerformed = {
    ...countInWindows(periodicChecks, (c) => c.lastCheckDate),
    goodDirection: "up",
  };

  return { newRisks, closedRisks, completedTrainings, checksPerformed };
}
