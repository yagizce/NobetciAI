export function nowLabel() {
  return new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

export function todayLabel() {
  return new Date().toLocaleDateString("tr-TR");
}

/**
 * Bugünün tarihi, "YYYY-MM-DD" (ISO, `<input type="date">` ile uyumlu) formatında.
 * Sprint 7.2.2: `new Date().toISOString().slice(0, 10)` deseni 3. kez tekrarlanacaktı
 * (constants/periodicCheck.js, utils/attentionItems.js) — buraya çıkarıldı. Önceki 2
 * kullanım, gereksiz refactor yapılmaması kuralı gereği DEĞİŞTİRİLMEDİ.
 * @returns {string}
 */
export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * "DD.MM.YYYY" (todayLabel formatı) → "YYYY-MM-DD" karşılaştırılabilir string.
 * Fine-Kinney tarih filtresi (input type="date", YYYY-MM-DD) ile date="DD.MM.YYYY"
 * alanını karşılaştırabilmek için kullanılır. Geçersiz/boş girişte null döner.
 * @param {string} trDateStr
 * @returns {string|null}
 */
export function toComparableDate(trDateStr) {
  if (!trDateStr) return null;
  const parts = trDateStr.split(".");
  if (parts.length !== 3) return null;
  const [day, month, year] = parts;
  if (!day || !month || !year) return null;
  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}
