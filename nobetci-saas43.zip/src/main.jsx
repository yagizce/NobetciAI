import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { ThemeProvider } from "./contexts/ThemeContext.jsx";
import { RoleProvider } from "./contexts/RoleContext.jsx";
import { LanguageProvider } from "./contexts/LanguageContext.jsx";
import { IsgDataProvider } from "./contexts/IsgDataContext.jsx";
import { ToastProvider } from "./contexts/ToastContext.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <ErrorBoundary>
    <ThemeProvider>
      <LanguageProvider>
        <ToastProvider>
          <RoleProvider>
            <IsgDataProvider>
              <BrowserRouter>
                <App />
              </BrowserRouter>
            </IsgDataProvider>
          </RoleProvider>
        </ToastProvider>
      </LanguageProvider>
    </ThemeProvider>
  </ErrorBoundary>
);

// PWA / Service Worker — v2, GÜVENLİ (network-first) tasarım. v1'in cache-first
// stratejisi bir beyaz ekran olayına yol açmıştı (bkz. CHANGELOG.md → "ACİL:
// Service Worker Beyaz Ekran Düzeltmesi"); o olayın ardından bir süre hiç SW
// kaydedilmiyordu (yalnızca eski kayıtları kaldıran bir "kill-switch" vardı).
// Artık v2 ile normal kayıt geri döndü — v2, HTML/JS/CSS için ASLA cache-first
// kullanmıyor (bkz. public/service-worker.js dosya başı yorumu), bu yüzden aynı
// hatanın tekrarlanması yapısal olarak mümkün değil.
//
// v1'in kill-switch'i (kayıtlı olan kullanıcılarda) kendi kendini zaten kaldırıp
// eski cache'lerini temizliyordu; bu register() çağrısı o kullanıcılarda normal
// şekilde v2'yi kurar. Burada AYRICA elle bir cache temizleme yapılmıyor — o iş
// artık service-worker.js'in kendi `activate` olayına ait (tek sorumluluk noktası).
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js").catch(() => {
      // Kayıt başarısız olursa uygulama normal (SW'siz) çalışmaya devam eder — sessiz geç.
    });
  });
}
