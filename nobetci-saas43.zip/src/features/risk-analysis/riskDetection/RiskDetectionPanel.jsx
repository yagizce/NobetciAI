import { useState, useMemo, useRef } from "react";
import { useRiskDetections } from "./useRiskDetections.js";
import { usePhotoDetection } from "./usePhotoDetection.js";
import { useCompanyOrgLists } from "../fineKinney/useCompanyOrgLists.js";
import { useToast } from "../../../contexts/ToastContext.jsx";
import { validateImageFile } from "../../../utils/fileValidation.js";
import RiskDetectionForm from "./RiskDetectionForm.jsx";
import RiskDetectionCard from "./RiskDetectionCard.jsx";
import RiskDetectionFilters from "./RiskDetectionFilters.jsx";
import Button from "../../../components/ui/Button.jsx";
import ToggleSwitch from "../../../components/ui/ToggleSwitch.jsx";
import EmptyState from "../../../components/EmptyState.jsx";
import Loading from "../../../components/Loading.jsx";
import { Plus, ShieldAlert, Camera } from "../../../components/icons/index.jsx";

const SUMMARY_ITEMS = [
  { key: "newCount", label: "Yeni", tone: "pending" },
  { key: "reviewingCount", label: "İncelemede", tone: "warning" },
  { key: "convertedCount", label: "Dönüştürüldü", tone: "success" },
  { key: "dismissedCount", label: "Reddedildi", tone: "neutral" },
];

/**
 * Phase 9.1 — Risk Tespiti (triage havuzu). Fine-Kinney'den BİLİNÇLİ olarak ayrı bir
 * sekme: burada toplanan kayıtlar ham/doğrulanmamış tespitlerdir, resmi risk kaydı
 * değildir (bkz. types/index.js → RiskDetection). Sabit kamera entegrasyonu henüz yok
 * (Phase 9.2) — bunun yerine tespitler üç yoldan biriyle oluşur: manuel giriş, "Demo:
 * Otomatik Simülasyon" (sistem periyodik olarak örnek tespit üretir) veya kullanıcının
 * kendi telefonuyla çektiği fotoğrafın AI analizi (bkz. usePhotoDetection.js — AI_ROADMAP.md
 * → "AI Vision" maddesinin karşılığı, kamera KURULUMU değil). Üçü de aynı veri modelini
 * kullanır; gerçek sabit kamera geldiğinde yalnızca dördüncü bir "source" (`"camera"`)
 * eklenmesi yeterli olacaktır.
 *
 * @param {{ onSendToFineKinney: (hazard: string, risk: string, extra?: object) => void }} props
 */
export default function RiskDetectionPanel({ theme, onSendToFineKinney, initialSearch }) {
  const {
    detections, allDetections, totalCount, stats, loaded,
    addDetection, updateStatus, removeDetection,
    search, setSearch, statusFilter, setStatusFilter, categoryFilter, setCategoryFilter,
    simulating, setSimulating,
  } = useRiskDetections(initialSearch);
  const { departments } = useCompanyOrgLists();
  const { showToast } = useToast();
  const { analyzing, error: photoError, photoDataUrl, suggestion, analyzePhoto, reset: resetPhoto } = usePhotoDetection();

  const [formOpen, setFormOpen] = useState(false);
  const photoInputRef = useRef(null);

  const departmentNameById = useMemo(() => {
    const map = {};
    for (const d of departments) map[String(d.id)] = d.name;
    return map;
  }, [departments]);

  async function handleManualAdd(category, location, departmentId, extra) {
    await addDetection(category, location, extra?.source || "manual", departmentId, extra);
    setFormOpen(false);
    resetPhoto();
  }

  function handleCancelForm() {
    setFormOpen(false);
    resetPhoto();
  }

  async function handlePhotoFile(e) {
    const file = e.target.files?.[0];
    e.target.value = ""; // aynı dosyanın tekrar seçilebilmesi için input'u sıfırla
    if (!file) return;

    const { valid, error } = await validateImageFile(file);
    if (!valid) {
      showToast(error, "error");
      return;
    }

    setFormOpen(true);
    analyzePhoto(file);
  }

  if (!loaded) return <Loading label="Risk tespitleri yükleniyor..." />;

  return (
    <div>
      <div className="rounded-xl border px-3.5 py-3 mb-4 flex items-center justify-between gap-3" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
        <div className="min-w-0">
          <p className="text-sm font-semibold" style={{ color: theme.textPrimary }}>Demo: Otomatik Simülasyon</p>
          <p className="text-[10.5px]" style={{ color: theme.textFaint }}>Gerçek kamera henüz bağlı değil — açıkken sistem periyodik olarak örnek bir tespit üretir.</p>
        </div>
        <ToggleSwitch checked={simulating} onChange={setSimulating} theme={theme} />
      </div>

      {allDetections.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          {SUMMARY_ITEMS.map((item) => (
            <div key={item.key} className="rounded-xl border px-3 py-2.5" style={{ borderColor: theme.border, background: theme.surface }}>
              <p className="text-lg font-bold leading-none" style={{ color: theme.textPrimary }}>{stats[item.key]}</p>
              <p className="text-[10px] mt-1" style={{ color: theme.textFaint }}>{item.label}</p>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-end gap-2 mb-3">
        <button onClick={() => photoInputRef.current?.click()} disabled={analyzing} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
          style={{ background: theme.surfaceAlt, color: theme.accent, border: `1px solid ${theme.accent}` }}>
          <Camera style={{ fontSize: "13px" }} /> Fotoğrafla Tespit Et
        </button>
        <input ref={photoInputRef} type="file" accept="image/*" capture="environment" onChange={handlePhotoFile} style={{ display: "none" }} />
        <Button size="sm" onClick={() => (formOpen ? handleCancelForm() : setFormOpen(true))} className="flex items-center gap-1.5">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Tespit Ekle
        </Button>
      </div>

      {formOpen && analyzing && (
        <div className="rounded-xl border px-3.5 py-4 mb-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
          <Loading label="🤖 Fotoğraf analiz ediliyor..." />
        </div>
      )}

      {formOpen && !analyzing && (
        <>
          {photoError && (
            <div className="rounded-lg px-3 py-2 mb-2 text-xs" style={{ background: theme.emergencyBg, color: theme.emergencyText }}>
              {photoError} Kategoriyi elle seçip devam edebilirsin.
            </div>
          )}
          <RiskDetectionForm
            theme={theme}
            onSubmit={handleManualAdd}
            onCancel={handleCancelForm}
            initialCategory={suggestion?.category}
            initialNote={suggestion?.note}
            photoDataUrl={photoDataUrl}
          />
        </>
      )}

      {totalCount > 0 && (
        <RiskDetectionFilters
          theme={theme}
          search={search}
          onSearchChange={setSearch}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          categoryFilter={categoryFilter}
          onCategoryFilterChange={setCategoryFilter}
        />
      )}

      {totalCount === 0 ? (
        <EmptyState icon={ShieldAlert} title="Henüz risk tespiti yok" description="Sahada gördüğünüz bir tehlikeyi manuel ekleyebilir, ya da demo simülasyonunu açarak sistemin nasıl çalışacağını görebilirsiniz." />
      ) : detections.length === 0 ? (
        <EmptyState icon={ShieldAlert} title="Eşleşen sonuç yok" description="Arama veya filtre kriterlerini değiştirmeyi deneyin." />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {detections.map((d) => (
            <RiskDetectionCard
              key={d.id}
              detection={d}
              theme={theme}
              departmentName={d.departmentId ? departmentNameById[String(d.departmentId)] : null}
              onUpdateStatus={updateStatus}
              onDelete={removeDetection}
              onSendToFineKinney={onSendToFineKinney}
            />
          ))}
        </div>
      )}
    </div>
  );
}
