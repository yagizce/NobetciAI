import { useState } from "react";
import { RISK_DETECTION_CATEGORIES, MOCK_DETECTION_LOCATIONS } from "../../../constants/riskDetection.js";
import { useCompanyOrgLists } from "../fineKinney/useCompanyOrgLists.js";
import Button from "../../../components/ui/Button.jsx";

/**
 * "Yeni Tespit Ekle" — kamera henüz olmadığı için Uzman/İşveren'in sahada gördüğü bir
 * tehlikeyi manuel olarak, gerçek kamera tespiti ile AYNI veri modeline (kategori +
 * konum) girebilmesi içindir. Bilinçli olarak Fine-Kinney formu kadar detaylı DEĞİL —
 * bu yalnızca bir triage kaydı, ayrıntı Fine-Kinney'e dönüştürülünce girilir.
 *
 * `initialCategory`/`initialNote`/`photoDataUrl` doluysa (bkz. usePhotoDetection.js),
 * form AI'nin fotoğraftan çıkardığı öneriyle önceden doldurulmuş açılır — kullanıcı
 * yine de kategoriyi/notu değiştirebilir, konum ise AI tarafından bilinemediği için
 * (fiziksel yer adı) her zaman elle girilir.
 *
 * @param {{
 *   theme: object,
 *   onSubmit: (category: string, location: string, departmentId: string|null, extra?: {hazardNote?: string, photoDataUrl?: string, source?: string}) => void,
 *   onCancel: () => void,
 *   initialCategory?: string|null, initialNote?: string|null, photoDataUrl?: string|null,
 * }} props
 */
export default function RiskDetectionForm({ theme, onSubmit, onCancel, initialCategory = null, initialNote = null, photoDataUrl = null }) {
  const { departments } = useCompanyOrgLists();
  const [category, setCategory] = useState(initialCategory || RISK_DETECTION_CATEGORIES[0].value);
  const [location, setLocation] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [hazardNote, setHazardNote] = useState(initialNote || "");

  function handleSubmit() {
    if (!location.trim()) return;
    onSubmit(category, location.trim(), departmentId || null, {
      hazardNote: hazardNote.trim(),
      photoDataUrl: photoDataUrl || undefined,
      source: photoDataUrl ? "photo" : "manual",
    });
  }

  return (
    <div className="rounded-xl border px-3.5 py-3 mb-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
      {photoDataUrl && (
        <div className="flex items-start gap-2.5 mb-3 rounded-lg border px-2.5 py-2" style={{ borderColor: theme.border, background: theme.surface }}>
          <img src={photoDataUrl} alt="Analiz edilen fotoğraf" className="w-14 h-14 rounded-md object-cover shrink-0" />
          <p className="text-[10.5px]" style={{ color: theme.textFaint }}>
            🤖 AI önerisi aşağıda dolduruldu — gözden geçirip düzenleyebilir, konumu girmen gerekiyor.
          </p>
        </div>
      )}

      <div className="grid gap-2 mb-2 sm:grid-cols-2">
        <select value={category} onChange={(e) => setCategory(e.target.value)}
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
          {RISK_DETECTION_CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
        </select>
        <input
          list="risk-detection-locations"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="Konum (örn. Depo B — Giriş)"
          className="text-sm rounded-lg px-3 py-2 outline-none border"
          style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
        />
        <datalist id="risk-detection-locations">
          {MOCK_DETECTION_LOCATIONS.map((loc) => <option key={loc} value={loc} />)}
        </datalist>
      </div>

      <label className="block mb-2">
        <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Not (opsiyonel)</span>
        <textarea value={hazardNote} onChange={(e) => setHazardNote(e.target.value)} rows={2}
          placeholder="Tespitle ilgili kısa bir not..."
          className="w-full text-sm rounded-lg px-3 py-2 outline-none border resize-y" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
      </label>

      <label className="block mb-3">
        <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Departman (opsiyonel)</span>
        <select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}
          className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
          <option value="">Belirtilmedi</option>
          {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>

      <div className="flex gap-2">
        <Button variant="secondary" onClick={onCancel} className="flex-1">Vazgeç</Button>
        <Button onClick={handleSubmit} disabled={!location.trim()} className="flex-1">Ekle</Button>
      </div>
    </div>
  );
}
