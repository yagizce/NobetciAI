// riskDetectionService — Risk Tespiti (triage havuzu) depolaması, diğer tüm servisler
// gibi soyut dataProvider üzerinden (bkz. dataProvider.js). Fine-Kinney'den ayrı bir
// koleksiyon ("riskDetections") — bilinçli tasarım kararı, bkz. types/index.js → RiskDetection.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").RiskDetection[]>}
 */
export async function getRiskDetections() {
  return dataProvider.getAll("riskDetections");
}

/**
 * @param {import("../types/index.js").RiskDetection} detection
 */
export async function saveRiskDetection(detection) {
  const companyId = detection.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("riskDetections", { ...detection, companyId });
}

/**
 * @param {number} id
 */
export async function deleteRiskDetection(id) {
  return dataProvider.remove("riskDetections", id);
}
