// trainingCourseSettingsService — her kurs için ŞİRKET ÇAPINDA (kişiye özel değil) bir
// "son tarih" saklar. Sistemde her çalışan her kursa örtük olarak "atanmış" sayılır
// (bkz. trainingStatus.js — ayrı bir TrainingAssignment kaydı yoktur), bu yüzden
// kişi-bazlı değil kurs-bazlı bir son tarih modeli, mevcut mimariyle tutarlıdır.
// id = courseId (constants/trainingCourses.js → TRAINING_COURSES[].id).

import { dataProvider } from "./dataProvider.js";

/**
 * @returns {Promise<Array<{id: string, dueDate: string|null}>>}
 */
export async function getTrainingCourseSettings() {
  return dataProvider.getAll("trainingCourseSettings");
}

/**
 * @param {string} courseId
 * @param {string|null} dueDate - ISO tarih (YYYY-MM-DD) veya null (son tarihi kaldırır)
 */
export async function saveTrainingCourseDueDate(courseId, dueDate) {
  return dataProvider.upsert("trainingCourseSettings", { id: courseId, dueDate });
}
