import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { validateBackup } from "./backupService.js";

describe("validateBackup", () => {
  test("geçerli bir yedek nesnesi için valid: true döner", () => {
    const backup = { formatVersion: 1, exportedAt: "2026-01-01T00:00:00.000Z", data: { companies: [], employees: [{ id: 1, fullName: "Ahmet" }] } };
    assert.deepEqual(validateBackup(backup), { valid: true });
  });

  test("null/undefined/nesne olmayan veri için hata döner", () => {
    assert.equal(validateBackup(null).valid, false);
    assert.equal(validateBackup(undefined).valid, false);
    assert.equal(validateBackup("bir metin").valid, false);
    assert.equal(validateBackup(42).valid, false);
  });

  test("formatVersion eksik veya farklıysa hata döner", () => {
    assert.equal(validateBackup({ data: {} }).valid, false);
    assert.equal(validateBackup({ formatVersion: 999, data: {} }).valid, false);
  });

  test("data alanı eksikse hata döner", () => {
    assert.equal(validateBackup({ formatVersion: 1 }).valid, false);
    assert.equal(validateBackup({ formatVersion: 1, data: "yanlış tip" }).valid, false);
  });

  test("bir store'un verisi dizi değilse hata döner", () => {
    const result = validateBackup({ formatVersion: 1, data: { employees: "dizi değil" } });
    assert.equal(result.valid, false);
    assert.ok(result.error.includes("employees"));
  });

  test("data içinde hiç store olmaması (boş yedek) geçerli sayılır", () => {
    assert.deepEqual(validateBackup({ formatVersion: 1, data: {} }), { valid: true });
  });

  test("bilinmeyen (STORES listesinde olmayan) fazladan bir alan görmezden gelinir", () => {
    // İleride eski bir yedek dosyasında artık var olmayan bir store adı kalmış olabilir —
    // bu durumun restore'u BOZMAMASI gerekir, yalnızca o alan kullanılmaz.
    const result = validateBackup({ formatVersion: 1, data: { bilinmeyenStore: [1, 2, 3] } });
    assert.equal(result.valid, true);
  });
});
