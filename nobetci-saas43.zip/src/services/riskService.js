// riskService — Fine-Kinney risk assessment storage, via the abstract dataProvider.
// `scoreRisk()` now calls the AI proxy (chatService) to suggest an initial Fine-Kinney
// score from free-text hazard/risk description — see its jsdoc below. Free-text
// conversational risk analysis (the questioning AI risk engine) still happens via
// chatService directly from RiskAnalysisPage — that's intentional, it's a different,
// conversational flow rather than structured Fine-Kinney data entry.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";
import { sendChatMessage } from "./chatService.js";
import { INITIAL_SCORE_PROMPT, parseInitialScoreSuggestion } from "../constants/systemPrompt.js";

/**
 * @returns {Promise<import("../types/index.js").FineKinneyEntry[]>}
 */
export async function getFineKinneyEntries() {
  return dataProvider.getAll("fineKinney");
}

/**
 * @param {import("../types/index.js").FineKinneyEntry} entry
 */
export async function saveFineKinneyEntry(entry) {
  const companyId = entry.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("fineKinney", { ...entry, companyId });
}

/**
 * @param {number} id
 */
export async function deleteFineKinneyEntry(id) {
  return dataProvider.remove("fineKinney", id);
}

/**
 * Serbest metinden (yalnızca tehlike + risk tanımı) önlem öncesi başlangıç Fine-Kinney
 * Olasılık/Maruziyet/Şiddet değerlerini AI ile önerir — AI_ROADMAP.md → "scoreRisk()
 * gerçek implementasyonu" maddesinin karşılığı. Bu, kullanıcının formu ölçek tablolarını
 * ezbere okumadan doldurmaya başlamasını sağlayan bir ÖNERİDİR; hiçbir değer otomatik/
 * sessizce kaydedilmez — çağıran taraf (bkz. useInitialRiskScore.js) dönen değerleri
 * yalnızca kullanıcının düzenleyebileceği form alanlarına yazar.
 * @param {{hazard: string, risk: string}} input
 * @returns {Promise<{probability: number|null, frequency: number|null, severity: number|null, reasoning: string|null}>}
 */
export async function scoreRisk({ hazard, risk }) {
  const reply = await sendChatMessage({
    system: INITIAL_SCORE_PROMPT,
    max_tokens: 300,
    messages: [{ role: "user", content: `Tehlike: ${hazard}\nRisk: ${risk || "belirtilmedi"}` }],
  });
  return parseInitialScoreSuggestion(reply);
}

/**
 * Sprint 5A: Risk Detay Sayfası alt-sekmeleri (Düzeltici Faaliyetler, Ek Dosyalar, Notlar,
 * Risk Geçmişi) mevcut tekil form akışından (saveFineKinneyEntry) BAĞIMSIZ, hafif bir
 * güncelleme yolu kullanır — sadece belirtilen alanları mevcut kayıtla birleştirir.
 * Bu, ana Fine-Kinney formunu (ve onun score/history mantığını) hiç etkilemez.
 * @param {number} id
 * @param {object} patch - Birleştirilecek kısmi alanlar
 * @returns {Promise<import("../types/index.js").FineKinneyEntry|null>}
 */
export async function patchFineKinneyEntry(id, patch) {
  const current = await dataProvider.getById("fineKinney", id);
  if (!current) return null;
  const updated = { ...current, ...patch };
  await dataProvider.upsert("fineKinney", updated);
  return updated;
}
