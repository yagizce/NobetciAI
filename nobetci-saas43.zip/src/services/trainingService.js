import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").TrainingCompletion[]>}
 */
export async function getTrainingCompletions() {
  return dataProvider.getAll("trainingCompletions");
}

/**
 * @param {{ courseId: string, employeeName: string, watchedFullVideo: boolean, quizScore: number, passed: boolean }} completion
 * @returns {Promise<import("../types/index.js").TrainingCompletion>}
 */
export async function saveTrainingCompletion(completion) {
  const companyId = await getPrimaryCompanyId();
  const record = {
    id: Date.now(),
    companyId,
    completedAt: new Date().toISOString(),
    ...completion,
  };
  return dataProvider.upsert("trainingCompletions", record);
}

/**
 * @returns {Promise<import("../types/index.js").TrainingProgress[]>}
 */
export async function getTrainingProgress() {
  return dataProvider.getAll("trainingProgress");
}

/**
 * Bir (kurs, çalışan) çifti için TEK ilerleme kaydını günceller (upsert) — "kaldığı
 * yerden devam et" ve ilerleme yüzdesi bu kayıttan hesaplanır. Sınav sonucundan
 * (saveTrainingCompletion) bilinçli olarak ayrı bir kalıcılık yoludur.
 * @param {{ courseId: string, employeeName: string, positionSeconds: number, durationSeconds: number }} progress
 * @returns {Promise<import("../types/index.js").TrainingProgress>}
 */
export async function saveTrainingProgressRecord(progress) {
  const companyId = await getPrimaryCompanyId();
  const record = {
    id: `${progress.courseId}::${progress.employeeName}`,
    companyId,
    updatedAt: new Date().toISOString(),
    ...progress,
  };
  return dataProvider.upsert("trainingProgress", record);
}
