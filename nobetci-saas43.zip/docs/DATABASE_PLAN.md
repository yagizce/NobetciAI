# Veritabanı Planı

Bu doküman, Nöbetçi backend'e geçtiğinde **Supabase (Postgres)** üzerinde kullanılacak
veri modelini tanımlar. Yalnızca **tabloları ve aralarındaki ilişkileri** açıklar —
SQL şeması veya uygulama kodu içermez. Mevcut (IndexedDB tabanlı) durum için bkz.
[ARCHITECTURE.md](./ARCHITECTURE.md) → "Mock Veri Yapısı".

> Bu plan **yalnızca planlamadır.** Uygulanması kullanıcı açık onayı gerektirir
> (bkz. [DEVELOPMENT_RULES.md](./DEVELOPMENT_RULES.md) → "Architecture").

---

## Çok Kiracılılık İlkesi

Kiracıya (firmaya) özel her tablo bir `companyId` alanı taşır. Gerçek izolasyon,
Postgres **Row Level Security (RLS)** ile sağlanır: bir kullanıcı yalnızca kendi
`companyId`'sine ait satırları görebilir/değiştirebilir. Bu ilke, çok kiracılı
olan her tablonun tanımında ayrıca belirtilmemiştir — aksi belirtilmedikçe geçerli
kabul edilir. Yalnızca genel/mevzuat niteliğindeki veriler (örn. tüm firmalara açık
Bilgi Kütüphanesi dokümanları) `companyId` alanını boş bırakabilir.

Tablolar altı kategoride gruplanmıştır: **Kimlik & Erişim**, **Organizasyon**,
**Risk Yönetimi**, **Bilgi & İletişim**, **Operasyonel Takip**, **Yapay Zeka**.

---

## Kategori 1: Kimlik, Rol ve Erişim

### Users

Sisteme giriş yapabilen her kişinin hesabı. Supabase Auth ile birebir eşleşir —
tablo kimliği doğrudan `auth.users` kimliğidir.

**Alanlar:** ad-soyad, e-posta, telefon, profil fotoğrafı, unvan, hesap durumu
(aktif/pasif), oluşturulma tarihi.

**İlişkiler:**
- Bir Kullanıcı, `UserRoles` ilişki tablosu üzerinden **birden fazla Firmada
  farklı Role** sahip olabilir (OSGB/danışman senaryosu — tek kişi birden fazla
  firmayı yönetebilir).
- Bir Kullanıcı, en fazla bir Employee kaydına bağlanabilir (bir kullanıcı aynı
  zamanda bir personel kaydına karşılık gelebilir, ama her personelin hesabı
  olmak zorunda değildir).

### Roles

Sistemdeki sabit rol tanımları (örn. İSG Uzmanı, İşveren, Çalışan, Firma Yöneticisi,
Sistem Yöneticisi). Referans/sabit veri niteliğindedir.

**Alanlar:** rol anahtarı, görünen ad, açıklama.

**İlişkiler:**
- `UserRoles` ilişki tablosu üzerinden Users ile **çoka-çok** bağlanır; bu ilişki
  ayrıca `companyId` taşır — bir kullanıcının rolü **firma bazlıdır**, global değildir.
- `RolePermissions` ilişki tablosu üzerinden Permissions ile **çoka-çok** bağlanır.

### Permissions

İnce taneli yetki tanımları (örn. "risk oluşturma", "risk onaylama", "firma
yönetimi"). Referans/sabit veri niteliğindedir.

**Alanlar:** izin anahtarı, görünen ad, ait olduğu modül.

**İlişkiler:**
- `RolePermissions` ilişki tablosu üzerinden Roles ile **çoka-çok** bağlanır.

---

## Kategori 2: Organizasyon

### Companies

Platformdaki her firma/kiracı.

**Alanlar:** firma adı, vergi no, sektör, risk sınıfı (az/tehlikeli/çok tehlikeli),
adres, iletişim bilgisi, oluşturulma tarihi.

**İlişkiler:** Branches, Departments, Employees, Risks, KnowledgeDocuments (firmaya
özel olanlar), Notifications, Audits, Trainings, Equipment, PeriodicInspections
tablolarının tümü **bire-çok** olarak Companies'e bağlıdır (`companyId`).

### Branches

Bir firmaya ait şubeler.

**Alanlar:** şube adı, adres, ait olduğu firma.

**İlişkiler:** Companies ile **çoka-bir**. Employees ve Risks tablolarından
**bire-çok** referans alır (bir çalışan/risk isteğe bağlı olarak bir şubeye
bağlanabilir).

### Departments

Bir firmaya ait departmanlar.

**Alanlar:** departman adı, ait olduğu firma.

**İlişkiler:** Companies ile **çoka-bir**. Employees ve Risks tablolarından
**bire-çok** referans alır.

### Employees

Bir firmadaki personel kaydı (illa sisteme giriş yapması gerekmez — HR kaydı
niteliğindedir).

**Alanlar:** ad-soyad, unvan, telefon, işe başlama tarihi, ait olduğu firma/şube/
departman, bağlı kullanıcı hesabı (varsa).

**İlişkiler:**
- Companies, Branches, Departments ile **çoka-bir**.
- Users ile **bire-bir, isteğe bağlı** (her personelin hesabı olmayabilir).
- Risks (sorumlu kişi), CorrectiveActions (sorumlu kişi), Trainings,
  PeriodicInspections (sorumlu kişi) tablolarından **bire-çok** referans alır.

---

## Kategori 3: Risk Yönetimi

### Risks

Fine-Kinney risk değerlendirme kayıtları (mevcut IndexedDB'deki `fineKinney`
koleksiyonunun karşılığı).

**Alanlar:** tehlike tanımı, risk açıklaması, olasılık/maruziyet/şiddet puanları,
toplam skor, risk seviyesi, alınacak önlem, sorumlu, termin tarihi, durum, öncelik,
tamamlanma yüzdesi, artık risk puanları/skoru, kapanma tarihi, ait olduğu firma/
şube/departman, oluşturan kullanıcı.

**İlişkiler:**
- Companies, Branches, Departments ile **çoka-bir**.
- Employees ile **çoka-bir** (sorumlu kişi).
- Users ile **çoka-bir** (oluşturan kişi).
- RiskAttachments, CorrectiveActions, RiskHistory tablolarından **bire-çok**
  referans alır.

### RiskAttachments

Bir riske eklenen dosyalar (fotoğraf, PDF, Word, Excel).

**Alanlar:** dosya adı, dosya türü, depolama yolu, ait olduğu risk, ekleyen
kullanıcı, eklenme tarihi.

**İlişkiler:** Risks ile **çoka-bir**. Users ile **çoka-bir** (ekleyen kişi).
Planlanan Vision AI özelliği (bkz. [AI_ROADMAP.md](./AI_ROADMAP.md)) bu tablodaki
kayıtları girdi olarak kullanacaktır.

### CorrectiveActions

Bir riskle ilişkili düzeltici/önleyici faaliyetler (bire-çok — bir risk için
birden fazla faaliyet olabilir).

**Alanlar:** faaliyet başlığı, açıklama, sorumlu, termin tarihi, öncelik, durum,
tamamlanma yüzdesi, oluşturulma tarihi, ait olduğu risk.

**İlişkiler:** Risks ile **çoka-bir**. Employees ile **çoka-bir** (sorumlu kişi).

### RiskHistory

Bir riskin yaşam döngüsü boyunca gerçekleşen olayların kronolojik kaydı (oluşturma,
güncelleme, dosya ekleme, faaliyet tamamlama, kapatma).

**Alanlar:** olay türü, açıklama, ait olduğu risk, aksiyonu yapan kullanıcı,
zaman damgası.

**İlişkiler:** Risks ile **çoka-bir**. Users ile **çoka-bir** (aksiyonu yapan
kişi). Bu tablo, genel `Audits` tablosundan **bilinçli olarak ayrıdır** — riske
özel, kullanıcı arayüzünde doğrudan gösterilen bir zaman çizelgesi sağlar; Audits
ise sistem geneli teknik denetim kaydıdır.

---

## Kategori 4: Bilgi ve İletişim

### KnowledgeDocuments

Bilgi Kütüphanesi doküman kayıtları (mevzuat, Fine-Kinney kılavuzları, risk
raporları, periyodik kontrol formları, KKD rehberleri, acil durum planları,
eğitim materyalleri, firma dokümanları).

**Alanlar:** başlık, özet, içerik/kaynak metni, kategori, doküman türü, etiketler,
depolama yolu, güncellenme tarihi, ait olduğu firma (mevzuat gibi genel dokümanlar
için boş bırakılabilir).

**İlişkiler:** Companies ile **çoka-bir, isteğe bağlı** (firmaya özel dokümanlar
için dolu, genel/mevzuat dokümanları için boş). Planlanan RAG özelliği (bkz.
[AI_ROADMAP.md](./AI_ROADMAP.md)) bu tabloyu AI yanıtları için kaynak olarak
kullanacaktır.

### Notifications

Uygulama içi bildirimler — hem çalışan↔uzman/işveren iş akışı bildirimlerini
(örn. ramak kala bildirimi) hem de sistem olaylarını (örn. "yeni risk onaylandı")
tek tabloda, bir `tür` alanıyla ayırt eder.

**Alanlar:** tür (iş akışı/sistem), başlık, mesaj, gönderen, hedef (kullanıcı veya
rol), durum (okunmadı/okundu/onaylandı), oluşturulma tarihi, ait olduğu firma.

**İlişkiler:** Companies ile **çoka-bir**. Users ile **çoka-bir** (gönderen ve
hedef için iki ayrı referans).

### Audits

Sistem genelinde kritik işlemlerin teknik denetim kaydı (oluşturma, güncelleme,
silme, onay).

**Alanlar:** işlem türü, açıklama, ilgili kayıt türü ve kimliği, aksiyonu yapan
kullanıcı, zaman damgası, ait olduğu firma.

**İlişkiler:** Companies ile **çoka-bir**. Users ile **çoka-bir**. `ilgili kayıt
türü/kimliği` alanı üzerinden Risks, Employees, Companies gibi herhangi bir
tabloya **çok biçimli (polymorphic)** referans verir.

---

## Kategori 5: Operasyonel Takip

### Trainings

Personel eğitim kayıtları. **Bugün kısmi bir karşılığı var:** IndexedDB'de İKİ ayrı
koleksiyon — `trainingCompletions` (sınav denemesi sonucu) ve `trainingProgress`
(video izleme ilerlemesi, "kaldığı yerden devam et" için — Sprint 7.2.1). Bu ikisi
bilinçli olarak ayrı tutuluyor: biri "değerlendirme", diğeri "izleme" kaydı (bkz.
`RiskHistory`/`Audits` ayrımıyla aynı gerekçe, yukarıda). Kurs tanımları (video,
sınav soruları) henüz bir tabloda değil, statik sabit olarak
(`constants/trainingCourses.js`) tutuluyor — bir "kurs oluşturma" arayüzü yok.
Supabase'e geçişte üçü ayrılacak: `Trainings` (kurs tanımı), `TrainingCompletions`
(sınav sonucu) ve `TrainingProgress` (video izleme ilerlemesi).

**Alanlar (TrainingCompletions):** kurs referansı, personel adı, video tamamlandı mı,
sınav puanı, geçti mi, tamamlanma tarihi, ait olduğu firma.

**Alanlar (TrainingProgress):** kurs referansı, personel adı, izlenen saniye,
video süresi, güncellenme tarihi, ait olduğu firma. Her (kurs, personel) çifti
için tek kayıt.

**İlişkiler:** Employees ile **çoka-bir**. Companies ile **çoka-bir**.

### Equipment

Ekipman/QR kayıtları (mevcut `equipment` koleksiyonunun karşılığı).

**Alanlar:** ekipman adı, QR kodu, tür, son kontrol tarihi, ait olduğu firma/şube.

**İlişkiler:** Companies, Branches ile **çoka-bir**. PeriodicInspections'tan
**bire-çok** referans alır.

### PeriodicInspections

Ekipman/tesisat periyodik kontrol kayıtları (mevcut `periodicChecks`
koleksiyonunun karşılığı).

**Alanlar:** kontrol türü, son kontrol tarihi, bir sonraki kontrol tarihi, durum,
sorumlu, ait olduğu firma ve (varsa) ekipman.

**İlişkiler:** Companies ile **çoka-bir**. Equipment ile **çoka-bir, isteğe
bağlı** (bazı kontroller belirli bir ekipmana değil, genel tesisata aittir).
Employees ile **çoka-bir** (sorumlu kişi).

---

## Kategori 6: Yapay Zeka

### AIHistory

AI Copilot ile yapılan her etkileşimin (sohbet, Fine-Kinney önerisi, gelecekte
Vision AI/RAG sorguları) izlenebilir kaydı — denetlenebilirlik ve gelecekteki
kalite iyileştirmesi için.

**Alanlar:** modül (sohbet/Fine-Kinney önerisi/vision/rag), istek özeti, yanıt
özeti, ilişkili kayıt türü ve kimliği (varsa, örn. hangi Risk için öneri
istendiği), oluşturulma tarihi, ait olduğu kullanıcı ve firma.

**İlişkiler:** Users ile **çoka-bir**. Companies ile **çoka-bir**. `ilişkili
kayıt` alanı üzerinden Risks gibi tablolara **çok biçimli (polymorphic)**
referans verebilir.

---

## İlişki Özeti

- **Companies**, tüm kiracıya özel verinin kök noktasıdır; Branches, Departments,
  Employees doğrudan ona bağlanır.
- **Users**, kimliktir; **Employees** ise organizasyondaki bir kişiyi temsil eder.
  İkisi bağımsızdır ve isteğe bağlı olarak birbirine bağlanır — her kullanıcının
  personel kaydı, her personelin kullanıcı hesabı olmak zorunda değildir.
- **Roles/Permissions**, kullanıcıdan bağımsız, sabit referans veridir; kullanıcıya
  bağlanması her zaman **firma bazlı** bir ilişki (`UserRoles`) üzerinden olur —
  bu, tek bir kullanıcının birden fazla firmayı farklı rollerle yönetebilmesini
  (OSGB senaryosu) mümkün kılar.
- **Risks**, modülün merkezidir; RiskAttachments, CorrectiveActions ve
  RiskHistory ona bağlı **alt kayıt** tablolarıdır — bugün IndexedDB'de bu üçü
  Risk kaydının içine gömülü dizi olarak tutulur, ilişkisel modelde ayrı
  tablolara ayrılır.
- **KnowledgeDocuments**, tek tablo içinde hem genel (mevzuat) hem firmaya özel
  içeriği `companyId`'nin boş/dolu olmasıyla ayırt eder.
- **Audits** ve **RiskHistory**, kasıtlı olarak ayrı tutulur: biri sistem geneli
  teknik denetim, diğeri kullanıcıya gösterilen risk bazlı zaman çizelgesidir.

## Bu Plan Ne Zaman Uygulanır

Bu doküman yalnızca **plandır**; herhangi bir tablo, migrasyon ya da Supabase
istemci kodu, kullanıcı açık onayı olmadan oluşturulmaz. Uygulama başladığında
[SPRINTS.md](./SPRINTS.md) ve [CHANGELOG.md](./CHANGELOG.md) güncellenir.
