import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { ThemeProvider } from "./contexts/ThemeContext.jsx";
import { RoleProvider } from "./contexts/RoleContext.jsx";
import { LanguageProvider } from "./contexts/LanguageContext.jsx";
import { IsgDataProvider } from "./contexts/IsgDataContext.jsx";
import { ToastProvider } from "./contexts/ToastContext.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <ErrorBoundary>
    <ThemeProvider>
      <LanguageProvider>
        <ToastProvider>
          <RoleProvider>
            <IsgDataProvider>
              <BrowserRouter>
                <App />
              </BrowserRouter>
            </IsgDataProvider>
          </RoleProvider>
        </ToastProvider>
      </LanguageProvider>
    </ThemeProvider>
  </ErrorBoundary>
);

// PWA / Service Worker GEÇİCİ OLARAK DEVRE DIŞI (bkz. CHANGELOG.md).
// Artık hiçbir yeni Service Worker kaydı yapılmıyor. Aşağıdaki blok, önceki sürümlerde
// zaten bir Service Worker kaydetmiş kullanıcıların tarayıcılarındaki kaydı proaktif
// olarak kaldırır ve bu uygulamanın oluşturduğu eski cache'leri temizler — böylece
// Vite'ın yeni build'lerinde üretilen hash'li JS dosyaları her zaman doğrudan ağdan
// (network) çekilir, eski/silinmiş chunk dosyalarına referans veren bayat bir paket
// asla sunulmaz.
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    registrations.forEach((registration) => registration.unregister());
  }).catch(() => {});
}
if ("caches" in window) {
  caches.keys().then((keys) => {
    keys.filter((k) => k.startsWith("nobetci-isg-")).forEach((k) => caches.delete(k));
  }).catch(() => {});
}
