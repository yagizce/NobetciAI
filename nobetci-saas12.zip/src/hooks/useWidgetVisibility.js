import { useLocalStorage } from "./useLocalStorage.js";

// Dashboard'daki tüm widget'ların kayıtlı listesi — sırayla render edilir. Yeni bir
// widget eklemek için buraya bir satır eklemek yeterli, görünürlük altyapısı otomatik
// çalışır.
export const DASHBOARD_WIDGETS = [
  { id: "safetyScore", label: "Güvenlik Skoru" },
  { id: "executiveSummary", label: "Yönetici Özeti" },
  { id: "kpiCards", label: "KPI Kartları" },
  { id: "trends", label: "Trend Analizi" },
  { id: "correctiveActions", label: "Düzeltici Faaliyetler" },
  { id: "riskAnalyses", label: "Risk Analizleri" },
  { id: "employees", label: "Çalışanlar" },
  { id: "education", label: "Eğitimler" },
  { id: "recentActivity", label: "Son Aktiviteler" },
];

const STORAGE_KEY = "nobetci-dashboard-widget-visibility";

function defaultVisibility() {
  return Object.fromEntries(DASHBOARD_WIDGETS.map((w) => [w.id, true]));
}

/**
 * @returns {{ visibility: Record<string, boolean>, isVisible: (id: string) => boolean, toggleWidget: (id: string) => void }}
 */
export function useWidgetVisibility() {
  const [visibility, setVisibility] = useLocalStorage(STORAGE_KEY, defaultVisibility());

  function isVisible(id) {
    return visibility[id] !== false;
  }

  function toggleWidget(id) {
    setVisibility({ ...visibility, [id]: !isVisible(id) });
  }

  return { visibility, isVisible, toggleWidget };
}
