import Modal from "./Modal.jsx";
import Button from "./Button.jsx";
import { useTheme } from "../../contexts/ThemeContext.jsx";

/**
 * @param {{ open: boolean, title?: string, message: string, confirmLabel?: string, cancelLabel?: string, onConfirm: () => void, onCancel: () => void, danger?: boolean }} props
 */
export default function ConfirmDialog({ open, title = "Emin misiniz?", message, confirmLabel = "Onayla", cancelLabel = "Vazgeç", onConfirm, onCancel, danger = false }) {
  const { theme } = useTheme();
  return (
    <Modal open={open} onClose={onCancel} title={title}>
      <p className="text-sm mb-4" style={{ color: theme.textMuted }}>{message}</p>
      <div className="flex gap-2">
        <Button variant="secondary" onClick={onCancel} className="flex-1">{cancelLabel}</Button>
        <Button variant={danger ? "danger" : "primary"} onClick={onConfirm} className="flex-1">{confirmLabel}</Button>
      </div>
    </Modal>
  );
}
