import { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar.jsx";
import Header from "./Header.jsx";
import { useTheme } from "../contexts/ThemeContext.jsx";
import { useIsgData } from "../contexts/IsgDataContext.jsx";

export default function Layout() {
  const { theme } = useTheme();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const { notifications } = useIsgData();
  const pendingCount = notifications.filter((n) => n.status !== "approved").length;

  return (
    <div className="flex min-h-screen" style={{ background: theme.pageBg }}>
      <Sidebar mobileOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header onMenuClick={() => setMobileNavOpen(true)} pendingCount={pendingCount} />
        <main className="flex-1 min-w-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
