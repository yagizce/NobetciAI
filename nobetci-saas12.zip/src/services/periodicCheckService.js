import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").PeriodicCheck[]>}
 */
export async function getPeriodicChecks() {
  return dataProvider.getAll("periodicChecks");
}

/**
 * @param {import("../types/index.js").PeriodicCheck} check
 */
export async function savePeriodicCheck(check) {
  const companyId = check.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("periodicChecks", { ...check, companyId });
}

/**
 * @param {number} id
 */
export async function deletePeriodicCheck(id) {
  return dataProvider.remove("periodicChecks", id);
}
