import { dataProvider } from "./dataProvider.js";

/**
 * @param {string} companyId
 * @returns {Promise<import("../types/index.js").Employee[]>}
 */
export async function getEmployees(companyId) {
  return dataProvider.getAll("employees", companyId ? { companyId } : undefined);
}

/**
 * @param {import("../types/index.js").Employee} employee
 */
export async function saveEmployee(employee) {
  return dataProvider.upsert("employees", employee);
}

/**
 * @param {number} id
 */
export async function deleteEmployee(id) {
  return dataProvider.remove("employees", id);
}
