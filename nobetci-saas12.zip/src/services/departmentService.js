import { dataProvider } from "./dataProvider.js";
import { DEFAULT_DEPARTMENT_NAMES } from "../constants/company.js";

/**
 * @param {string} companyId
 * @returns {Promise<import("../types/index.js").Department[]>}
 */
export async function getDepartments(companyId) {
  return dataProvider.getAll("departments", companyId ? { companyId } : undefined);
}

/**
 * @param {import("../types/index.js").Department} department
 */
export async function saveDepartment(department) {
  return dataProvider.upsert("departments", department);
}

/**
 * @param {number} id
 */
export async function deleteDepartment(id) {
  return dataProvider.remove("departments", id);
}

/**
 * Bir firma için hiç departman kaydedilmemişse, varsayılan seti oluşturup kaydeder.
 * Zaten kayıt varsa hiçbir şey yapmaz (mevcut kayıtlar korunur).
 * @param {string} companyId
 * @returns {Promise<import("../types/index.js").Department[]>}
 */
export async function ensureDefaultDepartments(companyId) {
  const existing = await getDepartments(companyId);
  if (existing.length > 0) return existing;

  const seeded = DEFAULT_DEPARTMENT_NAMES.map((name, i) => ({
    id: Date.now() + i,
    companyId,
    name,
    isCustom: false,
  }));
  await Promise.all(seeded.map((d) => saveDepartment(d)));
  return seeded;
}
