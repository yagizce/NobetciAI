import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * Records one activity entry. Fire-and-forget — callers don't need to await
 * this for their own flow to succeed (logging failure shouldn't break a feature).
 * companyId is attached automatically here (not by callers) so every existing
 * logActivity() call site across the app gets tenant-scoping for free.
 * @param {{ actor: string, action: string, details: string, entityType: string }} entry
 */
export async function logActivity({ actor, action, details, entityType }) {
  try {
    const companyId = await getPrimaryCompanyId();
    await dataProvider.upsert("auditLog", {
      id: Date.now() + Math.random(), // avoid collisions when multiple logs happen in the same millisecond
      companyId,
      timestamp: new Date().toISOString(),
      actor,
      action,
      details,
      entityType,
    });
  } catch (e) {
    console.error("Audit log kaydedilemedi:", e);
  }
}

/**
 * @returns {Promise<import("../types/index.js").AuditLogEntry[]>} newest first
 */
export async function getAuditLog() {
  const entries = await dataProvider.getAll("auditLog");
  return entries.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}
