import { dataProvider } from "./dataProvider.js";

/**
 * @param {string} companyId
 * @returns {Promise<import("../types/index.js").Branch[]>}
 */
export async function getBranches(companyId) {
  return dataProvider.getAll("branches", companyId ? { companyId } : undefined);
}

/**
 * @param {import("../types/index.js").Branch} branch
 */
export async function saveBranch(branch) {
  return dataProvider.upsert("branches", branch);
}

/**
 * @param {number} id
 */
export async function deleteBranch(id) {
  return dataProvider.remove("branches", id);
}
