import { dataProvider } from "./dataProvider.js";

/**
 * @returns {Promise<import("../types/index.js").Company[]>}
 */
export async function getCompanies() {
  return dataProvider.getAll("companies");
}

/**
 * MVP yardımcı: tek-firma senaryosunda "bizim firmamız" olarak ilk kaydı döndürür.
 * Gerçek çoklu-kiracı (multi-tenant) auth eklenince, bunun yerine oturumdaki
 * kullanıcının companyId'siyle eşleşen firma getirilecek (dataProvider.getById).
 * @returns {Promise<import("../types/index.js").Company|null>}
 */
export async function getPrimaryCompany() {
  const companies = await getCompanies();
  return companies[0] || null;
}

/**
 * @param {import("../types/index.js").Company} company
 */
export async function saveCompany(company) {
  const result = await dataProvider.upsert("companies", company);
  invalidatePrimaryCompanyIdCache();
  return result;
}

/**
 * @param {string} id
 */
export async function deleteCompany(id) {
  return dataProvider.remove("companies", id);
}

// --- Firma-kapsamı hazırlığı ---------------------------------------------------------
// Aşağıdaki yardımcı, oluşturulan her kaydın (bildirim, Fine-Kinney, belge, ekipman,
// periyodik kontrol, denetim kaydı) hangi firmaya ait olduğunu baştan işaretlemesi için
// var — gerçek çoklu-kiracı izolasyonu (Supabase RLS) eklendiğinde bu sütun zaten
// dolu olacak, geriye dönük veri taşıma/migrasyon gerekmeyecek.
//
// Basit bellek-içi önbellek: aynı oturumda her kayıt oluşturmada IndexedDB'ye tekrar
// gitmemek için. Firma bilgisi güncellendiğinde (saveCompany) otomatik geçersiz kılınır.
let _primaryCompanyIdCache;

/**
 * @returns {Promise<string|null>}
 */
export async function getPrimaryCompanyId() {
  if (_primaryCompanyIdCache !== undefined) return _primaryCompanyIdCache;
  const company = await getPrimaryCompany();
  _primaryCompanyIdCache = company?.id ?? null;
  return _primaryCompanyIdCache;
}

function invalidatePrimaryCompanyIdCache() {
  _primaryCompanyIdCache = undefined;
}
