// notificationRecordService — bildirim KAYITLARI için servis katmanı (Bildirim Merkezi'ndeki
// ramak kala/tehlike/iş kazası kayıtları). Tarayıcı push bildirimleriyle (services/notificationService.js)
// karışmasın diye adı farklı — o dosya Notification API'sini sarar, bu dosya veri kaydını sarar.
//
// Bu dosyanın eklenme nedeni: IsgDataContext daha önce bildirimler için doğrudan dataProvider'ı
// çağırıyordu, Service+Repository mimarisini atlıyordu (diğer tüm varlıklar servis katmanından
// geçiyor). Artık tutarlı.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").Notification[]>}
 */
export async function getNotificationRecords() {
  return dataProvider.getAll("notifications");
}

/**
 * @param {import("../types/index.js").Notification} notification
 */
export async function saveNotificationRecord(notification) {
  const companyId = notification.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("notifications", { ...notification, companyId });
}
