// documentService — wraps equipment/document storage via the abstract dataProvider.
// Kept separate from chatService because it doesn't touch the network/API at all.
//
// Document generation is UI + data model only right now (see constants/documentTypes.js).
// `content` on a DocumentRecord is a placeholder until AI-assisted generation is added —
// at that point, creating a document will likely call chatService to fill `content`,
// but the storage shape below already supports that without changes.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").Equipment[]>}
 */
export async function getEquipment() {
  return dataProvider.getAll("equipment");
}

/**
 * @param {import("../types/index.js").Equipment} equipment
 */
export async function saveEquipment(equipment) {
  const companyId = equipment.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("equipment", { ...equipment, companyId });
}

/**
 * @returns {Promise<import("../types/index.js").DocumentRecord[]>}
 */
export async function getDocuments() {
  return dataProvider.getAll("documents");
}

/**
 * @param {import("../types/index.js").DocumentRecord} document
 */
export async function saveDocument(document) {
  const companyId = document.companyId ?? (await getPrimaryCompanyId());
  return dataProvider.upsert("documents", { ...document, companyId });
}

/**
 * @param {number} id
 */
export async function deleteDocument(id) {
  return dataProvider.remove("documents", id);
}
