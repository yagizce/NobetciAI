// systemNotificationService — Header'daki Bildirim Merkezi'nin veri katmanı.
// Service+Repository mimarisine uygun: dataProvider üzerinden IndexedDB'ye yazıyor,
// gerçek backend gelince yalnızca dataProvider'ın implementasyonu değişecek.

import { dataProvider } from "./dataProvider.js";
import { getPrimaryCompanyId } from "./companyService.js";

/**
 * @returns {Promise<import("../types/index.js").SystemNotification[]>} en yeni en üstte
 */
export async function getSystemNotifications() {
  const all = await dataProvider.getAll("systemNotifications");
  return all.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

/**
 * @param {{ type: string, title: string, message: string }} input
 */
export async function pushSystemNotification({ type, title, message }) {
  const companyId = await getPrimaryCompanyId();
  return dataProvider.upsert("systemNotifications", {
    id: Date.now() + Math.random(),
    companyId,
    type,
    title,
    message,
    read: false,
    createdAt: new Date().toISOString(),
  });
}

/**
 * @param {number} id
 */
export async function markNotificationRead(id) {
  const notif = await dataProvider.getById("systemNotifications", id);
  if (!notif) return null;
  return dataProvider.upsert("systemNotifications", { ...notif, read: true });
}

/**
 * @param {import("../types/index.js").SystemNotification[]} notifications
 */
export async function markAllNotificationsRead(notifications) {
  await Promise.all(notifications.filter((n) => !n.read).map((n) => dataProvider.upsert("systemNotifications", { ...n, read: true })));
}

/**
 * İlk kullanımda örnek bildirim yoksa, "Eğitim Hatırlatma" türü için birkaç örnek ekler
 * (henüz gerçek çalışan-bazlı eğitim takip sistemi olmadığından — bkz. CHANGELOG).
 * Diğer tüm bildirim türleri gerçek olaylardan (risk oluşturma, çalışan ekleme vb.) üretilir.
 */
export async function ensureSampleTrainingReminders() {
  const existing = await getSystemNotifications();
  if (existing.length > 0) return;
  await pushSystemNotification({
    type: "trainingDue",
    title: "Eğitim tarihi yaklaşıyor",
    message: "Yangın Söndürme eğitiminin tekrarına 5 gün kaldı.",
  });
}
