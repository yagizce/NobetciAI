import ChatPanel from "../features/chat/ChatPanel.jsx";
import { useDocumentTitle } from "../hooks/useDocumentTitle.js";

export default function Chat() {
  useDocumentTitle("AI Chat");
  return <ChatPanel />;
}
