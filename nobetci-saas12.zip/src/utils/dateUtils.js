export function nowLabel() {
  return new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

export function todayLabel() {
  return new Date().toLocaleDateString("tr-TR");
}
