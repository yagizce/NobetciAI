// Periyodik kontrol modülü — kategoriler ve durum hesaplama mantığı.
// "Yaklaşan" eşiği: sonraki kontrole 14 gün veya daha az kaldıysa.

export const CHECK_CATEGORIES = [
  { value: "fireExtinguisher", label: "Yangın Tüpü" },
  { value: "equipment", label: "Ekipman" },
  { value: "electrical", label: "Elektrik Tesisatı" },
  { value: "scaffolding", label: "İskele / Platform" },
  { value: "other", label: "Diğer" },
];

export const INTERVAL_PRESETS = [
  { value: 30, label: "30 gün (Aylık)" },
  { value: 90, label: "90 gün (3 Aylık)" },
  { value: 180, label: "180 gün (6 Aylık)" },
  { value: 365, label: "365 gün (Yıllık)" },
];

export function getCategoryLabel(value) {
  return CHECK_CATEGORIES.find((c) => c.value === value)?.label || value;
}

const UPCOMING_THRESHOLD_DAYS = 14;

/**
 * @param {string} lastCheckDate - ISO date (YYYY-MM-DD)
 * @param {number} intervalDays
 * @returns {string} ISO date
 */
export function computeNextDueDate(lastCheckDate, intervalDays) {
  const base = lastCheckDate ? new Date(lastCheckDate) : new Date();
  base.setDate(base.getDate() + Number(intervalDays));
  return base.toISOString().slice(0, 10);
}

/**
 * @param {string} nextDueDate - ISO date
 * @returns {"ok"|"upcoming"|"overdue"}
 */
export function computeCheckStatus(nextDueDate) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(nextDueDate);
  const diffDays = Math.round((due - today) / (1000 * 60 * 60 * 24));
  if (diffDays < 0) return "overdue";
  if (diffDays <= UPCOMING_THRESHOLD_DAYS) return "upcoming";
  return "ok";
}

/**
 * @param {"ok"|"upcoming"|"overdue"} status
 * @param {"light"|"dark"} mode
 * @param {object} theme - the active THEMES[mode] object, for consistent shared tokens
 * @returns {{ label: string, bg: string, text: string }}
 */
export function getCheckStatusStyle(status, theme) {
  if (status === "overdue") return { label: "Süresi Geçti", bg: theme.highRiskBg, text: theme.highRiskText };
  if (status === "upcoming") return { label: "Yaklaşıyor", bg: theme.warnBg, text: theme.warnText };
  return { label: "Güncel", bg: theme.successBg, text: theme.successText };
}
