// Supported document types for the document generation infrastructure.
// UI + data model only for now — AI-assisted content generation is a future step
// (see documentService.js and FineKinneyModule.jsx pattern for how that will likely plug in).

export const DOCUMENT_TYPES = [
  { value: "riskAnalizi", label: "Risk Analizi" },
  { value: "acilDurumPlani", label: "Acil Durum Planı" },
  { value: "talimat", label: "Talimat" },
  { value: "kkdTutanagi", label: "KKD Teslim Tutanağı" },
  { value: "ramakKala", label: "Ramak Kala" },
  { value: "isKazasiBildirimi", label: "İş Kazası Bildirimi" },
];

export function getDocumentTypeLabel(value) {
  return DOCUMENT_TYPES.find((t) => t.value === value)?.label || value;
}
