// Mock company directory. Once real auth/backend exists, this becomes a database table
// and companyId on User becomes a real foreign key — the shape is already correct for that.

export const MOCK_COMPANIES = {
  comp_001: { id: "comp_001", name: "Örnek Sanayi A.Ş.", sector: "Metal İşleme", employeeCount: 84 },
  comp_002: { id: "comp_002", name: "Nöbetçi Danışmanlık", sector: "İSG Danışmanlığı", employeeCount: 12 },
};

export function getCompanyById(companyId) {
  return MOCK_COMPANIES[companyId] || null;
}
