// Tam rol kümesi — Sprint 3 hazırlığı. ⚠️ Bu liste henüz hiçbir yerde aktif olarak
// kullanılmıyor. Aktif rol değiştirici hâlâ src/contexts/RoleContext.jsx'teki 3 rollü
// (expert/employer/employee) ROLES listesini kullanıyor — orası bilerek değiştirilmedi,
// çünkü "otomatik yönlendirme yapılmayacak, bu Sprint 4'ün işi" talimatı verildi.
//
// Sprint 4'te otomatik role-based routing eklenirken, RoleContext.ROLES bu listeyle
// birleştirilecek/değiştirilecek.

export const ALL_ROLES = [
  { id: "superAdmin", emoji: "🛡️", label: "Süper Admin" },
  { id: "companyAdmin", emoji: "🏢", label: "Firma Admini" },
  { id: "employer", emoji: "👨‍💼", label: "İşveren" },
  { id: "expert", emoji: "🦺", label: "İSG Uzmanı" },
  { id: "employee", emoji: "👷", label: "Çalışan" },
];

export function getRoleLabel(roleId) {
  return ALL_ROLES.find((r) => r.id === roleId)?.label || roleId;
}
