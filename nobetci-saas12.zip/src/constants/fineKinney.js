// Fine-Kinney risk assessment method: Risk = Olasılık (Probability) × Maruziyet (Exposure) × Şiddet (Severity)
// Bu dosyadaki ölçek değerleri ve eşikler İSG uzmanlarının kullandığı standart Fine-Kinney referans değerleridir.

export const PROBABILITY_SCALE = [
  { value: 0.1, label: "0.1 — Neredeyse imkansız" },
  { value: 0.2, label: "0.2 — Çok düşük" },
  { value: 0.5, label: "0.5 — Düşük" },
  { value: 1, label: "1 — Düşük fakat mümkün" },
  { value: 3, label: "3 — Mümkün" },
  { value: 6, label: "6 — Yüksek" },
  { value: 10, label: "10 — Çok yüksek" },
];

export const FREQUENCY_SCALE = [
  { value: 0.5, label: "0.5 — Yılda birkaç kez" },
  { value: 1, label: "1 — Ayda birkaç kez" },
  { value: 2, label: "2 — Haftada birkaç kez" },
  { value: 3, label: "3 — Haftada sürekli" },
  { value: 6, label: "6 — Her gün" },
  { value: 10, label: "10 — Sürekli" },
];

export const SEVERITY_SCALE = [
  { value: 1, label: "1 — Önemsiz" },
  { value: 3, label: "3 — Hafif yaralanma" },
  { value: 7, label: "7 — İş günü kaybı" },
  { value: 15, label: "15 — Kalıcı yaralanma" },
  { value: 40, label: "40 — Tek ölüm" },
  { value: 100, label: "100 — Birden fazla ölüm / Felaket" },
];

export const STATUS_OPTIONS = [
  { value: "open", label: "Açık" },
  { value: "in_progress", label: "Devam Ediyor" },
  { value: "done", label: "Tamamlandı" },
];

export const PRIORITY_OPTIONS = [
  { value: "low", label: "Düşük", tone: "success" },
  { value: "medium", label: "Orta", tone: "pending" },
  { value: "high", label: "Yüksek", tone: "warning" },
  { value: "urgent", label: "Acil", tone: "danger" },
];

export function getPriorityMeta(value) {
  return PRIORITY_OPTIONS.find((p) => p.value === value) || PRIORITY_OPTIONS[1];
}

// Risk seviyesi renk paleti — mevcut paylaşılan Badge bileşenine yeni ton eklemeden
// (diğer modülleri etkilememek için) Fine-Kinney'e özel, tema-duyarlı renkler.
// "possible" (Olası Risk) ve "high" (Yüksek Risk) burada tanımlı, çünkü paylaşılan
// tema paletinde açık yeşil / turuncu karşılığı yok.
const RISK_LEVEL_PALETTE = {
  light: {
    low: { bg: "#E4F2E1", text: "#3E7A34" },
    possible: { bg: "#EAF7DC", text: "#5B8C3A" },
    important: { bg: "#FBEFD2", text: "#8A6300" },
    high: { bg: "#FDE7D2", text: "#B85C00" },
    veryHigh: { bg: "#FCE4E4", text: "#B3261E" },
  },
  dark: {
    low: { bg: "#1E3320", text: "#7FBF6E" },
    possible: { bg: "#233A18", text: "#9FDB7F" },
    important: { bg: "#332A12", text: "#F2B705" },
    high: { bg: "#3A2410", text: "#FFA94D" },
    veryHigh: { bg: "#3C1F1F", text: "#FF6B6B" },
  },
};

/**
 * @param {number} probability
 * @param {number} frequency
 * @param {number} severity
 * @returns {number}
 */
export function computeFineKinneyScore(probability, frequency, severity) {
  return probability * frequency * severity;
}

/**
 * @param {number} score
 * @param {"light"|"dark"} [mode]
 * @returns {{ label: string, description: string, bg: string, text: string, key: string }}
 */
export function getFineKinneyRiskLevel(score, mode = "light") {
  const palette = RISK_LEVEL_PALETTE[mode] || RISK_LEVEL_PALETTE.light;
  if (score < 20) return { key: "low", label: "Düşük Risk", description: "Risk kabul edilebilir düzeyde, rutin takip yeterli.", ...palette.low };
  if (score < 70) return { key: "possible", label: "Olası Risk", description: "Dikkat gerektirir, kontrol tedbirleri gözden geçirilmeli.", ...palette.possible };
  if (score < 200) return { key: "important", label: "Önemli Risk", description: "Düzeltici önlem gerekli, planlı iyileştirme yapılmalı.", ...palette.important };
  if (score < 400) return { key: "high", label: "Yüksek Risk", description: "Acil düzeltme gerekli, kısa sürede önlem alınmalı.", ...palette.high };
  return { key: "veryHigh", label: "Çok Yüksek Risk", description: "İş derhal durdurulmalı, acil müdahale gerekli.", ...palette.veryHigh };
}

// Filtreleme arayüzünde kullanılacak sabit liste (Tümü seçeneğiyle birlikte).
export const RISK_LEVEL_FILTERS = [
  { key: "all", label: "Tümü" },
  { key: "low", label: "Düşük Risk" },
  { key: "possible", label: "Olası Risk" },
  { key: "important", label: "Önemli Risk" },
  { key: "high", label: "Yüksek Risk" },
  { key: "veryHigh", label: "Çok Yüksek Risk" },
];
