export const EDUCATION_MODULES = ["KKD Kullanımı", "Yangın Söndürme", "İlk Yardım", "Elektrik Güvenliği", "Yüksekte Çalışma"];
