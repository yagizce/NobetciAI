import { useState, useEffect } from "react";
import { useToast } from "../../contexts/ToastContext.jsx";
import { useRole } from "../../contexts/RoleContext.jsx";
import { getRoleLabel } from "../../constants/allRoles.js";
import { getDepartments, saveDepartment, deleteDepartment, ensureDefaultDepartments } from "../../services/departmentService.js";
import { logActivity } from "../../services/auditService.js";
import Button from "../../components/ui/Button.jsx";
import Badge from "../../components/ui/Badge.jsx";
import Loading from "../../components/Loading.jsx";
import ConfirmDialog from "../../components/ui/ConfirmDialog.jsx";
import { Plus, Trash2 } from "../../components/icons/index.jsx";

/**
 * @param {{ theme: object, companyId: string }} props
 */
export default function DepartmentsSection({ theme, companyId }) {
  const { showToast } = useToast();
  const { role } = useRole();
  const [departments, setDepartments] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [newName, setNewName] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  useEffect(() => {
    ensureDefaultDepartments(companyId).then(() =>
      getDepartments(companyId).then((data) => { setDepartments(data); setLoaded(true); })
    );
  }, [companyId]);

  async function handleAdd() {
    if (!newName.trim()) return;
    const entry = { id: Date.now(), companyId, name: newName.trim(), isCustom: true };
    await saveDepartment(entry);
    setDepartments((prev) => [...prev, entry]);
    setNewName("");
    showToast("Departman eklendi.", "success");
    logActivity({ actor: getRoleLabel(role) || role, action: "Departman eklendi", details: entry.name, entityType: "department" });
  }

  async function handleConfirmDelete() {
    const dept = departments.find((d) => d.id === confirmDeleteId);
    await deleteDepartment(confirmDeleteId);
    setDepartments((prev) => prev.filter((d) => d.id !== confirmDeleteId));
    setConfirmDeleteId(null);
    showToast("Departman silindi.", "neutral");
    logActivity({ actor: getRoleLabel(role) || role, action: "Departman silindi", details: dept?.name || "", entityType: "department" });
  }

  if (!loaded) return <Loading label="Departmanlar yükleniyor..." />;

  return (
    <div>
      <div className="flex gap-2 mb-4 max-w-sm">
        <input value={newName} onChange={(e) => setNewName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleAdd()} placeholder="Yeni departman adı"
          className="flex-1 text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }} />
        <Button size="sm" onClick={handleAdd} disabled={!newName.trim()} className="flex items-center gap-1">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Ekle
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {departments.map((d) => (
          <div key={d.id} className="flex items-center gap-2 rounded-full pl-3 pr-1.5 py-1.5" style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}>
            <span className="text-sm" style={{ color: theme.textPrimary }}>{d.name}</span>
            {!d.isCustom && <Badge tone="neutral">Varsayılan</Badge>}
            <button onClick={() => setConfirmDeleteId(d.id)} className="w-5 h-5 rounded-full flex items-center justify-center" style={{ color: theme.emergencyText }}>
              <Trash2 style={{ fontSize: "11px" }} />
            </button>
          </div>
        ))}
      </div>

      <ConfirmDialog open={confirmDeleteId !== null} title="Departmanı sil" message="Bu departmanı silmek istediğinize emin misiniz?" confirmLabel="Sil" danger
        onConfirm={handleConfirmDelete} onCancel={() => setConfirmDeleteId(null)} />
    </div>
  );
}
