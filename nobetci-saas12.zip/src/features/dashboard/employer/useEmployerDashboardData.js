import { useState, useEffect, useMemo } from "react";
import { useIsgData } from "../../../contexts/IsgDataContext.jsx";
import { getPrimaryCompany } from "../../../services/companyService.js";
import { getBranches } from "../../../services/branchService.js";
import { getDepartments } from "../../../services/departmentService.js";
import { getEmployees } from "../../../services/employeeService.js";
import { getFineKinneyEntries } from "../../../services/riskService.js";
import { getPeriodicChecks } from "../../../services/periodicCheckService.js";
import { getAuditLog } from "../../../services/auditService.js";
import { getFineKinneyRiskLevel } from "../../../constants/fineKinney.js";
import { EDUCATION_MODULES } from "../../../constants/education.js";
import { computeSafetyScore } from "../../../utils/safetyScore.js";
import { computeWeeklySummary } from "../../../utils/executiveSummary.js";

/**
 * Tek yerden yükler, Genel Bakış / Performans sekmeleri ve tüm widget'lar aynı veriyi
 * tekrar çekmeden kullanır. "Tamamlanan Eğitimler" hâlâ mock (gerçek çalışan-bazlı eğitim
 * takip sistemi yok — bkz. CHANGELOG), diğer tüm metrikler gerçek servislerden geliyor.
 */
export function useEmployerDashboardData() {
  const { notifications } = useIsgData();
  const [company, setCompany] = useState(null);
  const [branches, setBranches] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [fineKinneyEntries, setFineKinneyEntries] = useState([]);
  const [periodicChecks, setPeriodicChecks] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getPrimaryCompany().then(async (c) => {
      setCompany(c);
      if (c) {
        const [b, d, e, fk, pc, log] = await Promise.all([
          getBranches(c.id), getDepartments(c.id), getEmployees(c.id),
          getFineKinneyEntries(), getPeriodicChecks(), getAuditLog(),
        ]);
        setBranches(b);
        setDepartments(d);
        setEmployees(e);
        setFineKinneyEntries(fk);
        setPeriodicChecks(pc);
        setAuditLog(log);
      }
      setLoaded(true);
    });
  }, []);

  const riskAnalyses = useMemo(() => notifications.filter((n) => n.status === "approved"), [notifications]);
  const aiAnalyzedNotifications = useMemo(() => notifications.filter((n) => n.aiAnalysis), [notifications]);

  const metrics = useMemo(() => {
    const openRisks = fineKinneyEntries.filter((e) => e.status !== "done").length;
    const criticalRisks = fineKinneyEntries.filter((e) => {
      const level = getFineKinneyRiskLevel(e.score).key;
      return level === "high" || level === "veryHigh";
    }).length;
    const upcomingChecks = periodicChecks.filter((c) => c.status === "upcoming" || c.status === "overdue").length;
    const closedEntries = fineKinneyEntries.filter((e) => e.status === "done");
    const riskClosureRate = fineKinneyEntries.length > 0 ? Math.round((closedEntries.length / fineKinneyEntries.length) * 100) : 0;
    const okChecks = periodicChecks.filter((c) => c.status === "ok").length;
    const periodicCompletionRate = periodicChecks.length > 0 ? Math.round((okChecks / periodicChecks.length) * 100) : 0;
    // Mock: gerçek çalışan-eğitim tamamlama kaydı yok, eğitim modülü sayısına göre temsili oran.
    const trainingCompletionRate = employees.length > 0 ? 72 : 0;

    // KPI: Ortalama Risk Puanı — gerçek, tüm Fine-Kinney kayıtlarının ortalaması.
    const avgRiskScore = fineKinneyEntries.length > 0
      ? Math.round(fineKinneyEntries.reduce((sum, e) => sum + e.score, 0) / fineKinneyEntries.length)
      : 0;

    // KPI: Risk Kapanma Süresi — gerçek, closedAt - date farkının gün ortalaması (yalnızca closedAt damgalı kayıtlar).
    const closureDurations = closedEntries
      .filter((e) => e.closedAt && e.date)
      .map((e) => Math.max(0, Math.round((new Date(e.closedAt) - new Date(e.date)) / (1000 * 60 * 60 * 24))));
    const avgClosureDays = closureDurations.length > 0 ? Math.round(closureDurations.reduce((a, b) => a + b, 0) / closureDurations.length) : null;

    // Düzeltici Faaliyet Modülü: her açık risk aynı zamanda bir düzeltici faaliyettir (priority/completionPercent alanlarıyla).
    const activeCorrectiveActions = fineKinneyEntries.filter((e) => e.status !== "done").length;
    const avgCompletionOfActive = activeCorrectiveActions > 0
      ? Math.round(fineKinneyEntries.filter((e) => e.status !== "done").reduce((sum, e) => sum + (e.completionPercent || 0), 0) / activeCorrectiveActions)
      : 100;
    const correctiveActionCompletionRate = fineKinneyEntries.length > 0
      ? Math.round(fineKinneyEntries.reduce((sum, e) => sum + (e.status === "done" ? 100 : (e.completionPercent || 0)), 0) / fineKinneyEntries.length)
      : 100;

    return {
      totalEmployees: employees.length,
      openRisks,
      criticalRisks,
      upcomingChecks,
      completedTrainings: Math.round((trainingCompletionRate / 100) * EDUCATION_MODULES.length),
      totalTrainings: EDUCATION_MODULES.length,
      recentAiAnalyses: aiAnalyzedNotifications.length,
      riskClosureRate,
      periodicCompletionRate,
      trainingCompletionRate,
      branchCount: branches.length,
      departmentCount: departments.length,
      avgRiskScore,
      avgClosureDays,
      activeCorrectiveActions,
      avgCompletionOfActive,
      correctiveActionCompletionRate,
      totalRisks: fineKinneyEntries.length,
    };
  }, [fineKinneyEntries, periodicChecks, employees, branches, departments, aiAnalyzedNotifications]);

  const safetyScore = useMemo(() => computeSafetyScore({
    openRisks: metrics.openRisks,
    criticalRisks: metrics.criticalRisks,
    totalRisks: fineKinneyEntries.length,
    trainingCompletionRate: metrics.trainingCompletionRate,
    upcomingChecks: metrics.upcomingChecks,
    totalChecks: periodicChecks.length,
    correctiveActionCompletionRate: metrics.correctiveActionCompletionRate,
  }), [metrics, fineKinneyEntries.length, periodicChecks.length]);

  const weeklySummary = useMemo(
    () => computeWeeklySummary(fineKinneyEntries, periodicChecks),
    [fineKinneyEntries, periodicChecks]
  );

  return { company, branches, departments, employees, fineKinneyEntries, periodicChecks, auditLog, riskAnalyses, metrics, safetyScore, weeklySummary, loaded };
}
