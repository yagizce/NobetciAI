import { useState, useEffect, useMemo, useCallback } from "react";
import { getFineKinneyEntries, saveFineKinneyEntry, deleteFineKinneyEntry } from "../../../services/riskService.js";
import { computeFineKinneyScore, getFineKinneyRiskLevel } from "../../../constants/fineKinney.js";
import { todayLabel } from "../../../utils/dateUtils.js";
import { logActivity } from "../../../services/auditService.js";
import { showLocalNotification } from "../../../services/notificationService.js";
import { pushSystemNotification } from "../../../services/systemNotificationService.js";
import { useRole, ROLES } from "../../../contexts/RoleContext.jsx";

export function useFineKinneyEntries() {
  const { role } = useRole();
  const [entries, setEntries] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [levelFilter, setLevelFilter] = useState("all");

  useEffect(() => {
    getFineKinneyEntries().then((data) => {
      setEntries(data);
      setLoaded(true);
    });
  }, []);

  const saveEntry = useCallback(async (formValues, editingId) => {
    const probability = Number(formValues.probability);
    const frequency = Number(formValues.frequency);
    const severity = Number(formValues.severity);
    const score = computeFineKinneyScore(probability, frequency, severity);
    const level = getFineKinneyRiskLevel(score);

    // Artık risk yalnızca bir önlem girildiyse anlamlıdır (form da bu durumda gösteriyor).
    const hasAction = formValues.action?.trim().length > 0;
    const residualProbability = hasAction ? Number(formValues.residualProbability) : null;
    const residualFrequency = hasAction ? Number(formValues.residualFrequency) : null;
    const residualSeverity = hasAction ? Number(formValues.residualSeverity) : null;
    const residualScore = hasAction ? computeFineKinneyScore(residualProbability, residualFrequency, residualSeverity) : null;
    const residualLevel = residualScore !== null ? getFineKinneyRiskLevel(residualScore) : null;

    // Risk kapanma süresi hesaplanabilsin diye (KPI: "Risk Kapanma Süresi"), durum ilk kez
    // "done" olduğunda closedAt damgalanır. Zaten kapalıysa (düzenlemede tekrar "done"
    // seçilirse) mevcut closedAt korunur — yeniden açılıp kapatılmadıkça değişmez.
    const previousEntry = editingId ? entries.find((e) => e.id === editingId) : null;
    let closedAt = previousEntry?.closedAt || null;
    if (formValues.status === "done" && !closedAt) closedAt = new Date().toISOString();
    if (formValues.status !== "done") closedAt = null;

    const entry = {
      id: editingId || Date.now(),
      hazard: formValues.hazard.trim(),
      risk: formValues.risk.trim(),
      probability,
      frequency,
      severity,
      score,
      riskLevel: level.label,
      action: formValues.action.trim(),
      responsible: formValues.responsible.trim(),
      dueDate: formValues.dueDate,
      date: editingId ? formValues.date || todayLabel() : todayLabel(),
      status: formValues.status,
      priority: formValues.priority || "medium",
      completionPercent: Number(formValues.completionPercent) || 0,
      closedAt,
      residualProbability,
      residualFrequency,
      residualSeverity,
      residualScore,
      residualRiskLevel: residualLevel?.label || null,
    };

    await saveFineKinneyEntry(entry);
    setEntries((prev) => {
      const exists = prev.some((e) => e.id === entry.id);
      return exists ? prev.map((e) => (e.id === entry.id ? entry : e)) : [entry, ...prev];
    });

    const actor = ROLES.find((r) => r.id === role)?.label || role;
    logActivity({
      actor,
      action: editingId ? (formValues.status === "done" && !previousEntry?.closedAt ? "Risk kapatıldı" : "Risk güncellendi") : "Yeni risk oluşturuldu",
      details: `${entry.hazard} — ${entry.score} (${level.label})`,
      entityType: "fineKinney",
    });
    if (level.key === "veryHigh") {
      showLocalNotification("newNotification", "Çok Yüksek Risk Tespit Edildi", `"${entry.hazard}" — puan ${entry.score}. Acil önlem gerekebilir.`);
    }

    // Yalnızca yeni kayıtlarda bildirim üret (düzenlemede tekrar tekrar bildirim gitmesin).
    if (!editingId) {
      pushSystemNotification({ type: "riskCreated", title: "Yeni Risk Oluşturuldu", message: `${entry.hazard} — ${level.label} (${entry.score} puan)` });
      if (level.key === "high" || level.key === "veryHigh") {
        pushSystemNotification({ type: "criticalRisk", title: "Kritik Risk", message: `${entry.hazard} — ${level.label} (${entry.score} puan). Acil önlem gerekebilir.` });
      }
    }

    return entry;
  }, [role, entries]);

  const removeEntry = useCallback(async (id) => {
    const entry = entries.find((e) => e.id === id);
    await deleteFineKinneyEntry(id);
    setEntries((prev) => prev.filter((e) => e.id !== id));
    logActivity({
      actor: ROLES.find((r) => r.id === role)?.label || role,
      action: "Fine-Kinney değerlendirmesi silindi",
      details: entry?.hazard || `#${id}`,
      entityType: "fineKinney",
    });
  }, [entries, role]);

  const filteredEntries = useMemo(() => {
    const query = search.trim().toLowerCase();
    return entries.filter((e) => {
      const matchesSearch = !query || e.hazard.toLowerCase().includes(query) || e.risk.toLowerCase().includes(query);
      const matchesLevel = levelFilter === "all" || getFineKinneyRiskLevel(e.score).key === levelFilter;
      return matchesSearch && matchesLevel;
    });
  }, [entries, search, levelFilter]);

  return {
    entries: filteredEntries,
    totalCount: entries.length,
    loaded,
    search,
    setSearch,
    levelFilter,
    setLevelFilter,
    saveEntry,
    removeEntry,
  };
}
