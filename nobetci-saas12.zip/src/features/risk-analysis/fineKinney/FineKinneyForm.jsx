import { useState } from "react";
import { PROBABILITY_SCALE, FREQUENCY_SCALE, SEVERITY_SCALE, STATUS_OPTIONS, PRIORITY_OPTIONS, computeFineKinneyScore } from "../../../constants/fineKinney.js";
import { FINE_KINNEY_AI_PROMPT, parseResidualSuggestion } from "../../../constants/systemPrompt.js";
import { sendChatMessage } from "../../../services/chatService.js";
import Button from "../../../components/ui/Button.jsx";
import RiskLevelChip from "./RiskLevelChip.jsx";

export const EMPTY_FINE_KINNEY_FORM = {
  hazard: "", risk: "", probability: 1, frequency: 1, severity: 1, action: "", responsible: "", dueDate: "", status: "open",
  residualProbability: 1, residualFrequency: 1, residualSeverity: 1, residualSuggested: false,
  priority: "medium", completionPercent: 0,
};

/**
 * @param {{ theme: object, mode: "light"|"dark", form: object, setForm: (f: object) => void, editingId: number|null, onSubmit: () => void, onCancel: () => void }} props
 */
export default function FineKinneyForm({ theme, mode, form, setForm, editingId, onSubmit, onCancel }) {
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [aiError, setAiError] = useState(null);

  const liveScore = computeFineKinneyScore(Number(form.probability), Number(form.frequency), Number(form.severity));
  const liveResidualScore = computeFineKinneyScore(Number(form.residualProbability), Number(form.residualFrequency), Number(form.residualSeverity));
  const showResidual = form.action.trim().length > 0;

  async function getAiSuggestion() {
    if (!form.hazard.trim()) return;
    setAiLoading(true);
    setAiError(null);
    setAiSuggestion(null);
    try {
      const reply = await sendChatMessage({
        system: FINE_KINNEY_AI_PROMPT,
        max_tokens: 500,
        messages: [{
          role: "user",
          content: `Tehlike: ${form.hazard}\nRisk: ${form.risk || "belirtilmedi"}\nÖnlem öncesi Olasılık: ${form.probability}\nÖnlem öncesi Maruziyet: ${form.frequency}\nÖnlem öncesi Şiddet: ${form.severity}`,
        }],
      });
      setAiSuggestion(reply || "Öneri oluşturulamadı, tekrar deneyin.");

      // AI'nin metin cevabından artık risk önerisini ayıkla ve önlem alanına eklendiğinde
      // kullanılmak üzere hazırla — asıl değerleri ASLA aşmayacak şekilde sınırlanır.
      if (reply) {
        const parsed = parseResidualSuggestion(reply);
        setForm((prev) => ({
          ...prev,
          residualProbability: parsed.probability !== null ? Math.min(parsed.probability, Number(prev.probability)) : prev.residualProbability,
          residualFrequency: parsed.frequency !== null ? Math.min(parsed.frequency, Number(prev.frequency)) : prev.residualFrequency,
          residualSeverity: parsed.severity !== null ? Math.min(parsed.severity, Number(prev.severity)) : prev.residualSeverity,
          residualSuggested: parsed.probability !== null || parsed.frequency !== null || parsed.severity !== null,
        }));
      }
    } catch {
      setAiError("AI önerisi alınamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.");
    } finally {
      setAiLoading(false);
    }
  }

  function applySuggestionToAction() {
    if (!aiSuggestion) return;
    // AI cevabının "Artık Risk Önerisi" kısmını önlem metnine eklemeye gerek yok — o veri
    // zaten aşağıdaki Artık Risk dropdown'larına otomatik uygulandı. Yalnızca önlem/KKD/açıklama kısmını ekle.
    const actionOnly = aiSuggestion.split(/\*\*Artık Risk Önerisi/i)[0].trim();
    setForm((prev) => ({ ...prev, action: prev.action ? `${prev.action}\n\n${actionOnly}` : actionOnly }));
  }

  return (
    <div className="rounded-xl border px-3.5 py-3 mb-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
      <div className="grid gap-2 mb-2 sm:grid-cols-2">
        <input
          value={form.hazard}
          onChange={(e) => setForm({ ...form, hazard: e.target.value })}
          placeholder="Tehlike (örn. Yüksekte korkuluksuz çalışma)"
          className="text-sm rounded-lg px-3 py-2 outline-none border"
          style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
        />
        <input
          value={form.risk}
          onChange={(e) => setForm({ ...form, risk: e.target.value })}
          placeholder="Risk (örn. Yüksekten düşme)"
          className="text-sm rounded-lg px-3 py-2 outline-none border"
          style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
        />
      </div>

      <div className="grid gap-2 mb-2 sm:grid-cols-3">
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Olasılık</span>
          <select value={form.probability} onChange={(e) => setForm({ ...form, probability: e.target.value })}
            className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
            {PROBABILITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Maruziyet</span>
          <select value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })}
            className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
            {FREQUENCY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Şiddet</span>
          <select value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}
            className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
            {SEVERITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
      </div>

      <div className="rounded-lg px-3 py-2.5 mb-3 flex items-center justify-between flex-wrap gap-2" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
        <span className="text-xs" style={{ color: theme.textFaint }}>Mevcut Risk Puanı</span>
        <RiskLevelChip score={liveScore} mode={mode} showDescription />
      </div>

      <button
        onClick={getAiSuggestion}
        disabled={!form.hazard.trim() || aiLoading}
        className="text-xs font-semibold mb-3 px-3 py-1.5 rounded-full disabled:opacity-40"
        style={{ background: theme.accent, color: theme.onAccent }}
      >
        {aiLoading ? "AI düşünüyor..." : "🤖 AI Önerisi Al (önlem + artık risk)"}
      </button>

      {aiError && (
        <div className="rounded-lg px-3 py-2 mb-3 text-xs" style={{ background: theme.emergencyBg, color: theme.emergencyText }}>
          {aiError}
        </div>
      )}

      {aiSuggestion && (
        <div className="rounded-lg px-3 py-2.5 mb-3" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
          <p className="text-[11px] whitespace-pre-wrap mb-2" style={{ color: theme.textMuted }}>{aiSuggestion}</p>
          <button onClick={applySuggestionToAction} className="text-[11px] font-semibold" style={{ color: theme.accent }}>
            + Önlem/KKD önerisini "Alınacak Önlem" alanına ekle
          </button>
          {form.residualSuggested && (
            <p className="text-[10.5px] mt-1.5" style={{ color: theme.successText }}>
              ✓ Artık risk değerleri aşağıda AI önerisiyle dolduruldu — gerekirse elle düzeltebilirsiniz.
            </p>
          )}
        </div>
      )}

      <textarea
        value={form.action}
        onChange={(e) => setForm({ ...form, action: e.target.value })}
        placeholder="Alınacak önlem"
        rows={3}
        className="w-full text-sm rounded-lg px-3 py-2 mb-2 outline-none border resize-none"
        style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
      />

      {showResidual && (
        <div className="rounded-lg px-3 py-3 mb-3" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
          <p className="text-xs font-semibold mb-2" style={{ color: theme.textPrimary }}>Artık Risk (Önlem Sonrası)</p>
          <p className="text-[10.5px] mb-2" style={{ color: theme.textFaint }}>Yukarıdaki önlem uygulandığında beklenen değerleri seçin — Şiddet genelde değişmez.</p>
          <div className="grid gap-2 mb-2 sm:grid-cols-3">
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Artık Olasılık</span>
              <select value={form.residualProbability} onChange={(e) => setForm({ ...form, residualProbability: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }}>
                {PROBABILITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Artık Maruziyet</span>
              <select value={form.residualFrequency} onChange={(e) => setForm({ ...form, residualFrequency: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }}>
                {FREQUENCY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Artık Şiddet</span>
              <select value={form.residualSeverity} onChange={(e) => setForm({ ...form, residualSeverity: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }}>
                {SEVERITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
          </div>
          <div className="rounded-lg px-3 py-2 flex items-center justify-between flex-wrap gap-2" style={{ background: theme.surfaceAlt }}>
            <span className="text-xs" style={{ color: theme.textFaint }}>Artık Risk Puanı</span>
            <RiskLevelChip score={liveResidualScore} mode={mode} showDescription />
          </div>
        </div>
      )}

      <div className="grid gap-2 mb-2 sm:grid-cols-3">
        <input value={form.responsible} onChange={(e) => setForm({ ...form, responsible: e.target.value })} placeholder="Sorumlu kişi"
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
        <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
        <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}
          className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
          {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>

      <div className="grid gap-2 mb-3 sm:grid-cols-2">
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Öncelik</span>
          <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}
            className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
            {PRIORITY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Tamamlanma Yüzdesi: %{form.completionPercent}</span>
          <input type="range" min="0" max="100" step="5" value={form.completionPercent}
            onChange={(e) => setForm({ ...form, completionPercent: Number(e.target.value) })}
            className="w-full" style={{ accentColor: theme.accent }} />
        </label>
      </div>

      <div className="flex gap-2">
        <Button variant="secondary" onClick={onCancel} className="flex-1">Vazgeç</Button>
        <Button onClick={onSubmit} disabled={!form.hazard.trim() || !form.risk.trim()} className="flex-1">
          {editingId ? "Güncelle" : "Kaydet"}
        </Button>
      </div>
    </div>
  );
}
