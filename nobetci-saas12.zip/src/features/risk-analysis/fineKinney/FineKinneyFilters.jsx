import { RISK_LEVEL_FILTERS } from "../../../constants/fineKinney.js";
import { Search } from "../../../components/icons/index.jsx";

/**
 * @param {{ theme: object, search: string, onSearchChange: (v: string) => void, levelFilter: string, onLevelFilterChange: (v: string) => void }} props
 */
export default function FineKinneyFilters({ theme, search, onSearchChange, levelFilter, onLevelFilterChange }) {
  return (
    <div className="mb-3">
      <div className="relative mb-2 max-w-sm">
        <Search style={{ fontSize: "14px", color: theme.textFaint, position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)" }} />
        <input
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Tehlike veya risk ara..."
          className="w-full text-sm rounded-lg pl-8 pr-3 py-2 outline-none border"
          style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }}
        />
      </div>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {RISK_LEVEL_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => onLevelFilterChange(f.key)}
            className="text-[11px] font-semibold px-2.5 py-1.5 rounded-full whitespace-nowrap shrink-0"
            style={
              levelFilter === f.key
                ? { background: theme.accent, color: theme.onAccent }
                : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }
            }
          >
            {f.label}
          </button>
        ))}
      </div>
    </div>
  );
}
