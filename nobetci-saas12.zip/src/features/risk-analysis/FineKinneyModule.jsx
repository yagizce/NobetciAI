import { useState } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useToast } from "../../contexts/ToastContext.jsx";
import Button from "../../components/ui/Button.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import Loading from "../../components/Loading.jsx";
import ConfirmDialog from "../../components/ui/ConfirmDialog.jsx";
import { Plus, BarChart3 } from "../../components/icons/index.jsx";

import { useFineKinneyEntries } from "./fineKinney/useFineKinneyEntries.js";
import FineKinneyForm, { EMPTY_FINE_KINNEY_FORM } from "./fineKinney/FineKinneyForm.jsx";
import FineKinneyCard from "./fineKinney/FineKinneyCard.jsx";
import FineKinneyFilters from "./fineKinney/FineKinneyFilters.jsx";
import FineKinneyExportButtons from "./fineKinney/FineKinneyExportButtons.jsx";

// Orchestrator only — all real logic lives in ./fineKinney/*. This keeps the module the
// rest of the app imports (RiskAnalysisPage.jsx) unchanged while the internals stay modular.
export default function FineKinneyModule() {
  const { theme, mode } = useTheme();
  const { showToast } = useToast();
  const {
    entries, totalCount, loaded, search, setSearch, levelFilter, setLevelFilter, saveEntry, removeEntry,
  } = useFineKinneyEntries();

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FINE_KINNEY_FORM);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  function resetForm() {
    setForm(EMPTY_FINE_KINNEY_FORM);
    setEditingId(null);
    setFormOpen(false);
  }

  function openNewForm() {
    setForm(EMPTY_FINE_KINNEY_FORM);
    setEditingId(null);
    setFormOpen(true);
  }

  function openEditForm(entry) {
    setForm({
      hazard: entry.hazard, risk: entry.risk, probability: entry.probability, frequency: entry.frequency,
      severity: entry.severity, action: entry.action, responsible: entry.responsible, dueDate: entry.dueDate,
      status: entry.status, date: entry.date,
      residualProbability: entry.residualProbability ?? entry.probability,
      residualFrequency: entry.residualFrequency ?? entry.frequency,
      residualSeverity: entry.residualSeverity ?? entry.severity,
      residualSuggested: false,
      priority: entry.priority || "medium",
      completionPercent: entry.completionPercent || 0,
    });
    setEditingId(entry.id);
    setFormOpen(true);
  }

  async function handleSubmit() {
    if (!form.hazard.trim() || !form.risk.trim()) return;
    await saveEntry(form, editingId);
    showToast(editingId ? "Değerlendirme güncellendi." : "Yeni risk değerlendirmesi eklendi.", "success");
    resetForm();
  }

  async function handleConfirmDelete() {
    await removeEntry(confirmDeleteId);
    setConfirmDeleteId(null);
    showToast("Değerlendirme silindi.", "neutral");
  }

  if (!loaded) return <Loading label="Risk değerlendirmeleri yükleniyor..." />;

  return (
    <div>
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <p className="text-xs" style={{ color: theme.textFaint }}>
          Fine-Kinney yöntemi: Risk = Olasılık × Maruziyet × Şiddet
        </p>
        <div className="flex items-center gap-2">
          <FineKinneyExportButtons theme={theme} />
          <Button size="sm" onClick={openNewForm} className="flex items-center gap-1.5 shrink-0">
            <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Değerlendirme
          </Button>
        </div>
      </div>

      {formOpen && (
        <FineKinneyForm
          theme={theme}
          mode={mode}
          form={form}
          setForm={setForm}
          editingId={editingId}
          onSubmit={handleSubmit}
          onCancel={resetForm}
        />
      )}

      {totalCount > 0 && (
        <FineKinneyFilters
          theme={theme}
          search={search}
          onSearchChange={setSearch}
          levelFilter={levelFilter}
          onLevelFilterChange={setLevelFilter}
        />
      )}

      {totalCount === 0 ? (
        <EmptyState icon={BarChart3} title="Henüz risk değerlendirmesi yok" description="Fine-Kinney yöntemiyle ilk değerlendirmeni ekle." />
      ) : entries.length === 0 ? (
        <EmptyState icon={BarChart3} title="Eşleşen sonuç yok" description="Arama veya filtre kriterlerini değiştirmeyi deneyin." />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {entries.map((e) => (
            <FineKinneyCard key={e.id} entry={e} theme={theme} mode={mode} onEdit={openEditForm} onDelete={setConfirmDeleteId} />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={confirmDeleteId !== null}
        title="Değerlendirmeyi sil"
        message="Bu risk değerlendirmesini silmek istediğine emin misin? Bu işlem geri alınamaz."
        confirmLabel="Sil"
        danger
        onConfirm={handleConfirmDelete}
        onCancel={() => setConfirmDeleteId(null)}
      />
    </div>
  );
}
