import { memo } from "react";
import { getCategoryLabel, getCheckStatusStyle } from "../../../constants/periodicCheck.js";
import { Trash2 } from "../../../components/icons/index.jsx";

/**
 * @param {{ check: object, theme: object, onEdit: (check: object) => void, onDelete: (id: number) => void }} props
 */
function PeriodicCheckCard({ check, theme, onEdit, onDelete }) {
  const statusStyle = getCheckStatusStyle(check.status, theme);
  return (
    <div className="rounded-xl border px-3.5 py-3" style={{ borderColor: theme.border, background: theme.surface }}>
      <div className="flex items-start justify-between gap-2 mb-1">
        <p className="text-sm font-semibold leading-snug" style={{ color: theme.textPrimary }}>{check.itemName}</p>
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full whitespace-nowrap" style={{ background: statusStyle.bg, color: statusStyle.text }}>
          {statusStyle.label}
        </span>
      </div>
      <p className="text-xs mb-1.5" style={{ color: theme.textMuted }}>{getCategoryLabel(check.category)}</p>
      <div className="text-[11px] flex flex-wrap gap-x-3 gap-y-0.5" style={{ color: theme.textFaint }}>
        <span>Son kontrol: {check.lastCheckDate}</span>
        <span>Sonraki: {check.nextDueDate}</span>
        {check.responsible && <span>Sorumlu: {check.responsible}</span>}
      </div>
      {check.notes && <p className="text-[11px] mt-1.5" style={{ color: theme.textMuted }}>{check.notes}</p>}
      <div className="flex gap-2 mt-2">
        <button onClick={() => onEdit(check)} className="text-[11px] font-semibold" style={{ color: theme.accent }}>Düzenle</button>
        <button onClick={() => onDelete(check.id)} className="text-[11px] font-semibold flex items-center gap-0.5" style={{ color: theme.emergencyText }}>
          <Trash2 style={{ fontSize: "11px" }} /> Sil
        </button>
      </div>
    </div>
  );
}

export default memo(PeriodicCheckCard);
