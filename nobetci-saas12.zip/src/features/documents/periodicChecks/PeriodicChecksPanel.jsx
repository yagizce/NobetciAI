import { useState, useMemo } from "react";
import { useTheme } from "../../../contexts/ThemeContext.jsx";
import { useToast } from "../../../contexts/ToastContext.jsx";
import { usePeriodicChecks } from "./usePeriodicChecks.js";
import PeriodicCheckForm, { EMPTY_PERIODIC_CHECK_FORM } from "./PeriodicCheckForm.jsx";
import PeriodicCheckCard from "./PeriodicCheckCard.jsx";
import Button from "../../../components/ui/Button.jsx";
import EmptyState from "../../../components/EmptyState.jsx";
import Loading from "../../../components/Loading.jsx";
import ConfirmDialog from "../../../components/ui/ConfirmDialog.jsx";
import { Plus, ListChecks } from "../../../components/icons/index.jsx";

const STATUS_ORDER = { overdue: 0, upcoming: 1, ok: 2 };

export default function PeriodicChecksPanel() {
  const { theme } = useTheme();
  const { showToast } = useToast();
  const { checks, loaded, saveCheck, removeCheck } = usePeriodicChecks();

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_PERIODIC_CHECK_FORM);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const sortedChecks = useMemo(
    () => [...checks].sort((a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status]),
    [checks]
  );

  const summary = useMemo(() => ({
    overdue: checks.filter((c) => c.status === "overdue").length,
    upcoming: checks.filter((c) => c.status === "upcoming").length,
  }), [checks]);

  function resetForm() {
    setForm(EMPTY_PERIODIC_CHECK_FORM);
    setEditingId(null);
    setFormOpen(false);
  }

  function openNewForm() {
    setForm(EMPTY_PERIODIC_CHECK_FORM);
    setEditingId(null);
    setFormOpen(true);
  }

  function openEditForm(check) {
    setForm({
      itemName: check.itemName, category: check.category, lastCheckDate: check.lastCheckDate,
      intervalDays: check.intervalDays, responsible: check.responsible, notes: check.notes,
    });
    setEditingId(check.id);
    setFormOpen(true);
  }

  async function handleSubmit() {
    if (!form.itemName.trim() || !form.lastCheckDate) return;
    await saveCheck(form, editingId);
    showToast(editingId ? "Kontrol güncellendi." : "Yeni periyodik kontrol eklendi.", "success");
    resetForm();
  }

  async function handleConfirmDelete() {
    await removeCheck(confirmDeleteId);
    setConfirmDeleteId(null);
    showToast("Kontrol kaydı silindi.", "neutral");
  }

  if (!loaded) return <Loading label="Periyodik kontroller yükleniyor..." />;

  return (
    <div>
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2 text-xs" style={{ color: theme.textFaint }}>
          {summary.overdue > 0 && (
            <span className="font-semibold px-2 py-1 rounded-full" style={{ background: theme.highRiskBg, color: theme.highRiskText }}>
              {summary.overdue} süresi geçmiş
            </span>
          )}
          {summary.upcoming > 0 && (
            <span className="font-semibold px-2 py-1 rounded-full" style={{ background: theme.warnBg, color: theme.warnText }}>
              {summary.upcoming} yaklaşıyor
            </span>
          )}
          {summary.overdue === 0 && summary.upcoming === 0 && checks.length > 0 && <span>Tüm kontroller güncel ✓</span>}
        </div>
        <Button size="sm" onClick={openNewForm} className="flex items-center gap-1.5">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Kontrol Kaydı
        </Button>
      </div>

      {formOpen && (
        <PeriodicCheckForm theme={theme} form={form} setForm={setForm} editingId={editingId} onSubmit={handleSubmit} onCancel={resetForm} />
      )}

      {sortedChecks.length === 0 ? (
        <EmptyState icon={ListChecks} title="Henüz periyodik kontrol kaydı yok" description="Yangın tüpü, ekipman veya elektrik tesisatı gibi düzenli kontrol gerektiren kalemleri ekleyin." />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {sortedChecks.map((c) => (
            <PeriodicCheckCard key={c.id} check={c} theme={theme} onEdit={openEditForm} onDelete={setConfirmDeleteId} />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={confirmDeleteId !== null}
        title="Kontrol kaydını sil"
        message="Bu periyodik kontrol kaydını silmek istediğine emin misin?"
        confirmLabel="Sil"
        danger
        onConfirm={handleConfirmDelete}
        onCancel={() => setConfirmDeleteId(null)}
      />
    </div>
  );
}
