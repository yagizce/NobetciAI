import { useState, useEffect, useCallback } from "react";
import { getPeriodicChecks, savePeriodicCheck, deletePeriodicCheck } from "../../../services/periodicCheckService.js";
import { computeNextDueDate, computeCheckStatus } from "../../../constants/periodicCheck.js";
import { logActivity } from "../../../services/auditService.js";
import { pushSystemNotification } from "../../../services/systemNotificationService.js";
import { useRole } from "../../../contexts/RoleContext.jsx";
import { ROLES } from "../../../contexts/RoleContext.jsx";

export function usePeriodicChecks() {
  const { role } = useRole();
  const [checks, setChecks] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getPeriodicChecks().then((data) => {
      setChecks(data);
      setLoaded(true);
    });
  }, []);

  const saveCheck = useCallback(async (formValues, editingId) => {
    const nextDueDate = computeNextDueDate(formValues.lastCheckDate, formValues.intervalDays);
    const status = computeCheckStatus(nextDueDate);
    const entry = {
      id: editingId || Date.now(),
      itemName: formValues.itemName.trim(),
      category: formValues.category,
      lastCheckDate: formValues.lastCheckDate,
      intervalDays: Number(formValues.intervalDays),
      nextDueDate,
      status,
      responsible: formValues.responsible.trim(),
      notes: formValues.notes.trim(),
    };
    await savePeriodicCheck(entry);
    setChecks((prev) => {
      const exists = prev.some((c) => c.id === entry.id);
      return exists ? prev.map((c) => (c.id === entry.id ? entry : c)) : [entry, ...prev];
    });
    logActivity({
      actor: ROLES.find((r) => r.id === role)?.label || role,
      action: editingId ? "Periyodik kontrol güncellendi" : "Periyodik kontrol eklendi",
      details: entry.itemName,
      entityType: "periodicCheck",
    });
    if (status === "upcoming" || status === "overdue") {
      pushSystemNotification({
        type: "periodicCheckDue",
        title: status === "overdue" ? "Periyodik kontrol süresi geçti" : "Periyodik kontrol zamanı yaklaşıyor",
        message: `${entry.itemName} — sonraki kontrol: ${entry.nextDueDate}`,
      });
    }
    return entry;
  }, [role]);

  const removeCheck = useCallback(async (id) => {
    const check = checks.find((c) => c.id === id);
    await deletePeriodicCheck(id);
    setChecks((prev) => prev.filter((c) => c.id !== id));
    logActivity({
      actor: ROLES.find((r) => r.id === role)?.label || role,
      action: "Periyodik kontrol silindi",
      details: check?.itemName || `#${id}`,
      entityType: "periodicCheck",
    });
  }, [checks, role]);

  return { checks, loaded, saveCheck, removeCheck };
}
