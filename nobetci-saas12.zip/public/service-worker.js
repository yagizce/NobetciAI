// GEÇİCİ KILL-SWITCH — PWA/offline cache özelliği duraklatıldı (bkz. CHANGELOG.md).
//
// Bu dosya BİLEREK bu yolda (/service-worker.js) duruyor: eski, hatalı Service Worker'ı
// (cache-first stratejisi yüzünden birkaç saat sonra beyaz ekrana yol açan) zaten kayıtlı
// olan kullanıcıların tarayıcıları normal güncelleme kontrolünde bu dosyayı çekip
// devreye alacak — bu, sayfası şu an bozuk/eski pakete takılı kalmış ve taze JS
// çalıştıramayan kullanıcılar için bile işe yarar.
//
// UYARI: Bu dosyayı SİLMEYİN. Silmek, mevcut kayıtlı Service Worker'ı OTOMATİK
// KALDIRMAZ (tarayıcılar güncelleme kontrolünde 404 alırsa eski SW'yi olduğu gibi
// bırakır) — yani zaten etkilenmiş kullanıcılar kurtulamaz. Bunun yerine bu script
// kendi kendini temizleyip kaydını siliyor.
//
// Modern, sürüm yönetimli bir Service Worker (network-first JS, "yeni sürüm mevcut"
// bildirimi vb.) proje stabil olduğunda buraya yeniden eklenecek — bkz. CHANGELOG.md.

const OLD_CACHE_PREFIX = "nobetci-isg-";

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      // Bu uygulamanın oluşturduğu tüm eski cache'leri güvenli şekilde temizle.
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k.startsWith(OLD_CACHE_PREFIX)).map((k) => caches.delete(k))
      );

      // Kaydı sil — bundan sonra hiçbir isteği yakalamayacak.
      await self.registration.unregister();

      // Açık her sekmeyi bir kez yeniden yükle, böylece eski pakete takılı kalmış
      // sekmeler de artık Service Worker olmadan doğrudan ağdan taze içerik çeker.
      const clientsList = await self.clients.matchAll({ type: "window" });
      for (const client of clientsList) {
        client.navigate(client.url);
      }
    })()
  );
});
