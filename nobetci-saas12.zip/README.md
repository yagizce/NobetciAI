# Nöbetçi — İSG Yönetim Platformu

Kurumsal mimariye taşınmış sürüm: React Router, modüler `src/` yapısı, paylaşılan context'ler.

## ⚠️ Dağıtım artık farklı — okuyun

Önceki sürüm tek bir `index.html` dosyasıydı, Netlify'a zip sürükleyerek yayınlanıyordu.
Bu sürüm **npm ile derlenmesi gereken** gerçek bir React projesi. Artık zip sürükleyerek
yayınlayamazsınız — bunun yerine:

### Kurulum adımları

1. **Bu projeyi GitHub'a yükleyin** (bir repo oluşturup tüm dosyaları/klasörleri — `node_modules`
   ve `dist` hariç, zaten `.gitignore` bunları engeller — yükleyin. Klasör yapısını korumak için
   GitHub'ın "Add file → Upload files" ekranına tüm proje klasörünü sürükleyin, GitHub alt
   klasörleri otomatik korur).

2. **Netlify'da yeni bağlantı kurun:**
   - Mevcut siteniz varsa: **Site configuration → Build & deploy → Link repository**
   - Ya da: **Add new site → Import an existing project → GitHub** → bu repoyu seçin

3. **Build ayarları** (genelde `netlify.toml`'dan otomatik algılanır, kontrol edin):
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Functions directory: `netlify/functions`

4. **API anahtarını tekrar ekleyin** (yeni bağlantıda ortam değişkenleri bazen sıfırlanabilir):
   - Site configuration → Environment variables → `ANTHROPIC_API_KEY`

5. Deploy edin. Netlify kendi sunucularında `npm install` + `npm run build` çalıştırır,
   sizin bilgisayarınızda Node kurulu olmasına gerek yoktur.

## Klasör yapısı

```
src/
  components/icons/   Ortak SVG ikon bileşenleri
  layout/             Sidebar, Header, Layout (Outlet)
  pages/              Route bileşenleri (ince sarmalayıcılar)
  features/           Asıl iş mantığı (chat, risk-analysis, documents, dashboard, legislation)
  services/           API ve IndexedDB erişim katmanı
  hooks/              Genel amaçlı hook'lar
  utils/              Yardımcı fonksiyonlar
  types/              JSDoc tip tanımları
  constants/          Tema, sistem promptu, hazır sorular
  contexts/           Theme / Role / IsgData (paylaşılan state)
```

## Korunan özellikler

- AI Chat (sorgulamalı risk motoru, fotoğraf analizi, kopyala/temizle, hazır sorular)
- Bildirim Merkezi (Çalışan → AI → Uzman → İşveren akışı)
- QR ekipman takibi, Eğitim modülleri
- Dashboard metrikleri
- Dark/Light tema (artık `localStorage`'da saklanıyor)
- PWA (manifest + service worker, `/public` altında)
- Netlify Functions (`netlify/functions/chat.js` değişmedi)

## Henüz eklenmeyenler (bilinçli olarak boş bırakıldı)

- Gerçek kullanıcı kimlik doğrulama (Login/Register şu an arayüz taslağı)
- TypeScript'e tam geçiş (şimdilik JSDoc ile hafif tipleme)
