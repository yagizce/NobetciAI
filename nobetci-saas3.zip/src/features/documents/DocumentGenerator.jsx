import { useState, useEffect } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useToast } from "../../contexts/ToastContext.jsx";
import { getDocuments, saveDocument, deleteDocument } from "../../services/documentService.js";
import { DOCUMENT_TYPES, getDocumentTypeLabel } from "../../constants/documentTypes.js";
import { todayLabel } from "../../utils/dateUtils.js";
import Button from "../../components/ui/Button.jsx";
import Badge from "../../components/ui/Badge.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import Loading from "../../components/Loading.jsx";
import ConfirmDialog from "../../components/ui/ConfirmDialog.jsx";
import { Plus, FileText, Trash2 } from "../../components/icons/index.jsx";

export default function DocumentGenerator() {
  const { theme } = useTheme();
  const { showToast } = useToast();
  const [documents, setDocuments] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [type, setType] = useState(DOCUMENT_TYPES[0].value);
  const [title, setTitle] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  useEffect(() => {
    getDocuments().then((docs) => { setDocuments(docs); setLoaded(true); });
  }, []);

  async function createDocument() {
    if (!title.trim()) return;
    const doc = {
      id: Date.now(),
      type,
      title: title.trim(),
      createdBy: "Ahmet Yıldız",
      createdAt: todayLabel(),
      status: "draft",
      content: "", // placeholder — AI-assisted generation will fill this in a later step
    };
    await saveDocument(doc);
    setDocuments((prev) => [doc, ...prev]);
    setTitle("");
    setFormOpen(false);
    showToast("Belge taslağı oluşturuldu.", "success");
  }

  async function confirmDelete() {
    await deleteDocument(confirmDeleteId);
    setDocuments((prev) => prev.filter((d) => d.id !== confirmDeleteId));
    setConfirmDeleteId(null);
    showToast("Belge silindi.", "neutral");
  }

  if (!loaded) return <Loading label="Belgeler yükleniyor..." />;

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs" style={{ color: theme.textFaint }}>
          Belge türü ve başlık seçerek taslak oluşturun. İçerik üretimi yakında AI ile eklenecek.
        </p>
        <Button size="sm" onClick={() => setFormOpen((v) => !v)} className="flex items-center gap-1.5 shrink-0">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Belge
        </Button>
      </div>

      {formOpen && (
        <div className="rounded-xl border px-3.5 py-3 mb-4 max-w-md" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
          <label className="block mb-2">
            <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Belge Türü</span>
            <select value={type} onChange={(e) => setType(e.target.value)}
              className="w-full text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
              {DOCUMENT_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Belge başlığı (örn. Depo B Risk Analizi)"
            className="w-full text-sm rounded-lg px-3 py-2 mb-3 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setFormOpen(false)} className="flex-1">Vazgeç</Button>
            <Button onClick={createDocument} disabled={!title.trim()} className="flex-1">Oluştur</Button>
          </div>
        </div>
      )}

      {documents.length === 0 ? (
        <EmptyState icon={FileText} title="Henüz belge yok" description="Yukarıdan yeni bir belge taslağı oluşturabilirsin." />
      ) : (
        <div className="grid gap-2 md:grid-cols-2">
          {documents.map((d) => (
            <div key={d.id} className="rounded-lg border px-3.5 py-3" style={{ borderColor: theme.border, background: theme.surface }}>
              <div className="flex items-start justify-between gap-2 mb-1">
                <p className="text-sm font-semibold" style={{ color: theme.textPrimary }}>{d.title}</p>
                <Badge tone={d.status === "completed" ? "success" : "pending"}>{d.status === "completed" ? "Tamamlandı" : "Taslak"}</Badge>
              </div>
              <p className="text-xs mb-1.5" style={{ color: theme.textMuted }}>{getDocumentTypeLabel(d.type)}</p>
              <p className="text-[11px]" style={{ color: theme.textFaint }}>{d.createdBy} • {d.createdAt}</p>
              <button onClick={() => setConfirmDeleteId(d.id)} className="text-[11px] font-semibold flex items-center gap-0.5 mt-2" style={{ color: theme.emergencyText }}>
                <Trash2 style={{ fontSize: "11px" }} /> Sil
              </button>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={confirmDeleteId !== null}
        title="Belgeyi sil"
        message="Bu belgeyi silmek istediğine emin misin?"
        confirmLabel="Sil"
        danger
        onConfirm={confirmDelete}
        onCancel={() => setConfirmDeleteId(null)}
      />
    </div>
  );
}
