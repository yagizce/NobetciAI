import { useState, useMemo, useCallback } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useRole } from "../../contexts/RoleContext.jsx";
import { useIsgData } from "../../contexts/IsgDataContext.jsx";
import { useToast } from "../../contexts/ToastContext.jsx";
import { SYSTEM_PROMPT } from "../../constants/systemPrompt.js";
import { sendChatMessage } from "../../services/chatService.js";
import { todayLabel } from "../../utils/dateUtils.js";
import { Plus, ShieldAlert, BarChart3, Bell } from "../../components/icons/index.jsx";
import Button from "../../components/ui/Button.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import NotificationCard from "./NotificationCard.jsx";
import FineKinneyModule from "./FineKinneyModule.jsx";

const TYPE_LABELS = { ramakKala: "Ramak Kala", tehlike: "Tehlike", kaza: "İş Kazası" };

function NotificationCenterTab({ theme, role }) {
  const { notifications, addNotification, updateNotification } = useIsgData();
  const { showToast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [desc, setDesc] = useState("");
  const [type, setType] = useState("ramakKala");

  const submitNotification = useCallback(async () => {
    if (!desc.trim()) return;
    const notif = { id: Date.now(), type, desc: desc.trim(), status: "pending", worker: "Ahmet Yıldız", date: todayLabel(), aiAnalysis: null, expertNote: null };
    addNotification(notif);
    setDesc("");
    setFormOpen(false);
    showToast("Bildirim gönderildi, AI analiz ediyor...", "neutral");

    try {
      const reply = await sendChatMessage({
        system: SYSTEM_PROMPT,
        max_tokens: 600,
        messages: [{ role: "user", content: `Bildirim türü: ${TYPE_LABELS[type]}. Açıklama: "${notif.desc}". Bu bildirime kısa bir ön analiz yap: olası risk seviyesi (gerekçeli) ve İSG uzmanının dikkat etmesi gereken noktalar. 3-4 madde, kısa.` }],
      });
      updateNotification(notif.id, { status: "ai_analyzed", aiAnalysis: reply || "AI analizi alınamadı." });
      showToast("AI analizi tamamlandı, uzman incelemesine düştü.", "success");
    } catch {
      updateNotification(notif.id, { status: "ai_analyzed", aiAnalysis: "AI analizine şu an ulaşılamadı, uzman manuel değerlendirebilir." });
      showToast("AI analizine ulaşılamadı, uzman manuel değerlendirecek.", "error");
    }
  }, [desc, type, addNotification, updateNotification, showToast]);

  const expertApprove = useCallback((id) => {
    updateNotification(id, { status: "approved", expertNote: "Uzman tarafından onaylandı, göreve dönüştürüldü." });
    showToast("Bildirim onaylandı ve göreve dönüştürüldü.", "success");
  }, [updateNotification, showToast]);

  const visibleNotifications = useMemo(() => notifications.filter((n) =>
    role === "employee" ? n.worker === "Ahmet Yıldız" : role === "expert" ? true : n.status === "approved"
  ), [notifications, role]);

  return (
    <div>
      {role === "employee" && (
        <Button onClick={() => setFormOpen((v) => !v)} className="mb-3 flex items-center gap-1.5">
          <Plus style={{ fontSize: "14px" }} sw={2.5} /> Yeni Bildirim
        </Button>
      )}

      {formOpen && role === "employee" && (
        <div className="rounded-xl border px-3.5 py-3 mb-4 max-w-md" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
          <div className="flex gap-2 mb-2">
            {Object.entries(TYPE_LABELS).map(([val, label]) => (
              <button key={val} onClick={() => setType(val)} className="flex-1 text-[11px] py-1.5 rounded-lg font-semibold"
                style={type === val ? { background: theme.accent, color: theme.onAccent } : { background: theme.surface, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
                {label}
              </button>
            ))}
          </div>
          <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Ne oldu, nerede? Kısaca açıklayın..." rows={3}
            className="w-full text-sm rounded-lg px-3 py-2 mb-2 outline-none border resize-none" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
          <Button onClick={submitNotification} disabled={!desc.trim()} className="w-full">Gönder</Button>
        </div>
      )}

      {visibleNotifications.length === 0 && (
        <EmptyState icon={ShieldAlert} title="Henüz bildirim yok" description="Yeni bir bildirim oluşturduğunuzda burada görünecek." />
      )}

      <div className="grid gap-2.5 md:grid-cols-2">
        {visibleNotifications.map((n) => (
          <NotificationCard
            key={n.id}
            notification={n}
            theme={theme}
            showApprove={role === "expert" && n.status === "ai_analyzed"}
            onApprove={expertApprove}
          />
        ))}
      </div>
    </div>
  );
}

export default function RiskAnalysisPage() {
  const { theme } = useTheme();
  const { role } = useRole();
  const [tab, setTab] = useState("notifications");

  return (
    <div className="px-4 md:px-8 py-6 max-w-3xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-1" style={{ color: theme.textPrimary }}>Risk Analizi</p>
      <p className="text-xs mb-4" style={{ color: theme.textFaint }}>Bildirim Merkezi ve Fine-Kinney risk değerlendirmesi bir arada</p>

      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab("notifications")} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full"
          style={tab === "notifications" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
          <Bell style={{ fontSize: "13px" }} /> Bildirim Merkezi
        </button>
        <button onClick={() => setTab("fineKinney")} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full"
          style={tab === "fineKinney" ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
          <BarChart3 style={{ fontSize: "13px" }} /> Fine-Kinney Değerlendirmesi
        </button>
      </div>

      {tab === "notifications" ? <NotificationCenterTab theme={theme} role={role} /> : <FineKinneyModule />}
    </div>
  );
}
