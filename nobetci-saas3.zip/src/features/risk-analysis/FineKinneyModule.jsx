import { useState, useEffect, useCallback } from "react";
import { useTheme } from "../../contexts/ThemeContext.jsx";
import { useToast } from "../../contexts/ToastContext.jsx";
import { getFineKinneyEntries, saveFineKinneyEntry, deleteFineKinneyEntry } from "../../services/riskService.js";
import { PROBABILITY_SCALE, FREQUENCY_SCALE, SEVERITY_SCALE, STATUS_OPTIONS, computeFineKinneyScore, getFineKinneyRiskLevel } from "../../constants/fineKinney.js";
import Button from "../../components/ui/Button.jsx";
import Badge from "../../components/ui/Badge.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import Loading from "../../components/Loading.jsx";
import ConfirmDialog from "../../components/ui/ConfirmDialog.jsx";
import { Plus, BarChart3, Trash2 } from "../../components/icons/index.jsx";

const EMPTY_FORM = { hazard: "", risk: "", probability: 1, frequency: 1, severity: 1, action: "", responsible: "", dueDate: "", status: "open" };

export default function FineKinneyModule() {
  const { theme } = useTheme();
  const { showToast } = useToast();
  const [entries, setEntries] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  useEffect(() => {
    getFineKinneyEntries().then((data) => { setEntries(data); setLoaded(true); });
  }, []);

  const resetForm = useCallback(() => {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setFormOpen(false);
  }, []);

  function openNewForm() {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setFormOpen(true);
  }

  function openEditForm(entry) {
    setForm({
      hazard: entry.hazard, risk: entry.risk, probability: entry.probability, frequency: entry.frequency,
      severity: entry.severity, action: entry.action, responsible: entry.responsible, dueDate: entry.dueDate, status: entry.status,
    });
    setEditingId(entry.id);
    setFormOpen(true);
  }

  async function submitForm() {
    if (!form.hazard.trim() || !form.risk.trim()) return;
    const score = computeFineKinneyScore(Number(form.probability), Number(form.frequency), Number(form.severity));
    const riskLevel = getFineKinneyRiskLevel(score).label;
    const entry = {
      id: editingId || Date.now(),
      hazard: form.hazard.trim(),
      risk: form.risk.trim(),
      probability: Number(form.probability),
      frequency: Number(form.frequency),
      severity: Number(form.severity),
      score,
      riskLevel,
      action: form.action.trim(),
      responsible: form.responsible.trim(),
      dueDate: form.dueDate,
      status: form.status,
    };
    await saveFineKinneyEntry(entry);
    setEntries((prev) => {
      const exists = prev.some((e) => e.id === entry.id);
      return exists ? prev.map((e) => (e.id === entry.id ? entry : e)) : [entry, ...prev];
    });
    showToast(editingId ? "Değerlendirme güncellendi." : "Yeni risk değerlendirmesi eklendi.", "success");
    resetForm();
  }

  async function confirmDelete() {
    await deleteFineKinneyEntry(confirmDeleteId);
    setEntries((prev) => prev.filter((e) => e.id !== confirmDeleteId));
    setConfirmDeleteId(null);
    showToast("Değerlendirme silindi.", "neutral");
  }

  if (!loaded) return <Loading label="Risk değerlendirmeleri yükleniyor..." />;

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs" style={{ color: theme.textFaint }}>
          Fine-Kinney yöntemi: Puan = Olasılık × Frekans × Şiddet
        </p>
        <Button size="sm" onClick={openNewForm} className="flex items-center gap-1.5 shrink-0">
          <Plus style={{ fontSize: "13px" }} sw={2.5} /> Yeni Değerlendirme
        </Button>
      </div>

      {formOpen && (
        <div className="rounded-xl border px-3.5 py-3 mb-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
          <div className="grid gap-2 mb-2 sm:grid-cols-2">
            <input value={form.hazard} onChange={(e) => setForm({ ...form, hazard: e.target.value })} placeholder="Tehlike (örn. Yüksekte korkuluksuz çalışma)"
              className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
            <input value={form.risk} onChange={(e) => setForm({ ...form, risk: e.target.value })} placeholder="Risk (örn. Yüksekten düşme)"
              className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
          </div>

          <div className="grid gap-2 mb-2 sm:grid-cols-3">
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Olasılık</span>
              <select value={form.probability} onChange={(e) => setForm({ ...form, probability: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
                {PROBABILITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Frekans</span>
              <select value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
                {FREQUENCY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="block text-[10.5px] mb-1" style={{ color: theme.textFaint }}>Şiddet</span>
              <select value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}
                className="w-full text-xs rounded-lg px-2 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
                {SEVERITY_SCALE.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
          </div>

          <div className="rounded-lg px-3 py-2 mb-2 flex items-center justify-between" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}>
            <span className="text-xs" style={{ color: theme.textFaint }}>Otomatik Puan</span>
            {(() => {
              const liveScore = computeFineKinneyScore(Number(form.probability), Number(form.frequency), Number(form.severity));
              const liveLevel = getFineKinneyRiskLevel(liveScore);
              return (
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold" style={{ color: theme.textPrimary }}>{liveScore}</span>
                  <Badge tone={liveLevel.tone}>{liveLevel.label}</Badge>
                </div>
              );
            })()}
          </div>

          <textarea value={form.action} onChange={(e) => setForm({ ...form, action: e.target.value })} placeholder="Alınacak önlem" rows={2}
            className="w-full text-sm rounded-lg px-3 py-2 mb-2 outline-none border resize-none" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />

          <div className="grid gap-2 mb-3 sm:grid-cols-3">
            <input value={form.responsible} onChange={(e) => setForm({ ...form, responsible: e.target.value })} placeholder="Sorumlu kişi"
              className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
            <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }} />
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}
              className="text-sm rounded-lg px-3 py-2 outline-none border" style={{ background: theme.surface, borderColor: theme.border, color: theme.textPrimary }}>
              {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={resetForm} className="flex-1">Vazgeç</Button>
            <Button onClick={submitForm} disabled={!form.hazard.trim() || !form.risk.trim()} className="flex-1">
              {editingId ? "Güncelle" : "Kaydet"}
            </Button>
          </div>
        </div>
      )}

      {entries.length === 0 ? (
        <EmptyState icon={BarChart3} title="Henüz risk değerlendirmesi yok" description="Fine-Kinney yöntemiyle ilk değerlendirmeni ekle." />
      ) : (
        <div className="grid gap-2.5 md:grid-cols-2">
          {entries.map((e) => {
            const level = getFineKinneyRiskLevel(e.score);
            const statusLabel = STATUS_OPTIONS.find((s) => s.value === e.status)?.label || e.status;
            return (
              <div key={e.id} className="rounded-xl border px-3.5 py-3" style={{ borderColor: theme.border, background: theme.surface }}>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-sm font-semibold leading-snug" style={{ color: theme.textPrimary }}>{e.hazard}</p>
                  <Badge tone={level.tone}>{e.score} — {level.label}</Badge>
                </div>
                <p className="text-xs mb-1.5" style={{ color: theme.textMuted }}>{e.risk}</p>
                {e.action && <p className="text-[11.5px] mb-1.5" style={{ color: theme.textMuted }}>Önlem: {e.action}</p>}
                <div className="flex items-center justify-between text-[11px]" style={{ color: theme.textFaint }}>
                  <span>{e.responsible || "—"} {e.dueDate && `• ${e.dueDate}`}</span>
                  <Badge tone="neutral">{statusLabel}</Badge>
                </div>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => openEditForm(e)} className="text-[11px] font-semibold" style={{ color: theme.accent }}>Düzenle</button>
                  <button onClick={() => setConfirmDeleteId(e.id)} className="text-[11px] font-semibold flex items-center gap-0.5" style={{ color: theme.emergencyText }}>
                    <Trash2 style={{ fontSize: "11px" }} /> Sil
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ConfirmDialog
        open={confirmDeleteId !== null}
        title="Değerlendirmeyi sil"
        message="Bu risk değerlendirmesini silmek istediğine emin misin? Bu işlem geri alınamaz."
        confirmLabel="Sil"
        danger
        onConfirm={confirmDelete}
        onCancel={() => setConfirmDeleteId(null)}
      />
    </div>
  );
}
