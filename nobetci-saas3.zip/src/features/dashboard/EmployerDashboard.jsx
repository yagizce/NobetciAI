import { useMemo, useState, useEffect } from "react";
import { useIsgData } from "../../contexts/IsgDataContext.jsx";
import { getCurrentUser } from "../../services/authService.js";
import { getCompanyById } from "../../constants/companies.js";
import { MOCK_EMPLOYEES } from "../../constants/mockEmployees.js";
import { EDUCATION_MODULES } from "../../constants/education.js";
import EmptyState from "../../components/EmptyState.jsx";
import Badge from "../../components/ui/Badge.jsx";
import { ShieldAlert, Users } from "../../components/icons/index.jsx";

/**
 * @param {{ theme: object }} props
 */
export default function EmployerDashboard({ theme }) {
  const { notifications } = useIsgData();
  const [company, setCompany] = useState(null);

  useEffect(() => {
    getCurrentUser("employer").then((user) => setCompany(getCompanyById(user.companyId)));
  }, []);

  const riskAnalyses = useMemo(() => notifications.filter((n) => n.status === "approved"), [notifications]);

  return (
    <div className="px-4 md:px-8 py-6 max-w-4xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-4" style={{ color: theme.textPrimary }}>İşveren Paneli</p>

      {company && (
        <div className="rounded-xl border px-4 py-3 mb-5" style={{ borderColor: theme.border, background: theme.surface }}>
          <p className="text-sm font-semibold" style={{ color: theme.textPrimary }}>{company.name}</p>
          <p className="text-xs mt-0.5" style={{ color: theme.textFaint }}>{company.sector} • {company.employeeCount} çalışan</p>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <section>
          <p className="text-sm font-semibold mb-2" style={{ color: theme.textPrimary }}>Risk Analizleri</p>
          {riskAnalyses.length === 0 ? (
            <EmptyState icon={ShieldAlert} title="Onaylanmış risk analizi yok" />
          ) : (
            <div className="grid gap-2">
              {riskAnalyses.map((n) => (
                <div key={n.id} className="rounded-lg border px-3 py-2.5" style={{ borderColor: theme.border, background: theme.surface }}>
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm" style={{ color: theme.textPrimary }}>{n.desc}</p>
                    <Badge tone="success">Onaylı</Badge>
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: theme.textFaint }}>{n.date}</p>
                </div>
              ))}
            </div>
          )}
        </section>

        <section>
          <p className="text-sm font-semibold mb-2 flex items-center gap-1.5" style={{ color: theme.textPrimary }}>
            <Users style={{ fontSize: "14px" }} /> Çalışanlar
          </p>
          <div className="grid gap-2">
            {MOCK_EMPLOYEES.map((e) => (
              <div key={e.id} className="rounded-lg border px-3 py-2 flex items-center justify-between" style={{ borderColor: theme.border, background: theme.surface }}>
                <div>
                  <p className="text-sm" style={{ color: theme.textPrimary }}>{e.name}</p>
                  <p className="text-xs" style={{ color: theme.textFaint }}>{e.position}</p>
                </div>
                <Badge tone={e.status === "Aktif" ? "success" : "neutral"}>{e.status}</Badge>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="mt-4">
        <p className="text-sm font-semibold mb-2" style={{ color: theme.textPrimary }}>Eğitimler</p>
        <div className="grid gap-2 md:grid-cols-2">
          {EDUCATION_MODULES.map((title) => (
            <div key={title} className="rounded-lg border px-3 py-2.5" style={{ borderColor: theme.border, background: theme.surface }}>
              <p className="text-sm font-medium" style={{ color: theme.textPrimary }}>{title}</p>
              <p className="text-xs mt-0.5" style={{ color: theme.textMuted }}>Zorunlu Eğitim</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
