import { useTheme } from "../contexts/ThemeContext.jsx";
import { useRole, ROLES } from "../contexts/RoleContext.jsx";
import { useDocumentTitle } from "../hooks/useDocumentTitle.js";

export default function Settings() {
  useDocumentTitle("Ayarlar");
  const { theme } = useTheme();
  const { role, setRole } = useRole();

  return (
    <div className="px-4 md:px-8 py-6 max-w-2xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-4" style={{ color: theme.textPrimary }}>Ayarlar</p>

      <p className="text-xs mb-4" style={{ color: theme.textFaint }}>
        Görünüm (açık/koyu tema) sağ üstteki başlık çubuğundan değiştirilir ve tarayıcınızda hatırlanır.
      </p>

      <div className="rounded-xl border px-4 py-4" style={{ borderColor: theme.border, background: theme.surface }}>
        <p className="text-sm font-semibold mb-2" style={{ color: theme.textPrimary }}>Rol (Demo)</p>
        <div className="flex gap-2">
          {ROLES.map((r) => (
            <button key={r.id} onClick={() => setRole(r.id)} className="flex-1 text-xs font-semibold py-2 rounded-lg flex items-center justify-center gap-1"
              style={role === r.id ? { background: theme.accent, color: theme.onAccent } : { background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}>
              <span>{r.emoji}</span>{r.label}
            </button>
          ))}
        </div>
        <p className="text-[11px] mt-2" style={{ color: theme.textFaint }}>
          Bu, farklı kullanıcı rollerinin arayüzü nasıl gördüğünü göstermek için bir demo seçicidir; gerçek kimlik doğrulama değildir.
        </p>
      </div>
    </div>
  );
}
