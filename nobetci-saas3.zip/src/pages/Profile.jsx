import { useState, useEffect } from "react";
import { useTheme } from "../contexts/ThemeContext.jsx";
import { useRole, ROLES } from "../contexts/RoleContext.jsx";
import { useDocumentTitle } from "../hooks/useDocumentTitle.js";
import { getCurrentUser } from "../services/authService.js";
import { getCompanyById } from "../constants/companies.js";
import { UserRound } from "../components/icons/index.jsx";
import Loading from "../components/Loading.jsx";
import Badge from "../components/ui/Badge.jsx";

const SUBSCRIPTION_LABELS = { trial: "Deneme Sürümü", pro: "Pro", enterprise: "Kurumsal" };

export default function Profile() {
  useDocumentTitle("Profil");
  const { theme } = useTheme();
  const { role } = useRole();
  const currentRole = ROLES.find((r) => r.id === role);
  const [user, setUser] = useState(null);

  useEffect(() => {
    getCurrentUser(role).then(setUser);
  }, [role]);

  if (!user) return <Loading label="Profil yükleniyor..." />;

  const company = getCompanyById(user.companyId);

  return (
    <div className="px-4 md:px-8 py-6 max-w-2xl mx-auto">
      <p className="font-[Oswald] text-xl uppercase tracking-wide mb-4" style={{ color: theme.textPrimary }}>Profil</p>

      <div className="rounded-xl border px-4 py-4 flex items-center gap-3 mb-4" style={{ borderColor: theme.border, background: theme.surface }}>
        <div className="w-14 h-14 rounded-full border flex items-center justify-center" style={{ background: theme.surfaceAlt, borderColor: theme.border }}>
          <UserRound style={{ fontSize: "28px", color: theme.accent }} />
        </div>
        <div>
          <p className="font-semibold text-base" style={{ color: theme.textPrimary }}>{user.name}</p>
          <p className="text-xs" style={{ color: theme.textFaint }}>{currentRole?.emoji} {currentRole?.label} • {company?.name || "Şirket bilgisi yok"}</p>
        </div>
      </div>

      <div className="rounded-xl border px-4 py-4 mb-4" style={{ borderColor: theme.border, background: theme.surface }}>
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs" style={{ color: theme.textFaint }}>E-posta</span>
          <span className="text-sm" style={{ color: theme.textPrimary }}>{user.email}</span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs" style={{ color: theme.textFaint }}>Şirket</span>
          <span className="text-sm" style={{ color: theme.textPrimary }}>{company?.name} <span style={{ color: theme.textFaint }}>({company?.sector})</span></span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs" style={{ color: theme.textFaint }}>Abonelik</span>
          <Badge tone={user.subscription === "trial" ? "warning" : "success"}>{SUBSCRIPTION_LABELS[user.subscription]}</Badge>
        </div>
      </div>

      <div className="rounded-xl border px-4 py-4" style={{ borderColor: theme.border, background: theme.surfaceAlt }}>
        <p className="text-xs" style={{ color: theme.textMuted }}>
          Bu demo sürümde kullanıcı bilgisi rol bazlı sahte (mock) bir servisten geliyor — üstteki rol anahtarını değiştirdiğinde farklı bir kullanıcı olarak görünürsün. Gerçek kimlik doğrulama eklenince yalnızca <code>src/services/authService.js</code> değişecek.
        </p>
      </div>
    </div>
  );
}
