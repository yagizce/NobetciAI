// riskService — Fine-Kinney risk assessment storage is real and working (local IndexedDB,
// no network). `scoreRisk()` remains a placeholder: that name is reserved for a future
// dedicated AI/backend risk-scoring endpoint. Free-text risk analysis (the questioning AI
// risk engine) still happens via chatService directly from RiskAnalysisPage — that's
// intentional, it's a conversational flow rather than structured Fine-Kinney data entry.

import { loadAllData, saveData, deleteData } from "./db.js";

/**
 * @returns {Promise<import("../types/index.js").FineKinneyEntry[]>}
 */
export async function getFineKinneyEntries() {
  return loadAllData("fineKinney");
}

/**
 * @param {import("../types/index.js").FineKinneyEntry} entry
 */
export async function saveFineKinneyEntry(entry) {
  return saveData("fineKinney", entry);
}

/**
 * @param {number} id
 */
export async function deleteFineKinneyEntry(id) {
  return deleteData("fineKinney", id);
}

/**
 * Not implemented yet — reserved for a future dedicated risk-scoring endpoint
 * (e.g. an AI service that suggests Fine-Kinney values from a free-text description).
 * @param {{description: string, type: string}} _input
 * @returns {Promise<never>}
 */
export async function scoreRisk(_input) {
  throw new Error("riskService.scoreRisk henüz uygulanmadı.");
}
