// documentService — wraps equipment/document storage (IndexedDB via services/db.js).
// Kept separate from chatService because it doesn't touch the network/API at all.
//
// Document generation is UI + data model only right now (see constants/documentTypes.js).
// `content` on a DocumentRecord is a placeholder until AI-assisted generation is added —
// at that point, creating a document will likely call chatService to fill `content`,
// but the storage shape below already supports that without changes.

import { loadAllData, saveData, deleteData } from "./db.js";

/**
 * @returns {Promise<import("../types/index.js").Equipment[]>}
 */
export async function getEquipment() {
  return loadAllData("equipment");
}

/**
 * @param {import("../types/index.js").Equipment} equipment
 */
export async function saveEquipment(equipment) {
  return saveData("equipment", equipment);
}

/**
 * @returns {Promise<import("../types/index.js").DocumentRecord[]>}
 */
export async function getDocuments() {
  return loadAllData("documents");
}

/**
 * @param {import("../types/index.js").DocumentRecord} document
 */
export async function saveDocument(document) {
  return saveData("documents", document);
}

/**
 * @param {number} id
 */
export async function deleteDocument(id) {
  return deleteData("documents", id);
}
