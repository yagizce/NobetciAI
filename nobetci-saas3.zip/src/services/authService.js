// authService — MOCK implementation. There is no real backend authentication yet.
// This exists so the rest of the app (Header, Profile, Dashboards) can be built against
// a stable User shape now, and swapped for real auth (e.g. Supabase Auth, Auth0) later
// without touching consuming components — only this file would change.
//
// Role-based routing readiness: once real login exists, the backend will return a User
// with a fixed `role` ("expert" | "employer" | "employee"), and the app should navigate
// straight to that role's dashboard view instead of showing a role picker. The demo role
// switcher (RoleContext) stands in for that "logged in as" state until then.

import { MOCK_USERS } from "../constants/mockUsers.js";

/**
 * @param {"expert"|"employer"|"employee"} [role] — which mock identity to return.
 *   In a real system this parameter wouldn't exist; the server would already know who's logged in.
 * @returns {Promise<import("../types/index.js").User>}
 */
export async function getCurrentUser(role = "employee") {
  const user = MOCK_USERS[role] || MOCK_USERS.employee;
  // Simulated network delay so loading states can be exercised meaningfully.
  return new Promise((resolve) => setTimeout(() => resolve({ ...user }), 150));
}

/**
 * Placeholder — will call a real backend once auth is implemented.
 * @returns {Promise<{success: boolean, message: string}>}
 */
export async function loginWithCredentials(_email, _password) {
  return { success: false, message: "Gerçek kimlik doğrulama henüz bağlı değil (mock servis)." };
}
