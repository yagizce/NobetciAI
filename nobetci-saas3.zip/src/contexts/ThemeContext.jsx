import { createContext, useContext, useState, useEffect } from "react";
import { THEMES } from "../constants/theme.js";

const ThemeContext = createContext(null);
const STORAGE_KEY = "nobetci-theme-mode";

export function ThemeProvider({ children }) {
  const [mode, setMode] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || "light";
    } catch {
      return "light";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, mode);
    } catch {
      // localStorage unavailable (e.g. private browsing) — theme just won't persist
    }
  }, [mode]);

  const toggleMode = () => setMode((m) => (m === "light" ? "dark" : "light"));
  const theme = THEMES[mode];

  return (
    <ThemeContext.Provider value={{ mode, setMode, toggleMode, theme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within a ThemeProvider");
  return ctx;
}
