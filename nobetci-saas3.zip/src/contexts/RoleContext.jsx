import { createContext, useContext, useState, useEffect } from "react";

const RoleContext = createContext(null);
const STORAGE_KEY = "nobetci-role";

// Role values are fixed to these three — matches the future real-auth User.role enum exactly,
// so swapping this demo switcher for real login later requires no changes elsewhere.
export const ROLES = [
  { id: "expert", emoji: "🦺", label: "Uzman" },
  { id: "employer", emoji: "👨‍💼", label: "İşveren" },
  { id: "employee", emoji: "👷", label: "Çalışan" },
];

export function RoleProvider({ children }) {
  const [role, setRole] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || "employee";
    } catch {
      return "employee";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, role);
    } catch {
      // ignore
    }
  }, [role]);

  return <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>;
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within a RoleProvider");
  return ctx;
}
