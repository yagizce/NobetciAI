import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { loadAllData, saveData } from "../services/db.js";
import { getEquipment, saveEquipment } from "../services/documentService.js";

const IsgDataContext = createContext(null);

export function IsgDataProvider({ children }) {
  const [equipmentList, setEquipmentList] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([getEquipment(), loadAllData("notifications")]).then(([eq, notif]) => {
      setEquipmentList(eq);
      setNotifications(notif);
      setLoaded(true);
    });
  }, []);

  const addEquipment = useCallback((eq) => {
    setEquipmentList((prev) => [...prev, eq]);
    saveEquipment(eq);
  }, []);

  const addNotification = useCallback((notif) => {
    setNotifications((prev) => [notif, ...prev]);
    saveData("notifications", notif);
  }, []);

  const updateNotification = useCallback((id, patch) => {
    setNotifications((prev) => {
      const updated = prev.map((n) => (n.id === id ? { ...n, ...patch } : n));
      const changed = updated.find((n) => n.id === id);
      if (changed) saveData("notifications", changed);
      return updated;
    });
  }, []);

  return (
    <IsgDataContext.Provider value={{ equipmentList, notifications, loaded, addEquipment, addNotification, updateNotification }}>
      {children}
    </IsgDataContext.Provider>
  );
}

export function useIsgData() {
  const ctx = useContext(IsgDataContext);
  if (!ctx) throw new Error("useIsgData must be used within an IsgDataProvider");
  return ctx;
}
