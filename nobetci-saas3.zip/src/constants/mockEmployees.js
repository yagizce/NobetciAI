// Mock employee directory for the Employer Dashboard's "Çalışanlar" section.
// Once a real backend exists, this becomes a query scoped to the employer's companyId.
export const MOCK_EMPLOYEES = [
  { id: "emp_001", name: "Ahmet Yıldız", position: "Saha Operatörü", status: "Aktif" },
  { id: "emp_002", name: "Zeynep Arslan", position: "Forklift Operatörü", status: "Aktif" },
  { id: "emp_003", name: "Mustafa Şahin", position: "Kaynakçı", status: "İzinli" },
  { id: "emp_004", name: "Elif Koç", position: "Depo Sorumlusu", status: "Aktif" },
];
