// Fine-Kinney risk assessment method: Score = Olasılık (Probability) × Frekans (Frequency) × Şiddet (Severity)
// Standard scale values and thresholds — widely used reference values for this method.

export const PROBABILITY_SCALE = [
  { value: 0.2, label: "0.2 — Beklenmez" },
  { value: 0.5, label: "0.5 — Mümkün ama uzak ihtimal" },
  { value: 1, label: "1 — Nadiren mümkün" },
  { value: 3, label: "3 — Mümkün" },
  { value: 6, label: "6 — Oldukça mümkün" },
  { value: 10, label: "10 — Beklenen bir durum" },
];

export const FREQUENCY_SCALE = [
  { value: 0.5, label: "0.5 — Yılda birkaç kez" },
  { value: 1, label: "1 — Yılda bir" },
  { value: 2, label: "2 — Ayda bir" },
  { value: 3, label: "3 — Haftada bir" },
  { value: 6, label: "6 — Günde bir" },
  { value: 10, label: "10 — Sürekli" },
];

export const SEVERITY_SCALE = [
  { value: 1, label: "1 — Küçük, ilkyardım gerektiren" },
  { value: 3, label: "3 — Önemli, tedavi gerektiren" },
  { value: 7, label: "7 — Ciddi, iş göremezlik" },
  { value: 15, label: "15 — Çok ciddi, kalıcı hasar" },
  { value: 40, label: "40 — Felaket, tek ölüm" },
  { value: 100, label: "100 — Çok büyük felaket, çoklu ölüm" },
];

export const STATUS_OPTIONS = [
  { value: "open", label: "Açık" },
  { value: "in_progress", label: "Devam Ediyor" },
  { value: "done", label: "Tamamlandı" },
];

/**
 * @param {number} probability
 * @param {number} frequency
 * @param {number} severity
 * @returns {number}
 */
export function computeFineKinneyScore(probability, frequency, severity) {
  return probability * frequency * severity;
}

/**
 * @param {number} score
 * @returns {{ label: string, tone: "success"|"warning"|"danger"|"pending" }}
 */
export function getFineKinneyRiskLevel(score) {
  if (score < 20) return { label: "Düşük Risk", tone: "success" };
  if (score < 70) return { label: "Olası Risk", tone: "pending" };
  if (score < 200) return { label: "Önemli Risk", tone: "warning" };
  if (score < 400) return { label: "Yüksek Risk", tone: "danger" };
  return { label: "Çok Yüksek Risk", tone: "danger" };
}
