import { useTheme } from "../../contexts/ThemeContext.jsx";

/**
 * @param {{ value: string, onChange: (e: any) => void, placeholder?: string, type?: string, label?: string, className?: string }} props
 */
export default function Input({ value, onChange, placeholder, type = "text", label, className = "", ...rest }) {
  const { theme } = useTheme();
  return (
    <label className={`block ${className}`}>
      {label && <span className="block text-xs font-medium mb-1" style={{ color: theme.textMuted }}>{label}</span>}
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full text-sm rounded-lg px-3 py-2.5 outline-none border"
        style={{ background: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }}
        {...rest}
      />
    </label>
  );
}
