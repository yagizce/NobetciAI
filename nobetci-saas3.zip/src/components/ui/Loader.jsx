import { useTheme } from "../../contexts/ThemeContext.jsx";

/**
 * Small inline spinner — use inside buttons or compact areas.
 * For a full-page loading state, use components/Loading.jsx instead.
 * @param {{ size?: number }} props
 */
export default function Loader({ size = 16 }) {
  const { theme } = useTheme();
  return (
    <div
      className="rounded-full border-2 animate-spin"
      style={{ width: size, height: size, borderColor: theme.border, borderTopColor: theme.accent }}
    />
  );
}
