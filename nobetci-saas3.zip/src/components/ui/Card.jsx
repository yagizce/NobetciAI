import { useTheme } from "../../contexts/ThemeContext.jsx";

/**
 * @param {{ children: React.ReactNode, className?: string, padded?: boolean }} props
 */
export default function Card({ children, className = "", padded = true }) {
  const { theme } = useTheme();
  return (
    <div
      className={`rounded-xl border ${padded ? "px-4 py-4" : ""} ${className}`}
      style={{ borderColor: theme.border, background: theme.surface }}
    >
      {children}
    </div>
  );
}
