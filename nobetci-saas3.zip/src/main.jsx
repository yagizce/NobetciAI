import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { ThemeProvider } from "./contexts/ThemeContext.jsx";
import { RoleProvider } from "./contexts/RoleContext.jsx";
import { IsgDataProvider } from "./contexts/IsgDataContext.jsx";
import { ToastProvider } from "./contexts/ToastContext.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <ErrorBoundary>
    <ThemeProvider>
      <ToastProvider>
        <RoleProvider>
          <IsgDataProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </IsgDataProvider>
        </RoleProvider>
      </ToastProvider>
    </ThemeProvider>
  </ErrorBoundary>
);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js").catch(() => {});
  });
}
