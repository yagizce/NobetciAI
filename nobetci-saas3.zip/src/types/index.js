/**
 * @typedef {Object} User
 * @property {string} id
 * @property {string} name
 * @property {string} email
 * @property {string} companyId
 * @property {"expert"|"employer"|"employee"} role
 * @property {"trial"|"pro"|"enterprise"} subscription
 */

/**
 * @typedef {Object} DocumentRecord
 * @property {number} id
 * @property {string} type - Belge türü (bkz. constants/documentTypes.js)
 * @property {string} title
 * @property {string} createdBy
 * @property {string} createdAt
 * @property {"draft"|"completed"} status
 * @property {string} content - Şu an boş/placeholder; AI üretimi eklenince doldurulacak
 */

/**
 * @typedef {Object} FineKinneyEntry
 * @property {number} id
 * @property {string} hazard - Tehlike
 * @property {string} risk - Risk
 * @property {number} probability - Olasılık
 * @property {number} frequency - Frekans
 * @property {number} severity - Şiddet
 * @property {number} score - Otomatik puan (probability × frequency × severity)
 * @property {string} riskLevel - Risk seviyesi (computed label)
 * @property {string} action - Alınacak önlem
 * @property {string} responsible - Sorumlu kişi
 * @property {string} dueDate - Termin tarihi
 * @property {"open"|"in_progress"|"done"} status - Durum
 */

/**
 * @typedef {Object} Notification
 * @property {number} id
 * @property {"ramakKala"|"tehlike"|"kaza"} type
 * @property {string} desc
 * @property {"pending"|"ai_analyzed"|"approved"} status
 * @property {string} worker
 * @property {string} date
 * @property {string|null} aiAnalysis
 * @property {string|null} expertNote
 */

/**
 * @typedef {Object} Equipment
 * @property {number} id
 * @property {string} name
 * @property {string|null} qr
 * @property {string} lastCheck
 */

/**
 * @typedef {Object} ChatMessage
 * @property {"user"|"assistant"} role
 * @property {string} text
 * @property {string} [image]
 * @property {string} time
 */

export {};
