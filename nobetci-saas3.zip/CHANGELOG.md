# Changelog

## [Auth Hazırlığı, Role-Based Routing, Fine-Kinney, Doküman Altyapısı] — Bu güncelleme

Kural: yeniden yazma değil, mevcut çalışan sistem korunarak üzerine inşa edildi. Yeni sayfa/route eklenmedi — tüm yeni özellikler mevcut route'ların içine (sekme olarak) yerleşti. Yeni bağımlılık eklenmedi.

### 1. Auth sistemi hazırlığı
- Rol değerleri artık sabit ve gerçek sisteme hazır: yalnızca `expert` | `employer` | `employee` (önceki `worker` değeri her yerde `employee` olarak güncellendi — bkz. `src/contexts/RoleContext.jsx`).
- `src/types/index.js` — `User` tipine `companyId` eklendi (`company` yerine), gerçek şirket ilişkisine hazır.
- `src/constants/mockUsers.js` — her rol için ayrı sahte kullanıcı (`MOCK_USERS.expert/employer/employee`), her biri `id, name, email, companyId, role, subscription` alanlarına sahip.
- `src/constants/companies.js` — sahte şirket dizini, `companyId` ile ilişkili.
- `src/services/authService.js` — `getCurrentUser(role)` artık role'e göre doğru sahte kullanıcıyı döndürüyor. Gerçek login eklenince yalnızca bu dosya değişecek, `role` parametresi kalkıp sunucudan gelen oturum bilgisiyle değişecek.
- `src/pages/Profile.jsx` — artık gerçek `companyId → şirket adı` çözümlemesi yapıyor, rol değiştikçe otomatik güncelleniyor.

### 2. Role-based routing
- `/dashboard` route'u tek kalmaya devam ediyor (gereksiz yeni route eklenmedi) — ama içeriği tamamen role'e göre seçiliyor: `src/features/dashboard/DashboardPage.jsx` artık `ExpertDashboard` / `EmployerDashboard` / `EmployeeDashboard` arasında yönlendirme yapan ince bir router.
- Gerçek login eklendiğinde, kullanıcı `/dashboard`'a gittiğinde otomatik olarak kendi rolüne uygun görünümü görecek — kod zaten buna göre yazıldı, ekstra değişiklik gerekmeyecek.

### 3. Role bazlı dashboard içerikleri
- `src/features/dashboard/ExpertDashboard.jsx` — Aktif şirketler, Bekleyen analizler, Son analizler, AI Chat kısayolu.
- `src/features/dashboard/EmployerDashboard.jsx` — Şirket özeti, Risk analizleri (onaylanmış bildirimler), Çalışanlar (`constants/mockEmployees.js`), Eğitimler.
- `src/features/dashboard/EmployeeDashboard.jsx` — Eğitimler, Bildirimlerim, Kendisine atanmış görevler (onaylanmış kendi bildirimleri).
- Üçü de gerçek paylaşılan veriyi (`IsgDataContext`) kullanıyor — mock olan yalnızca şirket/çalışan listeleri.

### 4. Fine-Kinney modülü güçlendirildi
- `src/constants/fineKinney.js` — standart Olasılık/Frekans/Şiddet skala değerleri + `computeFineKinneyScore()` + `getFineKinneyRiskLevel()` (5 kademeli risk seviyesi).
- `src/services/riskService.js` — artık gerçek CRUD içeriyor (`getFineKinneyEntries`, `saveFineKinneyEntry`, `deleteFineKinneyEntry`), IndexedDB'de saklıyor. `scoreRisk()` hâlâ placeholder (gelecekteki AI destekli otomatik puanlama için ayrıldı).
- `src/features/risk-analysis/FineKinneyModule.jsx` — düzenlenebilir liste: Tehlike, Risk, Olasılık, Frekans, Şiddet, otomatik puan, risk seviyesi, önlem, sorumlu, termin tarihi, durum. Ekle/düzenle/sil destekli, veri tamamen JSON-serileştirilebilir.
- Risk Analizi sayfası artık iki sekmeli: "Bildirim Merkezi" (değişmedi) ve "Fine-Kinney Değerlendirmesi" (yeni). L Tipi matris eklenmedi (talep edilmedi).

### 5. Doküman altyapısı
- `src/constants/documentTypes.js` — 6 belge türü: Risk Analizi, Acil Durum Planı, Talimat, KKD Teslim Tutanağı, Ramak Kala, İş Kazası Bildirimi.
- `src/services/documentService.js` — `getDocuments`, `saveDocument`, `deleteDocument` eklendi (equipment fonksiyonlarının yanına).
- `src/features/documents/DocumentGenerator.jsx` — belge türü + başlık seçip taslak oluşturma arayüzü. **Henüz AI ile içerik üretmiyor** (`content` alanı boş placeholder) — talep edildiği gibi yalnızca arayüz ve veri modeli.
- Dokümanlar sayfası artık üç sekmeli: Ekipman Kayıtları, Eğitim Modülleri, Belge Oluştur (yeni).

### Kod tekrarını azaltma
- `src/constants/education.js` — eğitim modülleri listesi artık tek yerde tanımlı, hem Dokümanlar sayfası hem Employer/Employee dashboard'ları buradan okuyor (önceden yalnızca Dokümanlar'da tanımlıydı, dashboard'lar için kopyalamak yerine paylaşıldı).

### Bozulmayanlar (doğrulandı)
- AI Chat, Bildirim Merkezi akışı, QR ekipman takibi, Netlify Functions, PWA, dark/light tema — hepsi test edildi, hiçbir import/referans kopmadı (otomatik bütünlük kontrolünden geçti).
- API sistemi değişmedi — hâlâ yalnızca `chatService.js` üzerinden, yalnızca `netlify/functions/chat.js` proxy'si ile.

---

## [Kurumsal Mimari Refaktörü] — Önceki güncelleme

Bu bir yeniden yazma değildir — çalışan hiçbir özellik bozulmadı, kod yeni bir mimariye taşındı.

### Kaldırıldı
- `src/pages/Settings.jsx` — tekrarlanan tema değiştirici kaldırıldı (zaten Header'da mevcut)
- `src/services/api.js` — yerini `src/services/chatService.js` aldı
- `src/hooks/useIsgData.js` — yerini `src/contexts/IsgDataContext.jsx` aldı (bkz. "Düzeltilen hata")

### Eklendi — Servis katmanı
- `src/services/chatService.js` — **tek gerçekten çalışan servis.** Chat ve fotoğraf analizi Netlify Function proxy'sine buradan gidiyor.
- `src/services/authService.js` — **sahte (mock) kullanıcı sistemi.** `getCurrentUser()` şu an sabit bir `User` objesi döndürüyor (`id, name, email, company, role, subscription`). Gerçek kimlik doğrulama eklenince yalnızca bu dosya değişecek.
- `src/services/documentService.js` — ekipman kayıtları için IndexedDB sarmalayıcı (gerçek, çalışıyor — ama API'ye gitmiyor).
- `src/services/riskService.js` — **iskelet/placeholder.** Risk analizi şu an `chatService` üzerinden yapılıyor; bu dosya gelecekte özel bir risk-skorlama backend'i eklenince kullanılacak.

### Eklendi — Sayfa/Route yapısı
- `src/App.jsx` — tüm sayfalar artık `React.lazy` + `Suspense` ile code-splitting kullanıyor (her sayfa kendi JS parçası, yalnızca ziyaret edildiğinde indiriliyor).
- Tüm sayfalara `useDocumentTitle` hook'u eklendi (`src/hooks/useDocumentTitle.js`) — sekme başlığı sayfaya göre dinamik olarak değişiyor.

### Eklendi — Hata yönetimi
- `src/components/ErrorBoundary.jsx` — `main.jsx`'te tüm uygulamayı sarmalıyor, render hatalarını yakalayıp kullanıcıya "Sayfayı Yenile" seçeneği sunuyor.
- `src/components/Loading.jsx` — tam sayfa yükleme göstergesi (Suspense fallback olarak da kullanılıyor).
- `src/components/EmptyState.jsx` — boş liste durumları için (Dashboard ve Risk Analizi'nde kullanıldı).
- 404 sayfası zaten mevcuttu (`src/pages/NotFound.jsx`), route yapısına bağlı kalmaya devam ediyor.

### Eklendi — Yeniden kullanılabilir bileşenler (`src/components/ui/`)
`Button`, `Input`, `Modal`, `Card`, `Badge`, `Loader`, `Toast` (+ `src/contexts/ToastContext.jsx`), `ConfirmDialog`.
Bazıları (Button, Badge, EmptyState) Risk Analizi ve Dashboard sayfalarında kullanılmaya başlandı; diğerleri (Modal, Input, Card, ConfirmDialog) hazır ve kullanılabilir durumda ama henüz her ekrana zorla entegre edilmedi — mevcut, çalışan arayüzü bozmamak adına kademeli benimseme tercih edildi.

### Düzeltilen hata
- **Veri tutarsızlığı:** Önceki sürümde `useIsgData` düz bir hook'tu; Header, Dashboard, Risk Analizi ve Dokümanlar sayfaları her biri kendi bağımsız IndexedDB okuma/durum kopyasına sahipti. Bir sayfada bildirim gönderildiğinde diğerleri anında güncellenmiyordu. Şimdi `src/contexts/IsgDataContext.jsx` tek bir paylaşılan kaynak — tüm sayfalar gerçek zamanlı senkronize.

### TypeScript hazırlığı
- `src/types/index.js` içine `User` tipi eklendi (JSDoc `@typedef`).
- Servis fonksiyonlarına JSDoc `@param`/`@returns` eklendi — ileride `.ts`'e geçişte tip çıkarımı kolaylaşsın diye.
- Yeni bağımlılık eklenmedi (TypeScript derleyicisi dahil) — mevcut kısıtlamaya uyuldu.

### Performans
- Route bazlı code splitting (`React.lazy`/`Suspense`).
- `React.memo`: `NotificationCard`, `QuickActionButton` — liste öğeleri artık gereksiz yere yeniden render olmuyor.
- `useMemo`: Dashboard metrikleri, Risk Analizi'nde görünür bildirim filtresi.
- `useCallback`: memoized bileşenlere geçen tüm handler'lar (`askQuickAction`, `copyMessage`, `submitNotification`, `expertApprove`).

### Güvenlik
- Değişiklik yok — API anahtarı hâlâ yalnızca `netlify/functions/chat.js` içinde, ortam değişkeni olarak duruyor. Hiçbir noktada frontend koduna yazılmadı.

### Bozulmayanlar (doğrulandı)
- AI Chat (hazır sorular, fotoğraf analizi, kopyala/temizle)
- Bildirim Merkezi akışı (Çalışan → AI → Uzman → İşveren)
- QR ekipman takibi, Eğitim modülleri
- Netlify Functions, `netlify.toml` build ayarları
- PWA (manifest, service worker) — `/public` altında değişmeden duruyor
- Dark/Light tema — `localStorage`'da saklanmaya devam ediyor, artık yalnızca Header'da
